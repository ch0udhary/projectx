<?php
if(Sentinel::check())
{
if (Sentinel::inRole('admin')) {

$login_user_details = Sentinel::getUser();
$login_user_details_id = $login_user_details->id;
//echo '<pre>'; print_r($login_user_details); echo '</pre>';
$Full_name = $login_user_details->first_name.' '.$login_user_details->last_name;
    ?>
        <!doctype html>
<html lang="{{ app()->getLocale() }}">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
     <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    {{--<title>{{ config('app.name', 'Laravel') }}</title>--}}
    <title>Amma India Admin Dashboard</title>
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="Unify Admin Panel" />
    <meta name="keywords" content="Admin, Dashboard, Bootstrap4, Sass, CSS3, HTML5, Responsive Dashboard, Responsive Admin Template, Admin Template, Best Admin Template, Bootstrap Template, Themeforest" />
    <meta name="author" content="Bootstrap Gallery" />
    <link rel="shortcut icon" href="{{url('/')}}/img/favicon.ico" />


    <!-- Common CSS -->
    <link rel="stylesheet" href="{{ URL::asset('css/bootstrap.min.css')}}" />
    <link rel="stylesheet" href="{{ URL::asset('fonts/icomoon/icomoon.css')}}" />
    <link rel="stylesheet" href="{{ URL::asset('css/main.css')}}" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

    <!-- Other CSS includes plugins - Cleanedup unnecessary CSS -->
    <!-- Chartist css -->
    <link href="{{ URL::asset('vendor/chartist/css/chartist.min.css')}}" rel="stylesheet" />
    <link href="{{ URL::asset('vendor/chartist/css/chartist-custom.css')}}" rel="stylesheet" />
    @yield('stylesheet')
</head>
<body>


<!-- Loading starts -->
@if (\Request::is('/'))

    <div class="loading-wrapper">
    <div class="loading">
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        <span></span>
    </div>
</div>
@endif
<!-- Loading ends -->

<!-- BEGIN .app-wrap -->
<div class="app-wrap">
    <!-- BEGIN .app-heading -->
    <header class="app-header">
        <div class="container-fluid">
            <div class="row gutters">
                <div class="col-xl-7 col-lg-7 col-md-7 col-sm-7 col-8">
                    <a class="mini-nav-btn" href="#" id="app-side-mini-toggler">
                        <i class="icon-arrow_back"></i>
                    </a>
                    <a href="#app-side" data-toggle="onoffcanvas" class="onoffcanvas-toggler float-left" aria-expanded="true">
                        <i class="icon-chevron-thin-left"></i>
                    </a>
                    <a href="{{url('/')}}" class="logo float-left ml-4">
                        <img src="{{url('/')}}/img/logo.png" alt="Amma India Admin Dashboard" />
                    </a>
                </div>
                <div class="col-xl-5 col-lg-5 col-md-5 col-sm-5 col-4">
                    <ul class="header-actions">
                        <li>
                            <a href="#" id="notifications" data-toggle="dropdown" aria-haspopup="true">
                                <i class="icon-notifications_none"></i>
                                <span class="count-label">7</span>
                            </a>
                            <div class="dropdown-menu dropdown-menu-right lg" aria-labelledby="notifications">
                                <ul class="imp-notify">
                                    <li>
                                        <div class="icon">W</div>
                                        <div class="details">
                                            <p><span>Wilson</span> The best Dashboard design I have seen ever.</p>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="icon">J</div>
                                        <div class="details">
                                            <p><span>John Smith</span> Jhonny sent you a message. Read now!</p>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="icon secondary">R</div>
                                        <div class="details">
                                            <p><span>Justin Mezzell</span> Stella, Added you as a Friend. Accept it!</p>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <li>
                            <a href="#" id="todos" data-toggle="dropdown" aria-haspopup="true">
                                <i class="icon-person_outline"></i>
                                <span class="count-label red">5</span>
                            </a>
                            <div class="dropdown-menu dropdown-menu-right lg" aria-labelledby="todos">
                                <ul class="stats-widget">
                                    <li>
                                        <h4>$37895</h4>
                                        <p>Revenue <span>+2%</span></p>
                                        <div class="progress">
                                            <div class="progress-bar" role="progressbar" aria-valuenow="87" aria-valuemin="0" aria-valuemax="100" style="width: 87%">
                                                <span class="sr-only">87% Complete (success)</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <h4>4,897</h4>
                                        <p>Downloads <span>+39%</span></p>
                                        <div class="progress">
                                            <div class="progress-bar" role="progressbar" aria-valuenow="65" aria-valuemin="0" aria-valuemax="100" style="width: 65%">
                                                <span class="sr-only">65% Complete (success)</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <h4>2,219</h4>
                                        <p>Uploads <span class="text-secondary">-7%</span></p>
                                        <div class="progress">
                                            <div class="progress-bar bg-danger" role="progressbar" aria-valuenow="42" aria-valuemin="0" aria-valuemax="100" style="width: 42%">
                                                <span class="sr-only">42% Complete (success)</span>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <li>
                            <a href="#" id="userSettings" class="user-settings" data-toggle="dropdown" aria-haspopup="true">
                                <img class="avatar" src="{{url('/')}}/img/user.png" alt="User Thumb" />
                                <span class="user-name">{{$Full_name}}</span>
                                <i class="icon-chevron-small-down"></i>
                            </a>
                            <div class="dropdown-menu lg dropdown-menu-right" aria-labelledby="userSettings">
                                <ul class="user-settings-list">
                                    <li>
                                        <a href="profile.html">
                                            <div class="icon">
                                                <i class="icon-account_circle"></i>
                                            </div>
                                            <p>Profile</p>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="profile.html">
                                            <div class="icon red">
                                                <i class="icon-cog3"></i>
                                            </div>
                                            <p>Settings</p>
                                        </a>
                                    </li>

                                </ul>
                                <div class="logout-btn">
                                    <a href="{{ route('logout') }}" class="btn btn-primary">Logout</a>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </header>
    <!-- END: .app-heading -->

    <!-- END: .app-heading -->
    <!-- BEGIN .app-container -->
    <div class="app-container">
        <!-- BEGIN .app-side -->
        <aside class="app-side" id="app-side">
            <!-- BEGIN .side-content -->
            <div class="side-content ">
                <!-- BEGIN .user-profile -->
                <div class="user-profile">
                    <a href="{{url('/')}}" class="logo">
                        <img src="{{url('/')}}/img/logo.png" alt="Amma India Admin Dashboard" />
                    </a>
                </div>
                <!-- END .user-profile -->
                <!-- BEGIN .side-nav -->
                <nav class="side-nav">
                    <!-- BEGIN: side-nav-content -->
                    <ul class="unifyMenu" id="unifyMenu">
                        <li class="@if(ends_with(Route::currentRouteAction(), 'HomeController@index')) active selected @endif">

                            <a href="{{url('/')}}">
										<span class="has-icon">
											<i class="icon-laptop_windows"></i>
										</span>
                                <span class="nav-title">Dashboards</span>
                            </a>
                        </li>

                        <li class="@if(ends_with(Route::currentRouteAction(), 'MasterFacultyController@index') ||ends_with(Route::currentRouteAction(), 'MasterFranchisesController@index') ||( Route::currentRouteName() == 'franchisee-mapping.create') || ( Route::currentRouteName() == 'centres.create') || ends_with(Route::currentRouteAction(), 'MasterFranchisesController@create')|| ends_with(Route::currentRouteAction(), 'MasterFranchisesController@show')|| ends_with(Route::currentRouteAction(), 'FranchisesController@show')|| ends_with(Route::currentRouteAction(), 'FranchisesController@create')|| ends_with(Route::currentRouteAction(), 'FranchisesController@index')) active selected @endif">
                            <a href="#" class="has-arrow" aria-expanded="false">
										<span class="has-icon">
											<i class="icon-school"></i>
										</span>
                                <span class="nav-title">Franchisee</span>
                            </a>
                            <ul aria-expanded="false">
                                <li>
                                  {{--  {{ Route::currentRouteName() }}--}}
                                    <a class="@if(ends_with(Route::currentRouteAction(), 'MasterFranchisesController@create'))current-page @endif" href="{{url('/admin/master-franchises/create')}}">Add Master Franchisee</a>
                                </li>
                                <li>
                                    <a class="@if( Route::currentRouteName() == 'franchises.create') current-page @endif" href="{{url('/admin/franchises/create')}}">Add Franchisee</a>
                                </li>
                                <li>
                                    <a class="@if(ends_with(Route::currentRouteAction(), 'MasterFranchisesController@index'))current-page @endif" href="{{url('/admin/master-franchises')}}">List Master Franchisee</a>
                                </li>
                                <li>
                                    <a class="@if( Route::currentRouteName() == 'franchises') current-page @endif" href="{{url('/admin/franchises')}}">List Franchisee</a>
                                </li>
                                <li>
                                    <a class="@if( Route::currentRouteName() == 'centres.create') current-page @endif" href="{{url('/admin/centres/create')}}">Add Centre</a>
                                </li>
                                <li>
                                    <a class="@if( Route::currentRouteName() == 'franchisee-mapping.create') current-page @endif" href="{{url('/admin/franchisee-mapping/create')}}">Franchisee Mapping</a>
                                </li>
                                <li>
                                    <a class="@if( Route::currentRouteName() == 'center-faculty.index') current-page @endif" href="{{url('/admin/center-faculty')}}">Center Faculty</a>
                                </li>
                            </ul>
                        </li>
                        <li class="@if(ends_with(Route::currentRouteAction(), 'LeadController@index') || ends_with(Route::currentRouteAction(), 'LeadController@create')|| ends_with(Route::currentRouteAction(), 'LeadController@show')) active selected @endif">
                            <a  href="#"  class="has-arrow" aria-expanded="false">

										<span class="has-icon">
											<i class="icon-perm_device_information"></i>
										</span>
                                <span class="nav-title">Lead</span>
                            </a>
                            <ul aria-expanded="false">
                                <li>
                                    <a class="@if(ends_with(Route::currentRouteAction(), 'LeadController@create'))current-page @endif" href='{{url('/admin/leads/create')}}'>Add Lead</a>
                                </li>
                                <li>
                                    <a class="@if(ends_with(Route::currentRouteAction(), 'LeadController@index'))current-page @endif" href='{{url('/admin/leads')}}'>List Lead</a>
                                </li>
                            </ul>
                        </li>
                        <li class="@if(ends_with(Route::currentRouteAction(), 'StudentController@dropOut') ||ends_with(Route::currentRouteAction(), 'StudentController@issueCertificate') ||ends_with(Route::currentRouteAction(), 'StudentController@createGrade') ||ends_with(Route::currentRouteAction(), 'ProgramLevelController@index') ||ends_with(Route::currentRouteAction(), 'ProgramMasterController@index') ||ends_with(Route::currentRouteAction(), 'StudentController@index') || ends_with(Route::currentRouteAction(), 'StudentController@create')|| ends_with(Route::currentRouteAction(), 'StudentController@show')|| ends_with(Route::currentRouteAction(), 'AttendanceController@index') || ends_with(Route::currentRouteAction(), 'StudentController@add_program') || ends_with(Route::currentRouteAction(), 'StudentController@applyCertificate')) active selected @endif">
                            <a  href="#"  class="has-arrow" aria-expanded="false">
										<span class="has-icon">
											<i class="icon-users2"></i>
										</span>
                                <span class="nav-title">Student</span>
                            </a>
                            <ul aria-expanded="false">
                                <li>
                                    <a class="@if(ends_with(Route::currentRouteAction(), 'StudentController@create'))current-page @endif" href='{{url('/admin/students/create')}}'>Add New Student</a>
                                </li>
                                <li>
                                    <a class="@if(ends_with(Route::currentRouteAction(), 'StudentController@add_program'))current-page @endif" href='{{url('/admin/add-program')}}'>
                                    Admit to program</a>
                                </li>
                                <li>
                                    <a class="@if(ends_with(Route::currentRouteAction(), 'AttendanceController@index'))current-page @endif"  href='{{url("admin/attendance") }}'>Student Attendance</a>
                                </li>
                                 <li>
                                 <a class="@if(ends_with(Route::currentRouteAction(), 'StudentController@index'))current-page @endif" href='{{url('/admin/students')}}'>All Student</a>
                                <li>
                                    <a href='{{ url("admin/apply-certificate") }}'>Apply for Certificate</a>
                                </li>
                                <li>
                                    <a href='{{ url("admin/issue-certificate") }}'>Issue Certificate</a>
                                </li>
                                <li>
                                    <a href='{{ url("admin/drop-out") }}'>Drop out</a>
                                </li>
                                <li>
                                    <a href='{{url("admin/grade-master")}}'>Grade Master</a>
                                </li>
                                <li>
                                    <a href='{{url("admin/program-master")}}'>Program Master</a>
                                </li>
                                <li>
                                    <a href='{{url("admin/program-level")}}'>Program level</a>
                                </li>
                            </ul>
                        </li>
                        <li class="@if(ends_with(Route::currentRouteAction(), 'FeesManagerContoller@generatereceipt') || ends_with(Route::currentRouteAction(), 'FeesManagerContoller@feelist') || ends_with(Route::currentRouteAction(), 'FeesManagerContoller@index') || ends_with(Route::currentRouteAction(), 'FeesManagerContoller@index')) active selected @endif">
                            <a href="#" class="has-arrow" aria-expanded="false">
										<span class="has-icon">
											<i class="icon-payment"></i>
										</span>
                                <span class="nav-title">Fee Management</span>
                            </a>
                            <ul aria-expanded="false">
                                <li>
                                    <a href='{{ route("generatereceipt") }}'>Genrerate Receipt</a>
                                </li>
                                <li>
                                    <a href='{{ route("feelist") }}'>List Fee</a>
                                </li>
                                <li>
                                    <a href='{{ route("fees-master.index") }}'>Fee Master</a>
                                </li>
                                <li>
                                    <a href='{{ route("feelistpending") }}'>Pending Fee</a>
                                </li>
                            </ul>
                        </li>
                        <li class="@if(ends_with(Route::currentRouteAction(), 'TrainingCompletionController@index') || ends_with(Route::currentRouteAction(), 'TrainingCompletionController@create') || ends_with(Route::currentRouteAction(), 'TrainingCalenderController@create') || ends_with(Route::currentRouteAction(), 'TrainingCalenderController@index') || ends_with(Route::currentRouteAction(), 'TrainingFeeController@index') || ends_with(Route::currentRouteAction(), 'TrainingFeeController@create') || ends_with(Route::currentRouteAction(), 'FacultyController@create') || ends_with(Route::currentRouteAction(), 'FacultyController@index')) active selected @endif">
                            <a href="#" class="has-arrow" aria-expanded="false">
										<span class="has-icon">
											<i class="icon-verified_user"></i>
										</span>
                                <span class="nav-title">Faculty</span>
                            </a>
                            <ul aria-expanded="false">
                                <li>
                                    <a href='{{ route("faculty.create") }}'>Registration</a>
                                </li>
                                <li>
                                    <a href='{{ route("training-fee.create") }}'>Training Fee</a>
                                </li>
                                <li>
                                    <a href='{{ route("training-calender.index") }}'>Training Calendar</a>
                                </li>
                                <li>
                                    <a href='{{ route("training-completion.index") }}'>Training Completion</a>
                                </li>
                                <li>
                                    <a href='{{ route("training-fee.index") }}'>Training Fee List</a>
                                </li>
                                <li>
                                    <a href='{{ route("faculty.index") }}'>Faculty List</a>
                                </li>
                            </ul>
                        </li>
                        <li class="@if(ends_with(Route::currentRouteAction(), 'PaymentReceiptController@create') || ends_with(Route::currentRouteAction(), 'PaymentReceiptController@index') ||ends_with(Route::currentRouteAction(), 'DispatchChallanController@index') || ends_with(Route::currentRouteAction(), 'DispatchChallanController@create') ||ends_with(Route::currentRouteAction(), 'IssueRequestController@create') ||ends_with(Route::currentRouteAction(), 'IssueRequestController@index') || ends_with(Route::currentRouteAction(), 'IssueRequestController@create') || ends_with(Route::currentRouteAction(), 'PurchaseChallanController@create') || ends_with(Route::currentRouteAction(), 'PurchaseChallanController@index') || ends_with(Route::currentRouteAction(), 'ItemMasterController@index') || ends_with(Route::currentRouteAction(), 'ItemMasterController@create') || ends_with(Route::currentRouteAction(), 'PartyMasterController@create') || ends_with(Route::currentRouteAction(), 'PartyMasterController@index')) active selected @endif">
                            <a href="#" class="has-arrow" aria-expanded="false">
										<span class="has-icon">
											<i class="icon-view_list"></i>
										</span>
                                <span class="nav-title">Inventory</span>
                            </a>
                            <ul aria-expanded="false">
                                <li>
                                    <a href='#' class="has-arrow" aria-expanded="false">
                                        <span class="nav-title">Party Master</span>
                                    </a>
                                    <ul aria-expanded="false">
                                        <li>
                                            <a href='{{ route("party-master.create") }}'>Add</a>
                                        </li>
                                        <li>
                                            <a href='{{ route("party-master.index")  }}'>List</a>
                                        </li>
                                    </ul>
                                </li>
                                <li>
                                    <a href='#' class="has-arrow" aria-expanded="false">
                                        <span class="nav-title">Item Master</span>
                                    </a>
                                    <ul aria-expanded="false">
                                        <li>
                                            <a href='{{ route("item-master.create") }}'>Add</a>
                                        </li>
                                        <li>
                                            <a href='{{ route("item-master.index") }}'>List</a>
                                        </li>
                                    </ul>
                                </li>
                                <li>
                                    <a href='{{ route("purchase-challan.create") }}'>Purchase Challan</a>
                                </li>
                                <li>
                                    <a href='{{ route("issue-request.create") }}'>Issue Request</a>
                                </li>
                                <li>
                                    <a href='{{ route("dispatch-challan.index") }}'>Dispatch Challan</a>
                                </li>
                                <li>
                                    <a href='{{ route("payment-receipt.create") }}'>Payment Receipt</a>
                                </li>
                            </ul>
                        </li>
                        <li>
                            <a href="#" class="has-arrow" aria-expanded="false">
										<span class="has-icon">
											<i class="icon-chart-bar-outline"></i>
										</span>
                                <span class="nav-title">Reports</span>
                            </a>
                            <ul aria-expanded="false">
                                <li>
                                    <a href='students-admission-report.html'>Student Admission Report</a>
                                </li>
                                <li>
                                    <a href='students-drop-out-report.html'>Student Drop Out Report</a>
                                </li>
                                <li>
                                    <a href='students-course-completion-report.html'>Student Course Completion Report</a>
                                </li>
                                <li>
                                    <a href='students-certificate-issue-report.html'>Student Certificate Issue Report</a>
                                </li>
                                <li>
                                    <a href='students-aggregate-performance.html'>Students Aggregate Performance</a>
                                </li>
                                <li>
                                    <a href='students-fee-report.html'>Students Fee Report</a>
                                </li>
                                <li>
                                    <a href='fees-outstanding.html'>Fees Outstanding</a>
                                </li>
                                <li>
                                    <a href='material-purchased.html'>Material Purchased</a>
                                </li>
                                <li>
                                    <a href='dispatch-challan-report.html'>Dispatch Challan Report</a>
                                </li>
                                <li>
                                    <a href='material-dispatch.html'>Material Dispatch</a>
                                </li>
                                <li>
                                    <a href='outstanding-payments-detail.html'>Outstanding Payments Detail</a>
                                </li>
                                <li>
                                    <a href='level-assessment-result.html'>Level Assessment Result</a>
                                </li>
                                <li>
                                    <a href='centre-performance.html'>Centre Performance</a>
                                </li>
                            </ul>
                        </li>


                    </ul>
                    <!-- END: side-nav-content -->
                </nav>
                <!-- END: .side-nav -->
            </div>
            <!-- END: .side-content -->
        </aside>
        <!-- END: .app-side -->
        @yield('before-content')
        @yield('content')

    </div>
    <!-- END: .app-container -->
    <!-- BEGIN .main-footer -->

    <footer class="main-footer fixed-btm">
        Copyright Amma India Admin 2018.
    </footer>
    <!-- END: .main-footer -->
</div>
<!-- END: .app-wrap -->

<!-- jQuery first, then Tether, then other JS. -->
<script src="{{ URL::asset('js/jquery.js')}}"></script>
<script src="{{ URL::asset('js/tether.min.js')}}"></script>
<script src="{{ URL::asset('js/bootstrap.min.js')}}"></script>
<script src="{{ URL::asset('vendor/unifyMenu/unifyMenu.js')}}"></script>
<script src="{{ URL::asset('vendor/onoffcanvas/onoffcanvas.js')}}"></script>
<script src="{{ URL::asset('js/moment.js')}}"></script>

<!-- Sparkline JS -->
<script src="{{ URL::asset('vendor/sparkline/sparkline-retina.js')}}"></script>
<script src="{{ URL::asset('vendor/sparkline/custom-sparkline.js')}}"></script>

<!-- Slimscroll JS -->
<script src="{{ URL::asset('vendor/slimscroll/slimscroll.min.js')}}"></script>
<script src="{{ URL::asset('vendor/slimscroll/custom-scrollbar.js')}}"></script>

<!-- Chartist JS -->
<script src="{{ URL::asset('vendor/chartist/js/chartist.min.js')}}"></script>
<script src="{{ URL::asset('vendor/chartist/js/chartist-tooltip.js')}}"></script>
<script src="{{ URL::asset('vendor/chartist/js/custom/custom-line-chart3.js')}}"></script>
<script src="{{ URL::asset('vendor/chartist/js/custom/custom-area-chart.js')}}"></script>
<script src="{{ URL::asset('vendor/chartist/js/custom/donut-chart2.js')}}"></script>
<script src="{{ URL::asset('vendor/chartist/js/custom/custom-line-chart4.js')}}"></script>

<!-- Common JS -->
<script src="{{ URL::asset('js/common.js')}}"></script>

@yield('javascript')


</body>
</html>


<?php }}else{ ?>


<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'Laravel') }}</title>

    <!-- Scripts -->
    <script src="{{ asset('js/app.js') }}" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Raleway:300,400,600" rel="stylesheet" type="text/css">

    <!-- Styles -->
    <link href="{{ asset('css/app.css') }}" rel="stylesheet">
</head>
<body>
<div id="app">
    <nav class="navbar navbar-expand-md navbar-light navbar-laravel">
        <div class="container">
            <a class="navbar-brand" href="{{ url('/') }}">
                {{ config('app.name', 'Laravel') }}
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <!-- Left Side Of Navbar -->
                <ul class="navbar-nav mr-auto">

                </ul>

                <!-- Right Side Of Navbar -->
                <ul class="navbar-nav ml-auto">
                    <!-- Authentication Links -->
                    @guest
                        <li><a class="nav-link" href="{{ route('login') }}">{{ __('Login') }}</a></li>
                        <li><a class="nav-link" href="{{ route('register') }}">{{ __('Register') }}</a></li>
                    @else
                        <li class="nav-item dropdown">
                            <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                {{ Auth::user()->name }} <span class="caret"></span>
                            </a>

                            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="{{ route('logout') }}"
                                   onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                    {{ __('Logout') }}
                                </a>

                                <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                    @csrf
                                </form>
                            </div>
                        </li>
                    @endguest
                </ul>
            </div>
        </div>
    </nav>

    <main class="py-4">
        @yield('content')
    </main>

</div>
</body>
</html>


    <?php } ?>

