@extends('layouts.app')
@section('stylesheet')
    <link href="{{ URL::asset('css/toastr.min.css')}}" rel="stylesheet" type="text/css" />
    <link href="{{ URL::asset('css/jquery.toast.css')}}" rel="stylesheet">
@endsection
@section('content')

    <!-- BEGIN .app-main -->
    <div class="app-main">
        <!-- BEGIN .main-heading -->
        <header class="main-heading">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-xl-8 col-lg-8 col-md-8 col-sm-8">
                        <div class="page-icon">
                            <i class="icon-layers"></i>
                        </div>
                        <div class="page-title">
                            <h5>Master Program</h5>
                            <h6 class="sub-heading">Welcome to Amma</h6>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4">
                        <div class="right-actions">
                            <a href="#" class="btn btn-primary float-right" data-toggle="tooltip" data-placement="left" title="Download Reports">
                                <i class="icon-download4"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <!-- END: .main-heading -->
        <!-- BEGIN .main-content -->
        <div class="main-content">

            <div class="row gutters">
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                    <!-- Row start -->
                    <div class="card">
                        {{--@if (\Session::has('success'))
                            <div class="alert alert-success">
                                <ul>
                                    <li>{!! \Session::get('success') !!}</li>
                                </ul>
                            </div>
                        @endif
--}}

                        <?php //echo '<pre>'; print_r($errors->all()); echo '</pre>'; ?>

                        {{-- @if ($errors->any())
                             <div class="alert alert-danger">
                                 <ul>
                                     @foreach ($errors->all() as $error)
                                         <li>{{ $error }}</li>
                                     @endforeach
                                 </ul>
                             </div>
                         @endif
--}}
                        <div class="card-body">
                            <form method="post" action="{{ route('program-level.store') }}">
                                @csrf
                                <div class="row gutters">
                                    <div class="col-md-8 mx-auto col-sm-12">

                                        <div class="form-group">
                                            <div class="row gutters">
                                                <div class="col-sm-12">
                                                    <div class="row">
                                                        <div class="form-group col-sm-12">
                                                <select name="master_program" id="master_program" class="form-control {{ $errors->has('master_program') ? ' is-invalid' : '' }}">
                                                    <option value="" >Select Master Program</option>
                                                    @if(isset($programmasters))
                                                        @foreach($programmasters as $mvalue)
                                                            <option value="{{$mvalue['id']}}" @if(old('master_program')==$mvalue['id'] || isset($franchises_info['name']) && $franchises_info['id'] == $mvalue['id'])selected="selected" @endif >{{$mvalue['name']}}</option>
                                                        @endforeach
                                                    @endif
                                                </select>
                                                @if ($errors->has('master_program'))
                                                    <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('master_program') }}</strong>
                                                        </span>
                                                @endif
                                            </div>
                                                    </div></div>

                                                <div class="col-sm-12">
                                                    <div class="row">
                                                        <div class="form-group col-sm-12">
                                                    <input name="program_level" value="@if(isset($lead['program_level'])){{$lead['program_level']}}@else{{old('program_level')}}@endif" class="form-control {{ $errors->has('program_level') ? ' is-invalid' : '' }}" placeholder="Enter Program Level" type="text" id="">
                                                    @if ($errors->has('program_level'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('program_level') }}</strong>
                                                        </span>
                                                    @endif
                                                </div>
                                                    </div></div>


                                            </div>
                                        </div>
                                    </div>

                                </div>
                                <div class="form-group row gutters">
                                    <div class="col-sm-3 mx-auto">
                                        <button type="submit" class="btn btn-primary btn-lg btn-block">Add Master Program Level</button>
                                    </div>
                                </div>

                            </form>
                            <!-- Row end -->
                            <div class="row">
                                <div class="col-md-8 mx-auto col-sm-12 listofprogramlevel" id="listofprogramlevel">



                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


        </div>
        <!-- END: .main-content -->
    </div>
    <!-- END: .app-main -->
@endsection
@section('javascript')
    <script>

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $('#master_program').change(function(e) {
        e.preventDefault(); // does not go through with the link.
        var tt = $(this,'option:selected').val();
        $.post({
        type:'POST',
        data: {'id':$(this).val(),'masterId' :  $('#master_program ,option:selected').val()},
        url: "{{ route('getlevellist') }}"
        }).done(function (data) {
        $('#listofprogramlevel').html(data.program_list);

        });
    });
    </script>


    <script src="{{ URL::asset('js/toastr.min.js')}}" type="text/javascript"></script>
    <script src="{{ URL::asset('js/ui-toastr.min.js')}}" type="text/javascript"></script>
    <!-- If using flash()->important() or flash()->overlay(), you'll need to pull in the JS for Twitter Bootstrap. -->

    @if (session()->has('flash_notification'))
        <script>
            jQuery( document ).ready(function() {
                @foreach (session('flash_notification', collect())->toArray() as $message)

                toastr.<?php echo ($message['level'] == 'danger')?'error':$message['level']; ?>('<?php echo $message['message'];?>');
                @endforeach
            });


        </script>

    @endif




@endsection