@extends('layouts.app')

@section('content')

    <!-- BEGIN .app-main -->
    <div class="app-main">
        <!-- BEGIN .main-heading -->
        <header class="main-heading">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-xl-8 col-lg-8 col-md-8 col-sm-8">
                        <div class="page-icon">
                            <i class="icon-layers"></i>
                        </div>
                        <div class="page-title">
                            <h5>Student Registration</h5>
                            <h6 class="sub-heading">Welcome to Amma</h6>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4">
                        <div class="right-actions">
                            <a href="#" class="btn btn-primary float-right" data-toggle="tooltip" data-placement="left" title="Download Reports">
                                <i class="icon-download4"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <!-- END: .main-heading -->
        <!-- BEGIN .main-content -->
        <div class="main-content">
            <form method="POST" action="{{ url('/admin/students/store-program') }}">
            @csrf
         
            <div class="row gutters">
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                    <!-- Row start -->
                    <div class="row gutters">
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                            <div class="card">
                                <div class="card-body">
                                    <div class="row gutters">
                                        <div class="col-md-8 mx-auto col-sm-12">
                                            <div class="row">
                                                <div class="form-group col-sm-4">
                                                    <label for="">Master Franchisee</label>
                                                    <select class="form-control    {{ $errors->has('masterFranchisesId') ? ' is-invalid' : '' }}" name="masterFranchisesId" id="franchisee_code">
                                                    <option value="">Select</option>
                                                    @if(!empty($masterfranchisess))
                                                    @foreach($masterfranchisess as $mf)
                                                        <option value="{{ $mf->id}}">{{ $mf->master_franchisee_code}}</option>
                                                    @endforeach   
                                                    @endif
                                                    </select>
                                                    @if ($errors->has('masterFranchisesId'))
                                                    <span class="invalid-feedback">
                                                        <strong>{{ $errors->first('masterFranchisesId') }}</strong>
                                                    </span>
                                                    @endif
                                                </div>
                                                <div class="form-group col-sm-4 ">
                                                    <label for="">Franchisee Code</label>
                                                    <select class="form-control {{ $errors->has('franchisesId') ? ' is-invalid' : '' }}" id="franchise" name="franchisesId">
                                                        <option value="">Select</option>
                                                    </select>
                                                    @if ($errors->has('franchisesId'))
                                                    <span class="invalid-feedback">
                                                        <strong>{{ $errors->first('franchisesId') }}</strong>
                                                    </span>
                                                    @endif
                                                </div>
                                                <div class="form-group col-sm-4">
                                                    <label for="">Centre</label>
                                                    <select class="form-control  {{ $errors->has('centreCode') ? ' is-invalid' : '' }} " id="centreCode" name="centreCode">
                                                        <option value="">Select Centre</option>
                                                    </select>
                                                    @if ($errors->has('centreCode'))
                                                    <span class="invalid-feedback">
                                                        <strong>{{ $errors->first('centreCode') }}</strong>
                                                    </span>
                                                    @endif
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <div class="row gutters">
                                                    <div class="col">
                                                        <input class="form-control {{ $errors->has('registration_no') ? ' is-invalid' : '' }}" placeholder="Student registration number" type="text" name="registration_no" id="registration_no">
                                                         @if ($errors->has('registration_no'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('registration_no') }}</strong>
                                                        </span>
                                                    @endif
                                                    </div>
                                                    <div class="col">
                                                        <button type="submit" class="btn btn-primary" id="get-details">Get Details</button>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group" id="student_details">
                                                <div class="row gutters">
                                                    <div class="col">
                                                        <label for="">Registration Date</label>
                                                    </div>
                                                    <div class="col" id="rg_date"></div>
                                                </div>
                                                <div class="row gutters">
                                                    <div class="col">
                                                        <label for="">Name</label>
                                                    </div>
                                                   <div class="col" id="name"></div>
                                                </div>
                                                <div class="row gutters">
                                                    <div class="col">
                                                        <label for="">DOB, Age</label>
                                                    </div>
                                                   <div class="col" id="dob"></div>
                                                </div>
                                                <div class="row gutters">
                                                    <div class="col">
                                                        <label for="">Parent Name</label>
                                                    </div>
                                                   <div class="col" id="parentName"></div>
                                                </div>
                                                <div class="row gutters">
                                                    <div class="col">
                                                        <label for="">Contact number</label>
                                                    </div>
                                                   <div class="col" id="contact_num"></div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="form-group col-sm-6">
                                                    <label for="">Program</label>
                                                    <select id="master_program" class="form-control {{ $errors->has('program') ? ' is-invalid' : '' }}" name="program">


                                                        <option value="">Select Program</option>

                                                        @if($programmasters)
                                                            @foreach($programmasters as $value)

                                                        <option value="{{$value['id']}}">{{$value['name']}}</option>

                                                            @endforeach

                                                        @endif

                                                    </select>
                                                     @if ($errors->has('program'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('program') }}</strong>
                                                        </span>
                                                    @endif
                                                </div>
                                                <div class="form-group col-sm-6">
                                                    <label for="">Level</label>
                                                    <select class="form-control {{ $errors->has('label') ? ' is-invalid' : '' }}" name="label" id="listofprogramlevel">
                                                        <option value="">Select Level</option>

                                                    </select>
                                                     @if ($errors->has('label'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('label') }}</strong>
                                                        </span>
                                                    @endif
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="form-group col-sm-4">
                                                    <label for="">Class Day</label>
                                                        <select class="form-control  {{ $errors->has('class_day') ? ' is-invalid' : '' }}" name="class_day">
                                                            <option value="">Select Day</option>
                                                            <option value="Sunday">Sunday</option>
                                                            <option value="Monday">Monday</option>
                                                            <option value="Tuesday">Tuesday</option>
                                                            <option value="Wednesday">Wednesday</option>
                                                            <option value="Thursday">Thursday</option>
                                                            <option value="Friday">Friday</option>
                                                            <option value="Saturday">Saturday</option>
                                                        </select>
                                                         @if ($errors->has('class_day'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('class_day') }}</strong>
                                                        </span>
                                                    @endif
                                                    </div>
                                                    <div class="form-group col-sm-4">
                                                        <label for="">Time Slot</label>
                                                        <select class="form-control {{ $errors->has('time_slot') ? ' is-invalid' : '' }}" name="time_slot">
                                                            <option value="">Select Time Slot</option>
                                                            <option value="9am to 11am">9am to 11am</option>
                                                            <option value="11am to 1pm">11am to 1pm</option>
                                                            <option value="2pm to 4pm">2pm to 4pm</option>
                                                            <option value="4pm to 6pm">4pm to 6pm</option>
                                                            <option value="6pm to 8pm">6pm to 8pm</option>
                                                        </select>
                                                         @if ($errors->has('time_slot'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('time_slot') }}</strong>
                                                        </span>
                                                    @endif
                                                    </div>
                                                    <div class="form-group col-sm-4">
                                                        <label for="">Faculty Name</label>
                                                        <select class="form-control {{ $errors->has('faculty_name') ? ' is-invalid' : '' }}" id="faculty_name" name="faculty_name">
                                                            <option value="">Select Faculty</option>
                                                            
                                                        </select>
                                                         @if ($errors->has('faculty_name'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('faculty_name') }}</strong>
                                                        </span>
                                                    @endif
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group row gutters">
                                        <div class="col-sm-3 mx-auto">
                                            <button type="submit" class="btn btn-primary btn-lg btn-block">Submit</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Row end -->
                </div>
            </div>
            </form>
            
        </div>
        <!-- END: .main-content -->
    </div>
    <!-- END: .app-main -->
@endsection

@section('javascript')

    <script>
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
         $('#franchisee_code').change(function(e) {
        e.preventDefault(); // does not go through with the link.
        var tt = $(this,'option:selected').val();
        $.post({
            type:'POST',
            data: {'masterId':$(this).val()},
            url: "{{ route('getFranchisee') }}"
        }).done(function (data) {
            $('#franchise').html(data);            
           
        });
    });
    $('#franchise').change(function(e) {
        e.preventDefault(); // does not go through with the link.
        var tt = $(this,'option:selected').val();
        $.post({
            type:'POST',
            data: {'id':$(this).val(),'masterId' :  $('#franchisee_code ,option:selected').val()},
            url: "{{ route('getcenter') }}"
        }).done(function (data) {
            $('#centreCode').html(data);            
           
        });
    });
        $('#get-details').on('click',function(e) {
            e.preventDefault(); // does not go through with the link.
            var registration_no = $('#registration_no').val();
            $.post({
                type:'POST',
                data:registration_no,
                url: '/admin/students/ajaxRequest'
            }).done(function (data) {
               $('#student_details').html(data);
                //console.log(data);
                //location.reload();
            });
        });


        $('#master_program').change(function(e) {
            e.preventDefault(); // does not go through with the link.
            var tt = $(this,'option:selected').val();
            $.post({
                type:'POST',
                data: {'id':$(this).val(),'program_id' :  $('#master_program ,option:selected').val()},
                url: "{{ route('getprogramlevel') }}"
            }).done(function (data) {
                $('#listofprogramlevel').html(data);

            });
        });

        $('#centreCode').change(function(e) {
            e.preventDefault(); // does not go through with the link.
            var tt = $(this,'option:selected').val();
            $.post({
                type:'POST',
                data: {'id':$(this).val(),'centreCode' :  $('#centreCode ,option:selected').val()},
                url: "{{ route('centergetfaculty') }}"
            }).done(function (data) {
                $('#faculty_name').html(data);

            });
        });
    </script>

@endsection