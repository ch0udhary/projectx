@extends('layouts.app')

@section('content')

    <!-- BEGIN .app-main -->
    <div class="app-main">
        <!-- BEGIN .main-heading -->
        <header class="main-heading">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-xl-8 col-lg-8 col-md-8 col-sm-8">
                        <div class="page-icon">
                            <i class="icon-layers"></i>
                        </div>
                        <div class="page-title">
                            <h5>Student Registration</h5>
                            <h6 class="sub-heading">Welcome to Amma</h6>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4">
                        <div class="right-actions">
                            <a href="#" class="btn btn-primary float-right" data-toggle="tooltip" data-placement="left" title="Download Reports">
                                <i class="icon-download4"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <!-- END: .main-heading -->
        <!-- BEGIN .main-content -->
        <div class="main-content">
            <?php //echo '<pre>'; print_r($franchises_info); echo '</pre>'; ?>
            @if(isset($student_info))
                <form method="POST" action="{{ url('/admin/students/'.$student_info['id']) }}" enctype="multipart/form-data">
                    @method('PUT')
                    @else
                        <form method="POST" action="{{ url('/admin/students/') }}" enctype="multipart/form-data">
                            @endif
                            @csrf
            <div class="row gutters">

                <div class="col-md-12 col-sm-12">
                    <!-- Row start -->
                    <div class="row gutters">
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                            <div class="card">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="form-group col-sm-4">
                                        <label for="">Master Franchisee</label>
                                        <select class="form-control {{ $errors->has('level') ? ' is-invalid' : '' }}" name="masterFranchisesId" id="franchisee_code">
                                        <option value="">Select</option>
                                        @if(!empty($masterfranchisess))
                                        @foreach($masterfranchisess as $mf)
                                            <option value="{{ $mf->id}}" @if(isset($student_info['master_franchisee_id']) && $student_info['master_franchisee_id'] == $mf->id )selected="selected" @endif>{{ $mf->master_franchisee_code}}</option>
                                        @endforeach   
                                        @endif
                                        </select>
                                        @if ($errors->has('masterFranchisesId'))
                                        <span class="invalid-feedback">
                                            <strong>{{ $errors->first('masterFranchisesId') }}</strong>
                                        </span>
                                        @endif
                                    </div>
                                    <div class="form-group col-sm-4 ">
                                        <label for="">Franchisee Code</label>
                                        <select class="form-control {{ $errors->has('franchisesId') ? ' is-invalid' : '' }}" id="franchise" name="franchisesId">
                                            <option value="@if(isset($student_info['franchisee_id'])){{$student_info['franchisee_id']}}@else{{''}}@endif">@if(isset($franchises_info['name'])){{$franchises_info['name']}}@else{{'select'}}@endif</option>
                                        </select>
                                        @if ($errors->has('franchisesId'))
                                        <span class="invalid-feedback">
                                            <strong>{{ $errors->first('franchisesId') }}</strong>
                                        </span>
                                        @endif
                                    </div>
                                    <div class="form-group col-sm-4 {{ $errors->has('centreCode') ? ' is-invalid' : '' }}">
                                        <label for="">Centre</label>
                                        <select class="form-control " id="centreCode" name="centreCode">
                                            <option value="@if(isset($student_info['centre_id'])){{$student_info['centre_id']}}@else{{''}}@endif">@if(isset($Centres_name['centre_name'])){{$Centres_name['centre_name']}}@else{{'select'}}@endif</option>
                                        </select>
                                         @if ($errors->has('centreCode'))
                                        <span class="invalid-feedback">
                                            <strong>{{ $errors->first('centreCode') }}</strong>
                                        </span>
                                        @endif
                                    </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Row end -->
                </div>
                <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                    <!-- Row start -->
                    <div class="row gutters">
                        <?php
                           // echo "<pre>";
                           // print_r($student_info);
                        ?>
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                            <div class="card">
                                <div class="card-header">Student Registration</div>
                                <div class="card-body">
                                    <div class="form-group">
                                        <label for="">Registration No.</label>
                                        <input name="registration_no" type="text" value="@if(isset($student_info['registration_no'])){{$student_info['registration_no']}}@else{{old('registration_no')}}@endif" class="form-control {{ $errors->has('registration_no') ? ' is-invalid' : '' }}" id="" placeholder="6945">
                                        @if ($errors->has('registration_no'))
                                            <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('registration_no') }}</strong>
                                                        </span>
                                        @endif
                                    </div>
                                    <div class="form-group">
                                        <label for="">Registration Date</label>
                                        <input type="date" name="registration_date"  value="@if(isset($student_info['registration_date'])){{$student_info['registration_date']}}@else{{old('registration_date')}}@endif" class="form-control {{ $errors->has('registration_date') ? ' is-invalid' : '' }}" id="" >
                                        @if ($errors->has('registration_date'))
                                            <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('registration_date') }}</strong>
                                                        </span>
                                        @endif
                                    </div>
                                    <div class="form-group">
                                        <label class="custom-file">Student Photo</label>
                                        <input id="file2" name="student_photo" class="form-control {{ $errors->has('student_photo') ? ' is-invalid' : '' }}" type="file">
                                        @if ($errors->has('student_photo'))
                                            <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('student_photo') }}</strong>
                                                        </span>
                                        @endif
                                    </div>
                                    <div class="form-group">
                                        <label for="">Name</label>
                                        <input type="text" name="name"  value="@if(isset($student_info['name'])){{$student_info['name']}}@else{{old('name')}}@endif" class="form-control {{ $errors->has('name') ? ' is-invalid' : '' }}" id="" placeholder="Anand Kumar Joshi">
                                        @if ($errors->has('name'))
                                            <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('name') }}</strong>
                                                        </span>
                                        @endif
                                    </div>
                                    <div class="form-group">
                                        <label for="">Date of Birth, Age</label>
                                        <input type="date" name="dob"  value="@if(isset($student_info['dob'])){{$student_info['dob']}}@else{{old('dob')}}@endif" class="form-control {{ $errors->has('dob') ? ' is-invalid' : '' }}" id="">
                                        @if ($errors->has('dob'))
                                            <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('dob') }}</strong>
                                                        </span>
                                        @endif
                                    </div>
                                    <div class="form-group">
                                        <label for="">Address</label>
                                        <textarea name="address"  class="form-control {{ $errors->has('address') ? ' is-invalid' : '' }}" id="" rows="2" placeholder="2563, WEA, Karol Bagh"> @if(isset($student_info['address'])){{$student_info['address']}}@else{{old('address')}}@endif</textarea>
                                        @if ($errors->has('address'))
                                            <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('address') }}</strong>
                                                        </span>
                                        @endif
                                    </div>
                                    <div class="form-group">
                                        <label for="">City</label>
                                        <input name="city" type="text"  value="@if(isset($student_info['city'])){{$student_info['city']}}@else{{old('city')}}@endif" class="form-control {{ $errors->has('city') ? ' is-invalid' : '' }}" id="" placeholder="New Delhi" >
                                        @if ($errors->has('city'))
                                            <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('city') }}</strong>
                                                        </span>
                                        @endif
                                    </div>
                                    <div class="form-group row">
                                        <div class="col">
                                            <label for="">State</label>
                                            <input name="state" type="text"  value="@if(isset($student_info['state'])){{$student_info['state']}}@else{{old('state')}}@endif" class="form-control {{ $errors->has('state') ? ' is-invalid' : '' }}" id="" placeholder="Delhi" >
                                            @if ($errors->has('state'))
                                                <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('state') }}</strong>
                                                        </span>
                                            @endif
                                        </div>
                                        <div class="col">
                                            <label for="">PIN</label>
                                            <input name="pin" type="text"  value="@if(isset($student_info['pin'])){{$student_info['pin']}}@else{{old('pin')}}@endif" class="form-control {{ $errors->has('pin') ? ' is-invalid' : '' }}" id="" placeholder="110055" >
                                            @if ($errors->has('pin'))
                                                <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('pin') }}</strong>
                                                        </span>
                                            @endif
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="">Contact Tel No.</label>
                                        <input type="text" name="contact_tel_no"  value="@if(isset($student_info['contact_tel_no'])){{$student_info['contact_tel_no']}}@else{{old('contact_tel_no')}}@endif" class="form-control {{ $errors->has('contact_tel_no') ? ' is-invalid' : '' }}" id="" placeholder="011 65905983" >
                                        @if ($errors->has('contact_tel_no'))
                                            <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('contact_tel_no') }}</strong>
                                                        </span>
                                        @endif
                                    </div>
                                    <div class="form-group">
                                        <label for="">Male / Female</label>
                                        <select name="gender" class="form-control {{ $errors->has('gender') ? ' is-invalid' : '' }}">
                                            <option  value="">Select Gender</option>
                                            <option value="male" @if(isset($student_info['gender']) && $student_info['gender'] =='male'){{'selected'}}@endif>Male</option>
                                            <option value="female" @if(isset($student_info['gender']) && $student_info['gender'] =='female'){{'selected'}}@endif>Female</option>
                                        </select>
                                        @if ($errors->has('gender'))
                                            <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('gender') }}</strong>
                                                        </span>
                                        @endif
                                    </div>
                                    <div class="form-group">
                                        <label for="">School Name</label>
                                        <input name="school_name" type="text"  value="@if(isset($student_info['school_name'])){{$student_info['school_name']}}@else{{old('school_name')}}@endif" class="form-control {{ $errors->has('school_name') ? ' is-invalid' : '' }}" id="" placeholder="Salwan Public School">
                                        @if ($errors->has('school_name'))
                                            <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('school_name') }}</strong>
                                                        </span>
                                        @endif
                                    </div>
                                    <div class="form-group">
                                        <label for="">School Address</label>
                                        <input name="school_address" type="text"  value="@if(isset($student_info['school_address'])){{$student_info['school_address']}}@else{{old('school_address')}}@endif" class="form-control {{ $errors->has('school_address') ? ' is-invalid' : '' }}" id="" placeholder="101, Old Rajinder" >
                                        @if ($errors->has('school_address'))
                                            <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('school_address') }}</strong>
                                                        </span>
                                        @endif
                                    </div>
                                    <div class="form-group">
                                        <label for="">City</label>
                                        <input type="text" name="school_city" value="@if(isset($student_info['school_city'])){{$student_info['school_city']}}@else{{old('school_city')}}@endif" class="form-control {{ $errors->has('school_city') ? ' is-invalid' : '' }}" id="" placeholder="New Delhi" >
                                        @if ($errors->has('school_city'))
                                            <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('school_city') }}</strong>
                                                        </span>
                                        @endif
                                    </div>
                                    <div class="form-group row">
                                        <div class="col">
                                            <label for="">State</label>
                                            <input name="school_state" type="text"  value="@if(isset($student_info['school_state'])){{$student_info['school_state']}}@else{{old('school_state')}}@endif" class="form-control {{ $errors->has('school_state') ? ' is-invalid' : '' }}" id="" placeholder="Delhi" >
                                            @if ($errors->has('school_state'))
                                                <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('school_state') }}</strong>
                                                        </span>
                                            @endif
                                        </div>
                                        <div class="col">
                                            <label for="">PIN</label>
                                            <input type="text" name="school_pin"  value="@if(isset($student_info['school_pin'])){{$student_info['school_pin']}}@else{{old('school_pin')}}@endif" class="form-control {{ $errors->has('school_pin') ? ' is-invalid' : '' }}" id="" placeholder="110055" >
                                            @if ($errors->has('school_pin'))
                                                <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('school_pin') }}</strong>
                                                        </span>
                                            @endif
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="">Standard/Class</label>
                                        <input type="text" name="class"  value="@if(isset($student_info['class'])){{$student_info['class']}}@else{{old('class')}}@endif" class="form-control {{ $errors->has('class') ? ' is-invalid' : '' }}" id="" placeholder="2nd" >
                                        @if ($errors->has('class'))
                                            <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('class') }}</strong>
                                                        </span>
                                        @endif
                                    </div>
                                    <div class="form-group">
                                        <label for="">Hobby1</label>
                                        <input name="hobby_1" type="text"  value="@if(isset($student_info['hobby_1'])){{$student_info['hobby_1']}}@else{{old('hobby_1')}}@endif" class="form-control {{ $errors->has('hobby_1') ? ' is-invalid' : '' }}" id="" placeholder="Keyboard" >
                                        @if ($errors->has('hobby_1'))
                                            <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('hobby_1') }}</strong>
                                                        </span>
                                        @endif
                                    </div>
                                    <div class="form-group">
                                        <label for="">Hobby2</label>
                                        <input name="hobby_2" type="text"  value="@if(isset($student_info['hobby_2'])){{$student_info['hobby_2']}}@else{{old('hobby_2')}}@endif" class="form-control {{ $errors->has('hobby_2') ? ' is-invalid' : '' }}" id="" placeholder="Karate" >
                                        @if ($errors->has('hobby_2'))
                                            <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('hobby_2') }}</strong>
                                                        </span>
                                        @endif
                                    </div>
                                    <div class="form-group">
                                        <label for="">Hobby3</label>
                                        <input name="hobby_3" type="text"  value="@if(isset($student_info['hobby_3'])){{$student_info['hobby_3']}}@else{{old('hobby_3')}}@endif" class="form-control {{ $errors->has('hobby_3') ? ' is-invalid' : '' }}" id="" placeholder="" >
                                        @if ($errors->has('hobby_3'))
                                            <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('hobby_3') }}</strong>
                                                        </span>
                                        @endif
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Row end -->
                </div>
                <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                    <!-- Row start -->
                    <div class="row gutters">
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                            <div class="card">
                                <div class="card-header">Parent Detail</div>
                                <div class="card-body">
                                    <div class="form-group">
                                        <label for="">Father's Name Title</label>
                                        <select name="ftitle" class="form-control {{ $errors->has('ftitle') ? ' is-invalid' : '' }}">
                                            <option  value="">Select</option>
                                            <option value="Dr" @if(isset($parentDetails['ftitle']) && $parentDetails['ftitle'] =='Dr'){{'selected'}}@endif>Dr.</option>
                                            <option value="Mr" @if(isset($parentDetails['ftitle']) && $parentDetails['ftitle'] =='Mr'){{'selected'}}@endif>Mr.</option>
                                        </select>
                                        @if ($errors->has('ftitle'))
                                            <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('ftitle') }}</strong>
                                                        </span>
                                        @endif
                                    </div>
                                    <div class="form-group">
                                        <label for="">Father's Name</label>
                                        <input type="text" name="fathers_name"  value="@if(isset($parentDetails['fathers_name'])){{$parentDetails['fathers_name']}}@else{{old('fathers_name')}}@endif" class="form-control {{ $errors->has('fathers_name') ? ' is-invalid' : '' }}" id="" placeholder="Sushil Kumar Joshi">
                                        @if ($errors->has('fathers_name'))
                                            <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('fathers_name') }}</strong>
                                                        </span>
                                        @endif
                                    </div>
                                    <div class="form-group">
                                        <label for="">Occupation </label>
                                        <input type="text" name="fathers_occupation"   value="@if(isset($parentDetails['fathers_occupation'])){{$parentDetails['fathers_occupation']}}@else{{old('fathers_occupation')}}@endif" class="form-control {{ $errors->has('fathers_occupation') ? ' is-invalid' : '' }}" id="" placeholder="Service (service, self-employed, business, housewife)">
                                        @if ($errors->has('fathers_occupation'))
                                            <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('fathers_occupation') }}</strong>
                                                        </span>
                                        @endif
                                    </div>
                                    <div class="form-group">
                                        <label for="">Office Address</label>
                                        <textarea name="fathers_office_address" class="form-control {{ $errors->has('fathers_office_address') ? ' is-invalid' : '' }}" id="" rows="2"  placeholder="Shastri Bhawan, Dr.Rajendra Prasad Road"> @if(isset($parentDetails['fathers_office_address'])){{$parentDetails['fathers_office_address']}}@else{{old('fathers_office_address')}}@endif</textarea>
                                        @if ($errors->has('fathers_office_address'))
                                            <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('fathers_office_address') }}</strong>
                                                        </span>
                                        @endif
                                    </div>
                                    <div class="form-group">
                                        <label for="">City</label>
                                        <input name="fathers_city" type="text"  value="@if(isset($parentDetails['fathers_city'])){{$parentDetails['fathers_city']}}@else{{old('fathers_city')}}@endif" class="form-control {{ $errors->has('fathers_city') ? ' is-invalid' : '' }}" id="" placeholder="New Delhi" >
                                        @if ($errors->has('fathers_city'))
                                            <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('fathers_city') }}</strong>
                                                        </span>
                                        @endif
                                    </div>
                                    <div class="form-group row">
                                        <div class="col">
                                            <label for="">State</label>
                                            <input name="fathers_state"  value="@if(isset($parentDetails['fathers_state'])){{$parentDetails['fathers_state']}}@else{{old('fathers_state')}}@endif"class="form-control {{ $errors->has('fathers_state') ? ' is-invalid' : '' }}" placeholder="Delhi" type="text">
                                            @if ($errors->has('fathers_state'))
                                                <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('fathers_state') }}</strong>
                                                        </span>
                                            @endif
                                        </div>
                                        <div class="col">
                                            <label for="">PIN</label>
                                            <input name="fathers_pin"  value="@if(isset($parentDetails['fathers_pin'])){{$parentDetails['fathers_pin']}}@else{{old('fathers_pin')}}@endif" class="form-control {{ $errors->has('fathers_pin') ? ' is-invalid' : '' }}" placeholder="110014" type="text">
                                            @if ($errors->has('fathers_pin'))
                                                <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('fathers_pin') }}</strong>
                                                        </span>
                                            @endif
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="">Office Tel.No.</label>
                                        <input name="fathers_office_tel_no"  value="@if(isset($parentDetails['fathers_office_tel_no'])){{$parentDetails['fathers_office_tel_no']}}@else{{old('fathers_office_tel_no')}}@endif" type="text" class="form-control {{ $errors->has('fathers_office_tel_no') ? ' is-invalid' : '' }}" id="" placeholder="011 25752763">
                                        @if ($errors->has('fathers_office_tel_no'))
                                            <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('fathers_office_tel_no') }}</strong>
                                                        </span>
                                        @endif
                                    </div>
                                    <div class="form-group">
                                        <label for="">Mobile No.</label>
                                        <input name="fathers_mobile_no"  value="@if(isset($parentDetails['fathers_mobile_no'])){{$parentDetails['fathers_mobile_no']}}@else{{old('fathers_mobile_no')}}@endif" type="text" class="form-control {{ $errors->has('fathers_mobile_no') ? ' is-invalid' : '' }}" id="" placeholder="9310394263">
                                        @if ($errors->has('fathers_mobile_no'))
                                            <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('fathers_mobile_no') }}</strong>
                                                        </span>
                                        @endif
                                    </div>
                                    <div class="form-group">
                                        <label for="">Email ID</label>
                                        <input name="fathers_email"  value="@if(isset($parentDetails['fathers_email'])){{$parentDetails['fathers_email']}}@else{{old('fathers_email')}}@endif" type="email" class="form-control {{ $errors->has('fathers_email') ? ' is-invalid' : '' }}" id="" placeholder="skj@gmail.com">
                                        @if ($errors->has('fathers_email'))
                                            <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('fathers_email') }}</strong>
                                                        </span>
                                        @endif
                                    </div>
                                    <div class="form-group">
                                        <label for="">Mother's Name Title</label>
                                        <select name="mtitle" class="form-control {{ $errors->has('mtitle') ? ' is-invalid' : '' }}">
                                            <option  value="">Select</option>
                                            <option value="Dr" @if(isset($parentDetails['mtitle']) && $parentDetails['mtitle'] =='Dr'){{'selected'}}@endif>Dr.</option>
                                            <option value="Miss" @if(isset($parentDetails['mtitle']) && $parentDetails['mtitle'] =='Miss'){{'selected'}}@endif>Miss.</option>
                                        </select>
                                        @if ($errors->has('mtitle'))
                                            <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('mtitle') }}</strong>
                                                        </span>
                                        @endif
                                    </div>
                                    <div class="form-group">
                                        <label for="">Mother's Name</label>
                                        <input name="mothers_name" value="@if(isset($parentDetails['mothers_name'])){{$parentDetails['mothers_name']}}@else{{old('mothers_name')}}@endif" type="text" class="form-control {{ $errors->has('mothers_name') ? ' is-invalid' : '' }}" id="" placeholder=" Rekha Joshi">
                                        @if ($errors->has('mothers_name'))
                                            <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('mothers_name') }}</strong>
                                                        </span>
                                        @endif
                                    </div>
                                    <div class="form-group">
                                        <label for="">Occupation</label>
                                        <input name="mothers_occupation"  value="@if(isset($parentDetails['mothers_occupation'])){{$parentDetails['mothers_occupation']}}@else{{old('mothers_occupation')}}@endif" type="text" class="form-control {{ $errors->has('mothers_occupation') ? ' is-invalid' : '' }}" id="" placeholder="Self-employed">
                                        @if ($errors->has('mothers_occupation'))
                                            <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('mothers_occupation') }}</strong>
                                                        </span>
                                        @endif
                                    </div>
                                    <div class="form-group">
                                        <label for="">Office Address</label>
                                        <input name="mothers_office_address"  value="@if(isset($parentDetails['mothers_office_address'])){{$parentDetails['mothers_office_address']}}@else{{old('mothers_office_address')}}@endif" type="text" class="form-control {{ $errors->has('mothers_office_address') ? ' is-invalid' : '' }}" id="" placeholder="2563, WEA Karol Bagh">
                                        @if ($errors->has('mothers_office_address'))
                                            <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('mothers_office_address') }}</strong>
                                                        </span>
                                        @endif
                                    </div>
                                    <div class="form-group">
                                        <label for="">City</label>
                                        <input  name="mothers_city" value="@if(isset($parentDetails['mothers_city'])){{$parentDetails['mothers_city']}}@else{{old('mothers_city')}}@endif" type="text" class="form-control {{ $errors->has('mothers_city') ? ' is-invalid' : '' }}" id="" placeholder="New Delhi" >
                                        @if ($errors->has('mothers_city'))
                                            <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('mothers_city') }}</strong>
                                                        </span>
                                        @endif
                                    </div>
                                    <div class="form-group row">
                                        <div class="col">
                                            <label for="">State</label>
                                            <input name="mothers_state"  value="@if(isset($parentDetails['mothers_state'])){{$parentDetails['mothers_state']}}@else{{old('mothers_state')}}@endif" class="form-control {{ $errors->has('mothers_state') ? ' is-invalid' : '' }}" placeholder="Delhi" type="text">
                                            @if ($errors->has('mothers_state'))
                                                <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('mothers_state') }}</strong>
                                                        </span>
                                            @endif
                                        </div>
                                        <div class="col">
                                            <label for="">PIN</label>
                                            <input name="mothers_pin"  value="@if(isset($parentDetails['mothers_pin'])){{$parentDetails['mothers_pin']}}@else{{old('mothers_pin')}}@endif" class="form-control {{ $errors->has('mothers_pin') ? ' is-invalid' : '' }}" placeholder="110014" type="text">
                                            @if ($errors->has('mothers_pin'))
                                                <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('mothers_pin') }}</strong>
                                                        </span>
                                            @endif
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="">Office Tel.No.</label>
                                        <input name="mothers_office_tel_no"  value="@if(isset($parentDetails['mothers_office_tel_no'])){{$parentDetails['mothers_office_tel_no']}}@else{{old('mothers_office_tel_no')}}@endif" type="text" class="form-control {{ $errors->has('mothers_office_tel_no') ? ' is-invalid' : '' }}" id="" placeholder="011 25752763">
                                        @if ($errors->has('mothers_office_tel_no'))
                                            <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('mothers_office_tel_no') }}</strong>
                                                        </span>
                                        @endif
                                    </div>
                                    <div class="form-group">
                                        <label for="">Mobile No.</label>
                                        <input name="mothers_mobile_no"  value="@if(isset($parentDetails['mothers_mobile_no'])){{$parentDetails['mothers_mobile_no']}}@else{{old('mothers_mobile_no')}}@endif" type="text" class="form-control {{ $errors->has('mothers_mobile_no') ? ' is-invalid' : '' }}" id="" placeholder="9313318230">
                                        @if ($errors->has('mothers_mobile_no'))
                                            <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('mothers_mobile_no') }}</strong>
                                                        </span>
                                        @endif
                                    </div>
                                    <div class="form-group">
                                        <label for="">Email ID</label>
                                        <input name="mothers_email" value="@if(isset($parentDetails['mothers_email'])){{$parentDetails['mothers_email']}}@else{{old('mothers_email')}}@endif" type="email" class="form-control {{ $errors->has('mothers_email') ? ' is-invalid' : '' }}" id="" placeholder="rekhajoshi@gmail.com">
                                        @if ($errors->has('mothers_email'))
                                            <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('mothers_email') }}</strong>
                                                        </span>
                                        @endif
                                    </div>
                                    <div class="form-group">
                                        <label for="">Referred by (Friends, Advertisement, Internet, etc.)</label>
                                        <input name="referred_by"  value="@if(isset($parentDetails['referred_by'])){{$parentDetails['referred_by']}}@else{{old('referred_by')}}@endif" type="text" class="form-control {{ $errors->has('referred_by') ? ' is-invalid' : '' }}" id="" placeholder="Internet">
                                        @if ($errors->has('referred_by'))
                                            <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('referred_by') }}</strong>
                                                        </span>
                                        @endif
                                    </div>
                                    <div class="form-group">
                                        <label for="">Purpose of enrollment</label>
                                        <input name="purpose_of_enrollment"  value="@if(isset($parentDetails['purpose_of_enrollment'])){{$parentDetails['purpose_of_enrollment']}}@else{{old('purpose_of_enrollment')}}@endif" type="text" class="form-control {{ $errors->has('purpose_of_enrollment') ? ' is-invalid' : '' }}" id="" placeholder="Improvement in mathematics, confidence">
                                        @if ($errors->has('purpose_of_enrollment'))
                                            <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('purpose_of_enrollment') }}</strong>
                                                        </span>
                                        @endif
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Row end -->
                </div>
            </div>
            <div class="form-group row gutters">
                <div class="col-sm-3 mx-auto">
                    <button type="submit" class="btn btn-primary btn-lg btn-block">Submit</button>
                </div>
            </div>
                        </form>

        </div>
        <!-- END: .main-content -->
    </div>
    <!-- END: .app-main -->
@endsection

@section('javascript')

    <script>
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
       $('#franchisee_code').change(function(e) {
        e.preventDefault(); // does not go through with the link.
        var tt = $(this,'option:selected').val();
        $.post({
            type:'POST',
            data: {'masterId':$(this).val()},
            url: "{{ route('getFranchisee') }}"
        }).done(function (data) {
            $('#franchise').html(data);            
           
        });
    });
    $('#franchise').change(function(e) {
        e.preventDefault(); // does not go through with the link.
        var tt = $(this,'option:selected').val();
        $.post({
            type:'POST',
            data: {'id':$(this).val(),'masterId' :  $('#franchisee_code ,option:selected').val()},
            url: "{{ route('getcenter') }}"
        }).done(function (data) {
            $('#centreCode').html(data);            
           
        });
    });
      
    </script>
@endsection