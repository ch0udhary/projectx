@extends('layouts.app')

@section('content')
<div class="app-main">
    <!-- BEGIN .main-heading -->
    <header class="main-heading">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xl-8 col-lg-8 col-md-8 col-sm-8">
                    <div class="page-icon">
                        <i class="icon-layers"></i>
                    </div>
                    <div class="page-title">
                        <h5>Generate Receipt</h5>
                        <h6 class="sub-heading">Welcome to Amma</h6>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4">
                    <div class="right-actions">
                        <!-- <a href="#" class="btn btn-primary float-right" data-toggle="tooltip" data-placement="left" title="Download Reports">
                            <i class="icon-download4"></i>
                        </a> -->
                    </div>
                </div>
            </div>
        </div>
    </header>
<!-- BEGIN .main-content -->
<div class="main-content">
@if (\Session::has('success'))
    <div class="alert alert-success">
        <ul>
            <li>{!! \Session::get('success') !!}</li>
        </ul>
    </div>
@endif
@if (\Session::has('error'))
    <div class="alert alert-danger">
        <ul>
            <li>{!! \Session::get('error') !!}</li>
        </ul>
    </div>
@endif
 <!-- Row start -->
<div class="row gutters">
    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
        <!-- Row start -->
        <div class="row gutters">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                <div class="card">
                    <div class="card-body">
                        <form method="post" action="{{ route('applyCertificate') }}">
                        @csrf
                        <div class="row gutters">
                            <div class="col-md-8 mx-auto col-sm-12">
                                <div class="row">
                                    <div class="form-group col-sm-4">
                                        <label for="">Master Franchisee</label>
                                        <select class="form-control    {{ $errors->has('level') ? ' is-invalid' : '' }}" name="masterFranchisesId" id="franchisee_code">
                                        <option selected value="">Select</option>
                                        @if(!empty($masterfranchisess))
                                        @foreach($masterfranchisess as $mf)
                                            <option value="{{ $mf->id}}">{{ $mf->master_franchisee_code}}</option>
                                        @endforeach   
                                        @endif
                                        </select>
                                        @if ($errors->has('masterFranchisesId'))
                                        <span class="invalid-feedback">
                                            <strong>{{ $errors->first('masterFranchisesId') }}</strong>
                                        </span>
                                        @endif
                                    </div>
                                    <div class="form-group col-sm-4 ">
                                        <label for="">Franchisee Code</label>
                                        <select class="form-control {{ $errors->has('franchisesId') ? ' is-invalid' : '' }}" id="franchise" name="franchisesId">
                                            <option selected value="">Select</option>
                                            
                                        </select>
                                        @if ($errors->has('franchisesId'))
                                        <span class="invalid-feedback">
                                            <strong>{{ $errors->first('franchisesId') }}</strong>
                                        </span>
                                        @endif
                                    </div>
                                    <div class="form-group col-sm-4 {{ $errors->has('centreCode') ? ' is-invalid' : '' }}">
                                        <label for="">Centre</label>
                                        <select class="form-control " id="centreCode" name="centreCode">
                                            <option selected>Select Centre</option>
                                            
                                        </select>
                                        @if ($errors->has('centreCode'))
                                        <span class="invalid-feedback">
                                            <strong>{{ $errors->first('centreCode') }}</strong>
                                        </span>
                                        @endif
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="row gutters">
                                        <div class="col">
                                            <input class="form-control" placeholder="Student registration number" type="text" id="regnumber">
                                        </div>
                                        <div class="col">
                                            <button type="button" class="btn btn-primary" id="getDetails">Get Details</button>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group studentDeatils">
                                 
                                </div> 
                                <div class="row">
                                    <div class="form-group col-sm-6 ">
                                        <label for="">Date of completion</label>
                                        <input class="form-control {{ $errors->has('dateCompletion') ? ' is-invalid' : '' }}" placeholder="" type="date" name="dateCompletion">
                                        @if ($errors->has('dateCompletion'))
                                        <span class="invalid-feedback">
                                            <strong>{{ $errors->first('dateCompletion') }}</strong>
                                        </span>
                                        @endif
                                    </div>
                                    <div class="form-group col-sm-6">
                                        <label for="">Certificate Date</label>
                                        <input class="form-control {{ $errors->has('certificateDate') ? ' is-invalid' : '' }}" placeholder="" type="date" name="certificateDate">
                                        @if ($errors->has('certificateDate'))
                                        <span class="invalid-feedback">
                                            <strong>{{ $errors->first('dateCompletion') }}</strong>
                                        </span>
                                        @endif
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="form-group col-sm-6">
                                        <label for="">Marks Obtained</label>
                                        <input class="form-control {{ $errors->has('obtainMarks') ? ' is-invalid' : '' }}" placeholder="80" type="text" name="obtainMarks">
                                        @if ($errors->has('obtainMarks'))
                                        <span class="invalid-feedback">
                                            <strong>{{ $errors->first('obtainMarks') }}</strong>
                                        </span>
                                        @endif
                                    </div>
                                    <div class="form-group col-sm-6">
                                        <label for="">Out of</label>
                                        <input class="form-control {{ $errors->has('outOf') ? ' is-invalid' : '' }}" placeholder="100" type="text" name="outOf">
                                        @if ($errors->has('outOf'))
                                        <span class="invalid-feedback">
                                            <strong>{{ $errors->first('outOf') }}</strong>
                                        </span>
                                        @endif
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="form-group col-sm-6">
                                        <label for="">Grade Obtained</label>
                                        <select class="form-control    {{ $errors->has('gradeObtain') ? ' is-invalid' : '' }}" name="gradeObtain" id="gradeObtain">
                                        <option selected value="">Select</option>
                                        @if(!empty($grade_master_details))
                                        @foreach($grade_master_details as $mf)
                                            <option value="{{ $mf->id}}">{{ $mf['grade']}}</option>
                                        @endforeach   
                                        @endif
                                        </select>
                                        @if ($errors->has('gradeObtain'))
                                        <span class="invalid-feedback">
                                            <strong>{{ $errors->first('gradeObtain') }}</strong>
                                        </span>
                                        @endif
                                    </div>
                                   <!--  <div class="form-group col-sm-6">
                                        <label for="">Certificate Status</label>
                                        <input class="form-control {{ $errors->has('certificateStatus') ? ' is-invalid' : '' }}" placeholder="OK/PENDING" type="text" name="certificateStatus">
                                        @if ($errors->has('certificateStatus'))
                                        <span class="invalid-feedback">
                                            <strong>{{ $errors->first('certificateStatus') }}</strong>
                                        </span>
                                        @endif
                                    </div> -->
                                </div>
                                <div class="form-group">
                                    <label for="">Parent's Feedback For the Level</label>
                                    <textarea class="form-control {{ $errors->has('parentsFeedback') ? ' is-invalid' : '' }}" placeholder="Write your feedback" rows="4" name="parentsFeedback"></textarea>
                                    @if ($errors->has('parentsFeedback'))
                                    <span class="invalid-feedback">
                                        <strong>{{ $errors->first('parentsFeedback') }}</strong>
                                    </span>
                                    @endif
                                </div>
                            </div>
                        </div>
                        <div class="form-group row gutters">
                            <div class="col-sm-3 mx-auto">
                                <button type="submit" class="btn btn-primary btn-lg btn-block">Apply To Certificate</button>
                            </div>
                        </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!-- Row end -->
    </div>
</div>
<!-- Row ends -->   
    
    
</div>
<!-- END: .main-content -->
</div>
@endsection
@section('javascript')

<script>
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    $('#franchisee_code').change(function(e) {
        e.preventDefault(); // does not go through with the link.
        var tt = $(this,'option:selected').val();
        $.post({
            type:'POST',
            data: {'masterId':$(this).val()},
            url: "{{ route('getFranchisee') }}"
        }).done(function (data) {
            $('#franchise').html(data);            
           
        });
    });
    $('#franchise').change(function(e) {
        e.preventDefault(); // does not go through with the link.
        var tt = $(this,'option:selected').val();
        $.post({
            type:'POST',
            data: {'id':$(this).val(),'masterId' :  $('#franchisee_code ,option:selected').val()},
            url: "{{ route('getcenter') }}"
        }).done(function (data) {
            $('#centreCode').html(data);            
           
        });
    });
    $('#getDetails').on('click',function(e) {
        e.preventDefault(); // does not go through with the link.
        if($.trim($('#regnumber').val()) == ''){
            alert("Please Enter Registration Number.")
        }
        var tt = $('#regnumber').val();
        $.post({
            type:'POST',
            data: {'regNo':$('#regnumber').val()},
            url: "{{ route('getstudent') }}"
        }).done(function (data) {
            $('.studentDeatils').html(data);            
           
        });
    });
</script>


@endsection