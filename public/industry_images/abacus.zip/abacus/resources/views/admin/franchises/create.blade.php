@extends('layouts.app')

@section('content')



    {{--@if(count($errors) > 0)

                          <div class="alert alert-default" role="alert">
                              @foreach ($errors->all() as $message)
                                  <p>{!! $message !!}</p>
                              @endforeach
                          </div>
                      @endif--}}

    <!-- BEGIN .app-main -->

    <div class="app-main">
        <!-- BEGIN .main-heading -->
        <header class="main-heading">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-xl-8 col-lg-8 col-md-8 col-sm-8">
                        <div class="page-icon">
                            <i class="icon-layers"></i>
                        </div>
                        <div class="page-title">
                            <h5>Add Franchise</h5>
                            <h6 class="sub-heading">Welcome to Amma</h6>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4">
                        <div class="right-actions">
                            <a href="#" class="btn btn-primary float-right" data-toggle="tooltip" data-placement="left" title="Download Reports">
                                <i class="icon-download4"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <!-- END: .main-heading -->
        <!-- BEGIN .main-content -->
        <div class="main-content">
            <div class="row gutters">
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                    <!-- Row start -->
                    <div class="row gutters">
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                            @if(isset($franchises_info))
                                 <form method="POST" action='{{ url("/admin/franchises/".$franchises_info['id']) }}'>
                                     @method('PUT')
                              @else
                                 <form method="POST" action="{{ url('/admin/franchises/') }}">
                            @endif
                                @csrf
                                <div class="card">
                                    <div class="card-body">
                                        <div class="row gutters">
                                            <div class="col-md-8 mx-auto col-sm-12">
                                                <div class="row">
                                                    <div class="form-group col-sm-4">
                                                        <label for="">Master Franchisee Code</label>
                                                        <select name="master_franchisee_code" class="form-control {{ $errors->has('master_franchisee_code') ? ' is-invalid' : '' }}">
                                                            <option value="" >Select Master Franchisee</option>
                                                            @if(isset($masterfranchisess))
                                                                @foreach($masterfranchisess as $mvalue)
                                                                    <option value="{{$mvalue['id']}}" @if(old('master_franchisee_code')==$mvalue['id'] || isset($franchises_info['master_franchisee_id']) && $franchises_info['master_franchisee_id'] == $mvalue['id'])selected="selected" @endif >{{$mvalue['master_franchisee_code']}}</option>
                                                                @endforeach
                                                            @endif
                                                        </select>
                                                        @if ($errors->has('master_franchisee_code'))
                                                            <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('master_franchisee_code') }}</strong>
                                                        </span>
                                                        @endif
                                                    </div>
                                                    <div class="form-group col-sm-4">
                                                        <label for="">Franchisee Code</label>
                                                        <input name="franchisee_code" value="@if(isset($franchises_info['franchisee_code'])){{$franchises_info['franchisee_code']}} @else {{old('franchisee_code')}} @endif" type="text" class="form-control {{ $errors->has('franchisee_code') ? ' is-invalid' : '' }}" id="franchisee_code" placeholder="DL/0058 (state short code, running number)">
                                                        @if ($errors->has('franchisee_code'))
                                                            <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('franchisee_code') }}</strong>
                                                        </span>
                                                        @endif
                                                    </div>
                                                    <div class="form-group col-sm-4">
                                                        <label for="">Date of Agreement</label>
                                              {{--          {{Carbon\Carbon::parse($franchises_info['date_of_agreement'])->format('m-d-Y')}}--}}
                                                        <input  value="@if(isset($franchises_info['date_of_agreement'])){{$franchises_info['date_of_agreement']}}@else{{old('date_of_agreement') }}@endif" name="date_of_agreement" type="date" class="form-control {{ $errors->has('date_of_agreement') ? ' is-invalid' : '' }}" id="date_of_agreement" >
                                                        @if ($errors->has('date_of_agreement'))
                                                            <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('date_of_agreement') }}</strong>
                                                        </span>
                                                        @endif
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="form-group col-sm-6">
                                                        <label for="">Name of Organisation/Name</label>
                                                        <input type="text" value="@if(isset($franchises_info['name'])){{$franchises_info['name']}}  @else {{old('name')}}@endif" name="name" class="form-control {{ $errors->has('name') ? ' is-invalid' : '' }}" id="name" placeholder="Krishna Coaching Centre" >
                                                        @if ($errors->has('name'))
                                                            <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('name') }}</strong>
                                                        </span>
                                                        @endif
                                                    </div>
                                                    <div class="form-group col-sm-6">
                                                        <label for="">Date of Establishment/Date of Birth</label>
                                                        <input value="@if(isset($franchises_info['date_of_establishment'])){{$franchises_info['date_of_establishment']}}@else{{old('date_of_establishment')}}@endif" name="date_of_establishment" type="date" class="form-control {{ $errors->has('date_of_establishment') ? ' is-invalid' : '' }}" id="date_of_establishment" >
                                                        @if ($errors->has('date_of_establishment'))
                                                            <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('date_of_establishment') }}</strong>
                                                        </span>
                                                        @endif
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label for="">Address</label>
                                                    <input value="@if(isset($franchises_info['address'])){{$franchises_info['address']}}@else{{old('address')}}@endif" name="address" class="form-control {{ $errors->has('address') ? ' is-invalid' : '' }}" type="text"placeholder="101, Janak puri West">
                                                    @if ($errors->has('address'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('address') }}</strong>
                                                        </span>
                                                    @endif
                                                </div>
                                                <div class="row">
                                                    <div class="form-group col-sm-4">
                                                        <label for="">City</label>
                                                        <input value="@if(isset($franchises_info['city'])){{$franchises_info['city']}}@else{{old('city')}}@endif" name="city" class="form-control {{ $errors->has('city') ? ' is-invalid' : '' }}" type="text"placeholder="New Delhi">
                                                        @if ($errors->has('city'))
                                                            <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('city') }}</strong>
                                                        </span>
                                                        @endif
                                                    </div>
                                                    <div class="form-group col-sm-4">
                                                        <label for="">State</label>
                                                        <input value="@if(isset($franchises_info['state'])){{$franchises_info['state']}}@else{{old('state')}}@endif" name="state" class="form-control {{ $errors->has('state') ? ' is-invalid' : '' }}" placeholder="Delhi" type="text">
                                                        @if ($errors->has('state'))
                                                            <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('state') }}</strong>
                                                        </span>
                                                        @endif
                                                    </div>
                                                    <div class="form-group col-sm-4">
                                                        <label for="">PIN</label>
                                                        <input value="@if(isset($franchises_info['pin'])){{$franchises_info['pin']}}@else{{old('pin')}}@endif" name="pin" class="form-control {{ $errors->has('pin') ? ' is-invalid' : '' }}" placeholder="110014" type="text">
                                                        @if ($errors->has('pin'))
                                                            <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('pin') }}</strong>
                                                        </span>
                                                        @endif
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="form-group col-sm-4">
                                                        <label for="">Office/Home Phone No.</label>
                                                        <input value="@if(isset($franchises_info['phone_no'])){{$franchises_info['phone_no']}}@else{{old('phone_no')}}@endif" name="phone_no" type="text" class="form-control {{ $errors->has('phone_no') ? ' is-invalid' : '' }}" id="phone_no" placeholder="011 25752763" >
                                                        @if ($errors->has('phone_no'))
                                                            <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('phone_no') }}</strong>
                                                        </span>
                                                        @endif
                                                    </div>
                                                    <div class="form-group col-sm-4">
                                                        <label for="">Mobile No.</label>
                                                        <input value="@if(isset($franchises_info['mobile_no'])){{$franchises_info['mobile_no']}}@else{{old('mobile_no')}}@endif" name="mobile_no" type="text" class="form-control {{ $errors->has('mobile_no') ? ' is-invalid' : '' }}" id="mobile_no" placeholder="9212252763" >
                                                        @if ($errors->has('mobile_no'))
                                                            <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('mobile_no') }}</strong>
                                                        </span>
                                                        @endif
                                                    </div>
                                                    <div class="form-group col-sm-4">
                                                        <label for="">Email ID</label>
                                                        <input value="@if(isset($franchises_info['email'])){{$franchises_info['email']}}@else{{old('email')}}@endif" name="email" type="email" class="form-control {{ $errors->has('email') ? ' is-invalid' : '' }}" id="email" placeholder="info@ammaindia.com">
                                                        @if ($errors->has('email'))
                                                            <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('email') }}</strong>
                                                        </span>
                                                        @endif
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label for="">Education, if individual</label>
                                                    <input name="education"  value="@if(isset($franchises_info['education'])){{$franchises_info['education']}}@else{{old('education')}}@endif" type="text" class="form-control {{ $errors->has('education') ? ' is-invalid' : '' }}" id="education" placeholder="B.A., B.Ed." >
                                                    @if ($errors->has('education'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('education') }}</strong>
                                                        </span>
                                                    @endif
                                                </div>
                                                <div class="row">
                                                    <div class="form-group col-sm-6">
                                                        <label for="">Years Experience in Teaching</label>
                                                        <input value="@if(isset($franchises_info['years_experience_in_teaching'])){{$franchises_info['years_experience_in_teaching']}}@else{{old('years_experience_in_teaching')}}@endif" name="years_experience_in_teaching" type="text" class="form-control {{ $errors->has('years_experience_in_teaching') ? ' is-invalid' : '' }}" id="years_experience_in_teaching" placeholder="5 years" >
                                                        @if ($errors->has('years_experience_in_teaching'))
                                                            <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('years_experience_in_teaching') }}</strong>
                                                        </span>
                                                        @endif
                                                    </div>
                                                    <div class="form-group col-sm-6">
                                                        <label for="">Years Experience in Business</label>
                                                        <input  value="@if(isset($franchises_info['years_experience_in_business'])){{$franchises_info['years_experience_in_business']}}@else{{old('years_experience_in_business')}}@endif" name="years_experience_in_business" type="text" class="form-control {{ $errors->has('years_experience_in_business') ? ' is-invalid' : '' }}" id="years_experience_in_business" placeholder="15 years (n/a for individual)" >
                                                        @if ($errors->has('years_experience_in_business'))
                                                            <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('years_experience_in_business') }}</strong>
                                                        </span>
                                                        @endif
                                                    </div>
                                                </div>
                                                <div class="row">
                                                     <div class="form-group col-sm-6">
                                                        <label for="">Licensed Territory</label>
                                                        <input  value="@if(isset($franchises_info['licensed_territory'])){{$franchises_info['licensed_territory']}}@else{{old('licensed_territory')}}@endif" type="text" name="licensed_territory" class="form-control  {{ $errors->has('licensed_territory') ? ' is-invalid' : '' }}" id="" placeholder="Patel Nagar" >
                                                        @if ($errors->has('licensed_territory'))
                                                            <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('licensed_territory') }}</strong>
                                                        </span>
                                                        @endif
                                                    </div>
                                                    <div class="form-group col-sm-6">
                                                        <label for="">PIN Code</label>
                                                        <input  value="@if(isset($franchises_info['pin_code'])){{$franchises_info['pin_code']}}@else{{old('pin_code')}}@endif" type="text" name="pin_code" class="form-control  {{ $errors->has('pin_code') ? ' is-invalid' : '' }}" id="" placeholder="110008" >
                                                        @if ($errors->has('pin_code'))
                                                            <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('pin_code') }}</strong>
                                                        </span>
                                                        @endif
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="form-group col-sm-4">
                                                        <label for="">License Certificate No.</label>
                                                        <input value="@if(isset($franchises_info['license_certificate_no'])){{$franchises_info['license_certificate_no']}}@else{{old('license_certificate_no')}}@endif" name="license_certificate_no" type="text" class="form-control  {{ $errors->has('license_certificate_no') ? ' is-invalid' : '' }}" id="license_certificate_no" placeholder="115" >
                                                        @if ($errors->has('license_certificate_no'))
                                                            <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('license_certificate_no') }}</strong>
                                                        </span>
                                                        @endif
                                                    </div>
                                                    <div class="form-group col-sm-4">
                                                        <label for="">License Period from</label>
                                                        <input  value="@if(isset($franchises_info['license_period_from'])){{$franchises_info['license_period_from']}}@else{{old('license_period_from')}}@endif" name="license_period_from" type="date" class="form-control  {{ $errors->has('license_period_from') ? ' is-invalid' : '' }}" id="	license_period_from" placeholder="" >
                                                        @if ($errors->has('license_period_from'))
                                                            <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('license_period_from') }}</strong>
                                                        </span>
                                                        @endif
                                                    </div>
                                                    <div class="form-group col-sm-4">
                                                        <label for="">License Period to</label>
                                                        <input  value="@if(isset($franchises_info['license_period_to'])){{$franchises_info['license_period_to']}}@else{{old('license_period_to')}}@endif" name="license_period_to" type="date" class="form-control  {{ $errors->has('license_period_to') ? ' is-invalid' : '' }}" id="license_period_to" placeholder="" >
                                                        @if ($errors->has('license_period_to'))
                                                            <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('license_period_to') }}</strong>
                                                        </span>
                                                        @endif
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="form-group col-sm-4">
                                                        <label for="">Franchisee License Fee</label>
                                                        <input  value="@if(isset($franchises_info['franchisee_license_fee'])){{$franchises_info['franchisee_license_fee']}}@else{{old('franchisee_license_fee')}}@endif" name="franchisee_license_fee" type="text" class="form-control  {{ $errors->has('franchisee_license_fee') ? ' is-invalid' : '' }}" id="franchisee_license_fee" placeholder="Rs.30,000/-" >
                                                        @if ($errors->has('franchisee_license_fee'))
                                                            <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('franchisee_license_fee') }}</strong>
                                                        </span>
                                                        @endif
                                                    </div>
                                                    <div class="form-group col-sm-4">
                                                        <label for="">License Fee Receipt No</label>
                                                        <input  value="@if(isset($franchises_info['license_fee_receipt_no'])){{$franchises_info['license_fee_receipt_no']}}@else{{old('license_fee_receipt_no')}}@endif" name="license_fee_receipt_no" type="text" class="form-control  {{ $errors->has('license_fee_receipt_no') ? ' is-invalid' : '' }}" id="license_fee_receipt_no" placeholder="0533" >
                                                        @if ($errors->has('license_fee_receipt_no'))
                                                            <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('license_fee_receipt_no') }}</strong>
                                                        </span>
                                                        @endif
                                                    </div>
                                                    <div class="form-group col-sm-4">
                                                        <label for="">Receipt Date</label>
                                                        <input  value="@if(isset($franchises_info['receipt_date'])){{$franchises_info['receipt_date']}}@else{{old('receipt_date')}}@endif" name="receipt_date" type="date" class="form-control  {{ $errors->has('receipt_date') ? ' is-invalid' : '' }}" id="receipt_date" placeholder="" >
                                                        @if ($errors->has('receipt_date'))
                                                            <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('receipt_date') }}</strong>
                                                        </span>
                                                        @endif
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="form-group col-sm-4">
                                                        <label for="">Renewal Fee</label>
                                                        <input  value="@if(isset($franchises_info['renewal_fee'])){{$franchises_info['renewal_fee']}}@else{{old('renewal_fee')}}@endif" name="renewal_fee" type="text" class="form-control  {{ $errors->has('renewal_fee') ? ' is-invalid' : '' }}" id="renewal_fee" placeholder="Rs.10,000/-">
                                                        @if ($errors->has('renewal_fee'))
                                                            <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('renewal_fee') }}</strong>
                                                        </span>
                                                        @endif
                                                    </div>
                                                    <div class="form-group col-sm-4">
                                                        <label for="">Renewed Period from</label>
                                                        <input  value="@if(isset($franchises_info['renewed_period_from'])){{$franchises_info['renewed_period_from']}}@else{{old('renewed_period_from')}}@endif" name="renewed_period_from" type="date" class="form-control  {{ $errors->has('renewed_period_from') ? ' is-invalid' : '' }}" id="renewed_period_from" placeholder="">
                                                        @if ($errors->has('renewed_period_from'))
                                                            <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('renewed_period_from') }}</strong>
                                                        </span>
                                                        @endif
                                                    </div>
                                                    <div class="form-group col-sm-4">
                                                        <label for="">Renewed Period to</label>
                                                        <input  value="@if(isset($franchises_info['renewed_period_to'])){{$franchises_info['renewed_period_to']}}@else{{old('renewed_period_to')}}@endif" name="renewed_period_to" type="date" class="form-control  {{ $errors->has('renewed_period_to') ? ' is-invalid' : '' }}" id="renewed_period_to" placeholder="">
                                                        @if ($errors->has('renewed_period_to'))
                                                            <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('renewed_period_to') }}</strong>
                                                        </span>
                                                        @endif
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="form-group col-sm-6">
                                                        <label for="">Royalty</label>
                                                        <input  value="@if(isset($franchises_info['royalty'])){{$franchises_info['royalty']}}@else{{old('royalty')}}@endif" name="royalty" type="text" class="form-control  {{ $errors->has('royalty') ? ' is-invalid' : '' }}" id="royalty" placeholder="25% of course fees" >
                                                        @if ($errors->has('royalty'))
                                                            <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('royalty') }}</strong>
                                                        </span>
                                                        @endif
                                                    </div>
                                                    <div class="form-group col-sm-6">
                                                        <label for="">Material Discount</label>
                                                        <input  value="@if(isset($franchises_info['material_discount'])){{$franchises_info['material_discount']}}@else{{old('material_discount')}}@endif" name="material_discount" type="text" class="form-control  {{ $errors->has('material_discount') ? ' is-invalid' : '' }}" id="material_discount" placeholder="" >
                                                        @if ($errors->has('material_discount'))
                                                            <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('material_discount') }}</strong>
                                                        </span>
                                                        @endif
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group row gutters">
                                            <div class="col-sm-3 mx-auto">
                                                <button type="submit" class="btn btn-primary btn-lg btn-block">Submit</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <!-- Row end -->
                </div>

            </div>


        </div>
        <!-- END: .main-content -->
    </div>
    <!-- END: .app-main -->
@endsection