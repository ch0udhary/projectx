@extends('layouts.app')
@section('stylesheet')
    <link href="{{ URL::asset('vendor/datatables/dataTables.bs4.css')}}" rel="stylesheet" type="text/css" />
    <link href="{{ URL::asset('vendor/datatables/dataTables.bs4-custom.css')}}" rel="stylesheet">
@endsection
@section('content')
<div class="app-main">
    <!-- BEGIN .main-heading -->
    <header class="main-heading">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xl-8 col-lg-8 col-md-8 col-sm-8">
                    <div class="page-icon">
                        <i class="icon-layers"></i>
                    </div>
                    <div class="page-title">
                        <h5>Fees Master</h5>
                        <h6 class="sub-heading">Welcome to Amma</h6>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4">
                    <div class="right-actions">
                        <!-- <a href="#" class="btn btn-primary float-right" data-toggle="tooltip" data-placement="left" title="Download Reports">
                            <i class="icon-download4"></i>
                        </a> -->
                    </div>
                </div>
            </div>
        </div>
    </header>
<!-- BEGIN .main-content -->
<div class="main-content">
@if (\Session::has('success'))
    <div class="alert alert-success">
        <ul>
            <li>{!! \Session::get('success') !!}</li>
        </ul>
    </div>
@endif
@if (\Session::has('error'))
    <div class="alert alert-danger">
        <ul>
            <li>{!! \Session::get('error') !!}</li>
        </ul>
    </div>
@endif
<!-- Row start -->
    <div class="row gutters">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
            <div class="card">
                <div class="card-header">Students Fee List</div>
                <div class="card-body">
                    <form method="post" action="{{ route('purchase-challan.store') }}">
                    @csrf
                    <div class="row gutters">
                        <div class="col-md-6 col-sm-12">
                            <div class="form-group">
                                <label for="">Challan No.</label>
                                <input class="form-control {{ $errors->has('challan_number') ? ' is-invalid' : '' }}" placeholder="10" type="text" name="challan_number">
                                @if ($errors->has('challan_number'))
                                <span class="invalid-feedback">
                                    <strong>{{ $errors->first('challan_number') }}</strong>
                                </span>
                                @endif
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-12">
                            <div class="form-group">
                                <label for="">Challan Date</label>
                                <input class="form-control" placeholder="" type="date" name="challan_date">
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-12">
                            <div class="form-group">
                                <label for="">Supplier Bill No.</label>
                                <input class="form-control {{ $errors->has('supplier_bill_no') ? ' is-invalid' : '' }}" placeholder="DL00123" type="text" name="supplier_bill_no">
                                @if ($errors->has('supplier_bill_no'))
                                <span class="invalid-feedback">
                                    <strong>{{ $errors->first('supplier_bill_no') }}</strong>
                                </span>
                                @endif
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-12">
                            <div class="form-group">
                                <label for="">Supplier's Name</label>
                                <select class="form-control" name="supplier_name">
                                     <option>Supplier's Name</option>
                                     <option>Mr. Sushil Kumar Joshi</option>
                                     <option>Mr. Sushil Kumar Joshi</option>
                                     <option>Mr. Sushil Kumar Joshi</option>
                                     <option>Mr. Sushil Kumar Joshi</option>
                                </select>
                            </div>
                        </div>
                        <input type="hidden" name="itemcount" id="itemcount" value="1">
                        <div class="col-md-12 col-sm-12">
                            <table id="challanTable" width="100%" border="0" cellspacing="0" cellpadding="0" class="table table-striped table-bordered">
                                <tr>
                                  <th width="30%">Item</th>
                                  <th width="10%">Quantity</th>
                                  <th width="20%">Purchase Price</th>
                                  <th width="20%">Amount</th>
                                  <th width="20%">Action</th>
                                </tr>
                                <tr>
                                  <td><input class="form-control" placeholder="Item" type="text" name="item_code[]"></td>
                                  <td><input class="form-control" placeholder="10" type="text" name="quantity[]"></td>
                                  <td><input class="form-control" placeholder="Purchase Price" type="text" name="purchase_price[]"></td>
                                  <td><input class="form-control" placeholder="Amount" type="text" name="amount[]"></td>
                                  <td><button type="button" class="delete btn btn-secondary btn-sm">Delete</button></td>
                                </tr>
                            </table>
                            <table id="" width="100%" border="0" cellspacing="0" cellpadding="0" class="table table-striped table-bordered">
                                <tr>
                                  <th width="30%">Total</th>
                                  <th width="30%">10</th>
                                  <th width="40%">Rs 3500/-</th>
                                </tr>
                            </table>
                            <div class="form-group row gutters">
                                <div class="col-sm-10">
                                    <button type="button" class="add-row btn btn-primary">Add Item</button>
                                </div>
                            </div>
                            <div class="form-group row gutters">
                                <div class="col-sm-3 mx-auto">
                                    <button type="submit" class="btn btn-primary btn-lg btn-block">Submit</button>
                                </div>
                            </div>
                        </div>
                    </div>

                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- Row ends -->    
    
</div>
<!-- END: .main-content -->
</div>
@endsection

@section('javascript')

<script>
    $('document').ready(function() {
        $("#itemcount").val(($('#challanTable tr').length-1));
    $('.add-row').click(function() {
    $("#challanTable").append('<tr><td><input class="form-control" placeholder="Item" type="text" name="item_code[]"></td><td><input class="form-control" placeholder="10" type="text"  name="quantity[]"></td><td><input class="form-control" placeholder="Purchase Price" type="text" name="purchase_price[]"></td><td><input class="form-control" placeholder="Amount" type="text" name="amount[]"></td><td><button type="button" class="delete btn btn-secondary btn-sm">Delete</button></td></tr>');
        $("#itemcount").val(($('#challanTable tr').length-1));
    });
    $(document).on('click','button.delete', function() {
      $(this).closest('tr').remove();
      $("#itemcount").val(($('#challanTable tr').length-1));
      return false;
    });
    })
</script>



@endsection