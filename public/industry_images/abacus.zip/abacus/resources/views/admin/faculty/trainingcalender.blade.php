@extends('layouts.app')

@section('content')
<div class="app-main">
    <!-- BEGIN .main-heading -->
    <header class="main-heading">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xl-8 col-lg-8 col-md-8 col-sm-8">
                    <div class="page-icon">
                        <i class="icon-layers"></i>
                    </div>
                    <div class="page-title">
                        <h5>Training Calender</h5>
                        <h6 class="sub-heading">Welcome to Amma</h6>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4">
                    <div class="right-actions">
                        <!-- <a href="#" class="btn btn-primary float-right" data-toggle="tooltip" data-placement="left" title="Download Reports">
                            <i class="icon-download4"></i>
                        </a> -->
                    </div>
                </div>
            </div>
        </div>
    </header>
<!-- BEGIN .main-content -->
<div class="main-content">
@if (\Session::has('success'))
    <div class="alert alert-success">
        <ul>
            <li>{!! \Session::get('success') !!}</li>
        </ul>
    </div>
@endif
@if (\Session::has('error'))
    <div class="alert alert-danger">
        <ul>
            <li>{!! \Session::get('error') !!}</li>
        </ul>
    </div>
@endif
    <div class="row gutters">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
            <!-- Row start -->
            <div class="row gutters">
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                    <div class="card">
                        <div class="card-body">
                            

                            <div class="row gutters">
                                <div class="col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label for="">Master Franchisee</label>
                                        <select class="form-control {{ $errors->has('masterFranchisesId') ? ' is-invalid' : '' }}" name="masterFranchisesId" id="franchisee_code">
                                        <option selected value="">Select</option>
                                        @if(!empty($masterfranchisess))
                                        @foreach($masterfranchisess as $mf)
                                            <option value="{{ $mf->id}}">{{ $mf->master_franchisee_code}}</option>
                                        @endforeach   
                                        @endif
                                        </select>
                                        @if ($errors->has('masterFranchisesId'))
                                        <span class="invalid-feedback">
                                            <strong>{{ $errors->first('masterFranchisesId') }}</strong>
                                        </span> 
                                        @endif
                                    </div>
                                </div>
                                <div class="col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label for="">Centre</label>
                                        <select class="form-control {{ $errors->has('centreCode') ? ' is-invalid' : '' }}" id="centreCode" name="centreCode">
                                            <option selected>Select Centre</option>
                                            
                                        </select>
                                        @if ($errors->has('centreCode'))
                                        <span class="invalid-feedback">
                                            <strong>{{ $errors->first('centreCode') }}</strong>
                                        </span>
                                        @endif
                                    </div>
                                </div>
                                <div class="col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label for="">Faculty</label>
                                        <select class="form-control {{ $errors->has('facultyId') ? ' is-invalid' : '' }}" id="facultyId" name="facultyId">
                                            <option selected>Select Faculty</option>                 
                                        </select>
                                        @if ($errors->has('facultyId'))
                                        <span class="invalid-feedback">
                                            <strong>{{ $errors->first('facultyId') }}</strong>
                                        </span>
                                        @endif
                                    </div>
                                </div>
                                <div class="col-md-12 col-sm-12">
                                    <table id="challanTable" width="100%" border="0" cellspacing="0" cellpadding="0" class="table table-striped table-bordered">
                                        <tr>
                                          <th width="25%">Date</th>
                                          <th width="50%">Program</th>
                                          <th width="25%">Level</th>
                                        </tr>
                                        <tr>
                                          <td>
                                            <form method="post" action="{{ route('training-calender.store') }}">
                                            @csrf
                                          <input class="form-control" placeholder="Date" type="date" name="trainingDate"></td>
                                          <td>
                                            <select class="form-control" id="programId" name="programId">
                                                <option>Select Program</option>
                                                @if(!empty($prlist))
                                                @foreach($prlist as $plist)
                                                <option value="{{ $plist->id }}">{{ $plist->name }}</option>
                                                @endforeach
                                                @endif
                                            </select>
                                          </td>
                                          <td><select class="form-control" id="levellist" name="level">
                                                <option >Select Level</option>
                                                
                                              </select>
                                          </td>
                                        </tr>
                                    </table>
                                    <div class="form-group row gutters">
                                        <div class="col-sm-10">
                                            <button type="submit" class="add-row btn btn-primary">Add Item</button>
                                        </div>
                                    </div>
                                    </form>
                                    <div class="form-group row gutters">
                                        <div class="col-sm-3 mx-auto">
                                            <button type="button" class="btn btn-primary btn-lg btn-block">Submit</button>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-12 col-sm-12">
                                    <table id="" width="100%" border="0" cellspacing="0" cellpadding="0" class="table table-striped table-bordered">
                                        <tr>
                                          <th width="25%">Date</th>
                                          <th width="25%">Program</th>
                                          <th width="25%">Level</th>
                                          <th width="25%">Action</th>
                                        </tr>
                                        @if(!empty($listing))
                                        @foreach($listing as $list)
                                        <tr>
                                          <td>{{ $list->trainingDate }}</td>
                                          <td>{{ $list->program->name }}</td>
                                          <td>{{ $list->level_rel->name }}</td>
                                          <td>
                                          <form method="post" action="{{ route('training-calender.destroy',$list->id) }}" id="deletecalender">
                                            @csrf  
                                            @method('DELETE')
                                          <button type="submit" id="" class="delete btn btn-secondary btn-sm beforedelete">Delete</button></td>
                                          </form>
                                        </tr>
                                        @endforeach
                                        @endif
                                    </table>
                                </div>
                            </div>
                            </form>
                        </div>
                    </div>
                         
                </div>
            </div>
            <!-- Row end -->
        </div>
    </div>
    
    
</div>
<!-- END: .main-content -->
</div>
@endsection

@section('javascript')

<script>
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    $('#franchisee_code').change(function(e) {
        e.preventDefault(); // does not go through with the link.
        var tt = $(this,'option:selected').val();
        $.post({
            type:'POST',
            data: {'masterId':$(this).val()},
            url: "{{ route('getcenter') }}"
        }).done(function (data) {
            $('#centreCode').html(data);            
           
        });
    });
    $('#centreCode').change(function(e) {
        e.preventDefault(); // does not go through with the link.
        var tt = $(this,'option:selected').val();
        $.post({
            type:'POST',
            data: {'centreCode':$(this).val()},
            url: "{{ route('facultylist') }}"
        }).done(function (data) {
            $('#facultyId').html(data);            
           
        });
    });
    $('#programId').change(function(e) {
        e.preventDefault(); // does not go through with the link.
        var tt = $(this,'option:selected').val();
        $.post({
            type:'POST',
            data: {'programId':$(this).val()},
            url: "{{ route('getlevel') }}"
        }).done(function (data) {
            $('#levellist').html(data);            
           
        });
    });
    $('.beforedelete').on('click',function(e){
       
        if(confirm("Are you sure, you want to delete this item ?")){
            $('#deletecalender').submit();
        }else{
             e.preventDefault();
        }
    })
</script>


@endsection