@extends('layouts.app')
@section('stylesheet')
    <link href="{{ URL::asset('vendor/datatables/dataTables.bs4.css')}}" rel="stylesheet" type="text/css" />
    <link href="{{ URL::asset('vendor/datatables/dataTables.bs4-custom.css')}}" rel="stylesheet">
@endsection
@section('content')
<div class="app-main">
    <!-- BEGIN .main-heading -->
    <header class="main-heading">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xl-8 col-lg-8 col-md-8 col-sm-8">
                    <div class="page-icon">
                        <i class="icon-layers"></i>
                    </div>
                    <div class="page-title">
                        <h5>Training Fee</h5>
                        <h6 class="sub-heading">Welcome to Amma</h6>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4">
                    <div class="right-actions">
                        <!-- <a href="#" class="btn btn-primary float-right" data-toggle="tooltip" data-placement="left" title="Download Reports">
                            <i class="icon-download4"></i>
                        </a> -->
                    </div>
                </div>
            </div>
        </div>
    </header>
<!-- BEGIN .main-content -->
<div class="main-content">
@if (\Session::has('success'))
    <div class="alert alert-success">
        <ul>
            <li>{!! \Session::get('success') !!}</li>
        </ul>
    </div>
@endif
@if (\Session::has('error'))
    <div class="alert alert-danger">
        <ul>
            <li>{!! \Session::get('error') !!}</li>
        </ul>
    </div>
@endif
    <div class="row gutters">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
            <!-- Row start -->
            <div class="row gutters">
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                    <div class="card">
                        <div class="card-body">  
                            <div class="row gutters">
                              
                                    <div class="form-group col-sm-6">
                                        <label for="">Master Franchisee</label>
                                        <select class="form-control    {{ $errors->has('level') ? ' is-invalid' : '' }}" name="masterFranchisesId" id="franchisee_code">
                                        <option selected value="">Select</option>
                                        @if(!empty($masterfranchisess))
                                        @foreach($masterfranchisess as $mf)
                                            <option value="{{ $mf->id}}">{{ $mf->master_franchisee_code}}</option>
                                        @endforeach   
                                        @endif
                                        </select>
                                        @if ($errors->has('masterFranchisesId'))
                                        <span class="invalid-feedback">
                                            <strong>{{ $errors->first('masterFranchisesId') }}</strong>
                                        </span>
                                        @endif
                                    </div>
                                    <div class="form-group col-sm-6 {{ $errors->has('centreCode') ? ' is-invalid' : '' }}">
                                        <label for="">Centre</label>
                                        <select class="form-control " id="centreCode" name="centreCode">
                                            <option selected>Select Centre</option>
                                            
                                        </select>
                                        @if ($errors->has('centreCode'))
                                        <span class="invalid-feedback">
                                            <strong>{{ $errors->first('centreCode') }}</strong>
                                        </span>
                                        @endif
                                    </div>
                                    <div class="col-sm-6 form-group">
                                        <label for="">From Date</label>
                                        <input class="form-control" type="date" placeholder="" name="startDate">
                                    </div>
                                    <div class="col-sm-6 form-group">
                                        <label for="">To Date</label>
                                        <input class="form-control" type="date" placeholder="" name="endDate">                                                
                                    </div>
                                   
                                </div>
                            <table id="basicExample" class="table table-list table-striped table-bordered">
                                <thead>
                                    <tr>
                                        <th width="20%">Faculty Name</th>
                                        <th width="15%">Faculty Code</th>
                                        <th width="20%">System Receipt No.</th>
                                        <th width="15%">Receipt Date</th>
                                        <th width="15%">Centre Code</th>
                                        <th width="15%">Fee Amount</th>
                                    </tr>
                                </thead>
                                <tbody>
                                @if(!empty($listing))
                                    @foreach($listing as $list)
                                    <tr>
                                        <td>{{ $list->faculty_detail->facultyName }}</td>
                                        <td>{{ $list->faculty_detail->facultyCode }}</td>
                                        <td>{{ $list->receiptNo }}</td>
                                        <td>{{ $list->receiptDate }}</td>
                                        <td>{{ $list->center_detail->centre_name }}</td>
                                        <td>{{ $list->total }}
                                        <!-- <span class="controls"><a href="#"><i class="fa fa-pencil" aria-hidden="true"></i></a><a href="#"><i class="fa fa-trash-o" aria-hidden="true"></i></a></span> -->
                                        </td>
                                    </tr>
                                    @endforeach
                                @endif
                                    
                                </tbody>
                            </table>

                        </div>
                    </div>
                         
                </div>
            </div>
            <!-- Row end -->
        </div>
    </div>
    
    
</div>
<!-- END: .main-content -->
</div>
@endsection

@section('javascript')
<script src="{{ URL::asset('vendor/datatables/dataTables.min.js')}}" type="text/javascript"></script>
<script src="{{ URL::asset('vendor/datatables/dataTables.bootstrap.min.js')}}" type="text/javascript"></script>
<script src="{{ URL::asset('vendor/datatables/custom/custom-datatables.js')}}" type="text/javascript"></script>
<script>
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    $('#franchisee_code').change(function(e) {
        e.preventDefault(); // does not go through with the link.
        var tt = $(this,'option:selected').val();
        $.post({
            type:'POST',
            data: {'masterId':$(this).val()},
            url: "{{ route('getcenter') }}"
        }).done(function (data) {
            $('#centreCode').html(data);            
           
        });
    });
    $('#centreCode').change(function(e) {
        e.preventDefault(); // does not go through with the link.
        var tt = $(this,'option:selected').val();
        $.post({
            type:'POST',
            data: {'centreCode':$(this).val()},
            url: "{{ route('facultylist') }}"
        }).done(function (data) {
            $('#facultyId').html(data);            
           
        });
    });
    $('#programId').change(function(e) {
        e.preventDefault(); // does not go through with the link.
        var tt = $(this,'option:selected').val();
        $.post({
            type:'POST',
            data: {'programId':$(this).val()},
            url: "{{ route('getlevel') }}"
        }).done(function (data) {
            $('#levellist').html(data);            
           
        });
    });
    $('.beforedelete').on('click',function(e){
       
        if(confirm("Are you sure, you want to delete this item ?")){
            $('#deletecalender').submit();
        }else{
             e.preventDefault();
        }
    })
</script>


@endsection