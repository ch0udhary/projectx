@extends('layouts.app')


@section('content')
    <?php
    $login_user_details = Sentinel::getUser();
    $login_user_details_id = $login_user_details->id;
    //echo '<pre>'; print_r($login_user_details); echo '</pre>';
    $Full_name = $login_user_details->first_name.' '.$login_user_details->last_name;

    ?>

    <!-- BEGIN .app-main -->
    <div class="app-main">
        <!-- BEGIN .main-heading -->
        <header class="main-heading">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-xl-8 col-lg-8 col-md-8 col-sm-8">
                        <div class="page-icon">
                            <i class="icon-layers"></i>
                        </div>
                        <div class="page-title">
                            <h5>Franchisee Details</h5>
                            <h6 class="sub-heading">Welcome to {{$Full_name}}</h6>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4">
                        <div class="right-actions">
                            <a href="#" class="btn btn-primary float-right" data-toggle="tooltip" data-placement="left" title="Download Reports">
                                <i class="icon-download4"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <!-- END: .main-heading -->
        <!-- BEGIN .main-content -->
        <?php //echo '<pre>'; print_r($masterfranchises_info); echo '</pre>'; ?>

        <div class="main-content">
            <div class="row gutters">
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                    <!-- Row start -->
                    <div class="row gutters">
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                            <div class="card">
                                <div class="card-header">Franchisee Details</div>
                                <div class="card-body">
                                    <table class="table table-striped table-bordered">
                                        <tbody>
                                        <tr>
                                            <td width="40%">Master Franchisee Code</td>
                                            <td width="60%">{{$masterfranchises_info['master_franchisee_code']}}</td>
                                        </tr>
                                        <tr>
                                            <td>Franchisee Code</td>
                                            <td>{{$masterfranchises_info['master_franchisee_code']}}</td>
                                        </tr>
                                        <tr>
                                            <td>Date of Agreement</td>
                                            <td>{{$masterfranchises_info['date_of_agreement']}}</td>
                                        </tr>
                                        <tr>
                                            <td>Name of Organisation/Name</td>
                                            <td>{{$masterfranchises_info['name']}}</td>
                                        </tr>
                                        <tr>
                                            <td>Date of Establishment/Date of Birth</td>
                                            <td>{{$masterfranchises_info['date_of_establishment']}}</td>
                                        </tr>
                                        <tr>
                                            <td>Address, City, State, PIN</td>
                                            <td>{{$masterfranchises_info['address']}}, {{$masterfranchises_info['city']}}, {{$masterfranchises_info['state']}}, {{$masterfranchises_info['pin']}}</td>
                                        </tr>
                                        <tr>
                                            <td>Education, if individual</td>
                                            <td>{{$masterfranchises_info['education']}}</td>
                                        </tr>
                                        <tr>
                                            <td>Office Phone No. / Home Phone No.</td>
                                            <td>{{$masterfranchises_info['phone_no']}}</td>
                                        </tr>
                                        <tr>
                                            <td>Mobile No.</td>
                                            <td>{{$masterfranchises_info['mobile_no']}}</td>
                                        </tr>
                                        <tr>
                                            <td>Email ID</td>
                                            <td>{{$masterfranchises_info['email']}}</td>
                                        </tr>
                                        <tr>
                                            <td>Years Experience in Teaching</td>
                                            <td>{{$masterfranchises_info['years_experience_in_teaching']}}</td>
                                        </tr>
                                        <tr>
                                            <td>Years Experience in Business</td>
                                            <td>{{$masterfranchises_info['years_experience_in_business']}}</td>
                                        </tr>
                                        <tr>
                                            <td>Centre Code</td>
                                            <td>{{$masterfranchises_info['centre_code']}}</td>
                                        </tr>
                                        <tr>
                                            <td>Licensed Territory &amp; PIN Code</td>
                                            <td>{{$masterfranchises_info['licensed_territory']}} {{$masterfranchises_info['pin_code']}}</td>
                                        </tr>
                                        <tr>
                                            <td>License Period</td>
                                            <td>3 years from 10 March 2018 to 9 March 2021</td>
                                        </tr>
                                        <tr>
                                            <td>License Certificate No.</td>
                                            <td>{{$masterfranchises_info['license_certificate_no']}}</td>
                                        </tr>
                                        <tr>
                                            <td>Franchisee License Fee</td>
                                            <td>Rs.{{$masterfranchises_info['franchisee_license_fee']}}-</td>
                                        </tr>
                                        <tr>
                                            <td>License Fee Receipt No. &amp Date</td>
                                            <td>{{$masterfranchises_info['license_fee_receipt_no']}}, {{$masterfranchises_info['receipt_date']}}</td>
                                        </tr>
                                        <tr>
                                            <td>Renewal Fee &amp; Renewed Period</td>
                                            <td>Rs.{{$masterfranchises_info['renewal_fee']}}/- {{$masterfranchises_info['renewed_period_from']}} to {{$masterfranchises_info['renewed_period_to']}}</td>
                                        </tr>
                                        <tr>
                                            <td>Royalty</td>
                                            <td>{{$masterfranchises_info['royalty']}}% of course fees</td>
                                        </tr>
                                        <tr>
                                            <td>Material Discount</td>
                                            <td>{{$masterfranchises_info['material_discount']}}%</td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Row end -->
                </div>
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                    <!-- Row start -->
                    <div class="row gutters">
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                            <div class="card">
                                <div class="card-header">Parent Detail</div>
                                <div class="card-body">
                                    <table class="table table-striped table-bordered">
                                        <tbody>
                                        <tr>
                                            <td width="40%">Father's Name</td>
                                            <td width="60%">Mr. Sushil Kumar Joshi</td>
                                        </tr>
                                        <tr>
                                            <td>Occupation</td>
                                            <td>Service</td>
                                        </tr>
                                        <tr>
                                            <td>Office Address</td>
                                            <td>Shastri Bhawan, Dr.Rajendra Prasad Road</td>
                                        </tr>
                                        <tr>
                                            <td>City, State</td>
                                            <td>New Delhi, Delhi, 110001</td>
                                        </tr>
                                        <tr>
                                            <td>Office Tel.No.</td>
                                            <td>011 25752763</td>
                                        </tr>
                                        <tr>
                                            <td>Mobile No.</td>
                                            <td>9310394263</td>
                                        </tr>
                                        <tr>
                                            <td>Email ID</td>
                                            <td>skj@gmail.com</td>
                                        </tr>
                                        <tr>
                                            <td>Mother's Name</td>
                                            <td>Mrs. Rekha Joshi</td>
                                        </tr>
                                        <tr>
                                            <td>Occupation</td>
                                            <td>Self-employed</td>
                                        </tr>
                                        <tr>
                                            <td>Office Address</td>
                                            <td>2563, WEA Karol Bagh</td>
                                        </tr>
                                        <tr>
                                            <td>City, State, PIN</td>
                                            <td>New Delhi, Delhi, 110055</td>
                                        </tr>
                                        <tr>
                                            <td>Office Tel.No.</td>
                                            <td>011 25752763</td>
                                        </tr>
                                        <tr>
                                            <td>Mobile No.</td>
                                            <td>9313318230</td>
                                        </tr>
                                        <tr>
                                            <td>Referred by (Friends, Advertisement, Internet, etc.)</td>
                                            <td>Internet</td>
                                        </tr>
                                        <tr>
                                            <td>Purpose of enrollment</td>
                                            <td>Improvement in mathematics, confidence</td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Row end -->
                </div>
            </div>


        </div>
        <!-- END: .main-content -->
    </div>
    <!-- END: .app-main -->

@endsection