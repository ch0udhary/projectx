<?php

use Faker\Generator as Faker;

$factory->define(App\ProgramLevel::class, function (Faker $faker) {
    return [
        //
    ];
});
