<?php

use Faker\Generator as Faker;

$factory->define(App\MasterFranchises::class, function (Faker $faker) {
    return [
        //
    ];
});
