<?php

use Faker\Generator as Faker;

$factory->define(App\MasterFaculty::class, function (Faker $faker) {
    return [
        //
    ];
});
