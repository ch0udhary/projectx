<?php

use Faker\Generator as Faker;

$factory->define(App\GradeMaster::class, function (Faker $faker) {
    return [
        //
    ];
});
