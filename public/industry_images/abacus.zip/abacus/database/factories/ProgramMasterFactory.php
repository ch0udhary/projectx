<?php

use Faker\Generator as Faker;

$factory->define(App\ProgramMaster::class, function (Faker $faker) {
    return [
        //
    ];
});
