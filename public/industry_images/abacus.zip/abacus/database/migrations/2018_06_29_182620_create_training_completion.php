<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTrainingCompletion extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('training_completions', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('facultyId')->nullable();
            $table->integer('programId')->nullable();
            $table->string('level')->nullable();
            $table->timestamp('completionDate')->nullable();
            $table->timestamp('examDate')->nullable();
            $table->decimal('obtainMarks',10,2)->nullable();
            $table->integer('outOf')->nullable();
            $table->string('trainerName')->nullable();
            $table->string('certificateNo')->nullable();
            $table->timestamp('certificateDate')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('training_completions');
    }
}
