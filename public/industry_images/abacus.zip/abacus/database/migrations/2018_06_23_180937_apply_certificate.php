<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class ApplyCertificate extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('apply_certificates', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('masterFranchisesId')->nullable();
            $table->integer('franchisesId')->nullable();
            $table->string('centreCode')->nullable();
            $table->integer('studentId')->nullable();
            $table->timestamp('dateCompletion')->nullable();
            $table->timestamp('certificateDate')->nullable();
            $table->decimal('obtainMarks',10,2)->nullable();
            $table->integer('outOf')->nullable();
            $table->string('gradeObtain')->nullable();
            $table->string('certificateStatus')->nullable();
            $table->text('parentsFeedback')->nullable();        
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('apply_certificates');
    }
}
