<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateProgram extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('program', function (Blueprint $table) {
            $table->increments('id');
            $table->string('title')->nullable();
            $table->string('lavel_title')->nullable();
            $table->string('class')->nullable();
            $table->string('time_slote')->nullable();
            $table->integer('registration_no')->nullable();
            $table->integer('master_franchises_id')->nullable();
            $table->integer('franchises_id')->nullable();
            $table->integer('centre_id')->nullable();
            $table->integer('faculty_id')->nullable();
            
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('program');
    }
}
