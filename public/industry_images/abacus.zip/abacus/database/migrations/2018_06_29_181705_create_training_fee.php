<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTrainingFee extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('training_fees', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('masterFranchisesId')->nullable();
            $table->integer('franchisesId')->nullable();
            $table->string('centreCode')->nullable();    
            $table->integer('facultyId')->nullable();
            $table->string('receiptNo')->nullable();
            $table->string('manualReceiptNo')->nullable();
            $table->timestamp('receiptDate')->nullable();
            $table->integer('programId')->nullable();
            $table->string('trainingFee')->nullable();
            $table->string('feeConcession')->nullable();
            $table->string('reasonConcession')->nullable();
            $table->string('total')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('training_fees');
    }
}
