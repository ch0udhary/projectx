<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateIssueRequestsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('issue_requests', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('request_no')->nullable();
            $table->timestamp('request_date')->nullable(); 
            $table->string('franchisee_code')->nullable();
            $table->timestamps();
        });
        Schema::create('issue_requests_item', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('request_id')->nullable();
            $table->string('item_code')->nullable();
            $table->integer('quantity')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('issue_requests');
        Schema::dropIfExists('issue_requests_item');
    }
}
