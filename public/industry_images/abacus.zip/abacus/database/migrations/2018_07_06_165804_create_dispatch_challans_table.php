<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateDispatchChallansTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('dispatch_challans', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('request_id')->nullable();
            $table->integer('challan_id')->nullable();
            $table->timestamp('delivery_date')->nullable();
            $table->string('delivery_executive')->nullable();
            $table->timestamps();
        });
        Schema::create('dispatch_challans_item', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('dispatch_id')->nullable();
            $table->string('item')->nullable();
            $table->integer('quantity')->nullable();
            $table->decimal('purchase_price',10,2)->nullable();
            $table->decimal('amount',10,2)->nullable(); 
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('dispatch_challans');
    }
}
