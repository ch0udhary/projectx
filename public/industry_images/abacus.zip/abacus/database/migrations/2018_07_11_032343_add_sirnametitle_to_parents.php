<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddSirnametitleToParents extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        //
		  Schema::table('parents', function($table) {
          $table->string('ftitle')->nullable();
		  $table->string('mtitle')->nullable();
    });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
		 Schema::table('parents', function($table) {
        $table->dropColumn('ftitle');
        $table->dropColumn('mtitle');
    });
    }
}
