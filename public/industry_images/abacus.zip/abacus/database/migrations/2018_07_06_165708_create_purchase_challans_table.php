<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePurchaseChallansTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('purchase_challans', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('user_id')->nullable();
            $table->string('challan_number')->nullable();
            $table->string('supplier_bill_no')->nullable();
            $table->string('supplier_name')->nullable();
            $table->timestamp('challan_date')->nullable();            
            $table->timestamps();
        });

        Schema::create('purchase_challans_item', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('challan_id')->nullable();
            $table->string('item_code')->nullable();
            $table->integer('quantity')->nullable();
            $table->decimal('purchase_price',10,2)->nullable();
            $table->decimal('amount',10,2)->nullable();          
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('purchase_challans');
        Schema::dropIfExists('purchase_challans_item');
    }
}
