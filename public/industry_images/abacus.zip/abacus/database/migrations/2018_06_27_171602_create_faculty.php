<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateFaculty extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('faculties', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('masterFranchisesId')->nullable();
            $table->integer('franchisesId')->nullable();
            $table->string('centreCode')->nullable();            
            $table->enum('facultyType',['owner','faculty'])->default('faculty');
            $table->string('facultyCode')->nullable();
            $table->string('facultyName')->nullable();
            $table->timestamp('dob')->nullable();
            $table->string('address')->nullable();        
            $table->string('city')->nullable();
            $table->string('state')->nullable();
            $table->string('pincode')->nullable();
            $table->string('education')->nullable();
            $table->string('skills')->nullable();
            $table->string('residenceNo')->nullable();
            $table->string('mobileNo')->nullable();
            $table->string('email')->nullable();
            $table->integer('experienceTotal')->nullable();
            $table->integer('experienceAbcus')->nullable();
            $table->integer('experienceVMath')->nullable();
            $table->enum('trainingRequire',['yes','no'])->default('no');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('faculties');
    }
}
