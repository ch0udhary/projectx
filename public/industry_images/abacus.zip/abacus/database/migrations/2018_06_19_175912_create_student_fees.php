<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateStudentFees extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('student_fees', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('masterFranchisesId')->nullable();
            $table->integer('franchisesId')->nullable();
            $table->string('centreCode')->nullable();
            $table->integer('studentId')->nullable();
            $table->string('receiptNo')->nullable();
            $table->string('manualReceiptNo')->nullable();
            $table->timestamp('receiptDate')->nullable();
            $table->string('fees')->nullable();
            $table->string('kitCost')->nullable();
            $table->string('bookCost')->nullable();
            $table->string('abacusCost')->nullable();
            $table->string('bagCost')->nullable();
            $table->string('miscellaneous')->nullable();
            $table->string('concession')->nullable();
            $table->string('reasonConcession')->nullable();
            $table->string('total')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('StudentFees');
    }
}
