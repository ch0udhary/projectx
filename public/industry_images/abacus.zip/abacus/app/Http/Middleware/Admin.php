<?php

namespace App\Http\Middleware;

use Closure;
use Sentinel;
use Session;
use Illuminate\Support\Facades\Auth;

class Admin
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next, $guard = null)
    {

        if ($user = Sentinel::check())
        {


            if ($admin = Sentinel::inRole('admin'))
            {
                return $next($request);
            }
            else
            {
                Session::flash('error', trans('Sentinel::users.noaccess'));
                return redirect()->guest('/');
            }
        }
        else
        {
            return redirect()->guest('login');
        }




    }
}
