<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use Sentinel;
use Redirect;
use Response;
use Validator;
use Session;
use Flash;
use Hash;

class UserController extends Controller
{

    /**
     * register the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function register()
    {
        //
        return view('auth.signup');

    }

    /**
     * register the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function postregister(Request $request){

        return Redirect::to('/login');
        dd($request->all());
        $all_user_details = Input::all();

        if ($user = Sentinel::check())
        {
            return Redirect::to('/activate');
        }

        if(!empty($all_user_details))
        {

            $validation = Validator::make(Input::all(), [
                'first_name' => 'required',
                'last_name' => 'required',
                'email' => 'required|email|max:50|unique:users',
                'password' => 'required|min:6',
                'password_confirmation' => 'required|same:password',

            ]);


            if ($validation->fails())
            {
                return Redirect::to('/register')->withErrors($validation)->withInput();
            }
            else
            {


                $toemail = Input::get('email');
                // $user = Sentinel::registerAndActivate(Input::all())
                //register
                if ($user = Sentinel::registerAndActivate(Input::all()))
                {
                    $role = Sentinel::findRoleBySlug('admin');
                    $role->users()->attach($user);

                    Flash::success('User is successfully Registered! Please Login Now.');


                    return Redirect::to('/login')->with('success', "User was successful Registered!");;
                }
                Flash::error('Oh, There Was An Error!');
                return Redirect::back()->withErrors("Oh, There Was An Error!");

            }

        }
        else
        {
            return  view('auth.register');
        }




        $user = Sentinel::registerAndActivate($request->all());
        $role = Sentinel::findRoleBySlug('admin');
        $role->users()->attach($user);


        return redirect('/');
    }

    public function login(Request $request)
    {
        //
        return view('auth.login');

    }

    public function logout(Request $request)
    {
        //
        Sentinel::logout();
        return redirect('/login');

    }

    public function postlogin(Request $request)
    {

        try {
            $user_details = Input::all();
            extract($user_details);
            if ($user = Sentinel::check()) {

                return Redirect::to('/');

            } else {
                if (!empty($user_details)) {

                   $user_exist = new \App\User;
                    $Load_Current_User = $user_exist::where('email', $email)->get()->toArray();

                    if(!empty($Load_Current_User)){

                       $all_details = Sentinel::authenticate($user_details);

                        if ($all_details = '' || empty($all_details)) {
                            Flash::error('Please Enter Valid Email or Password');
                            return Redirect::to('/login')->withErrors(["logininvalid" => "Please Enter Valid Email or Password"]);

                        } else {
                            Sentinel::authenticate($user_details);

                            $LoginUserId = Sentinel::getUser()->id;

                            if (isset($LoginUserId) && $LoginUserId != ''):
                                $Load_User = new \App\User;
                                $Load_Current_User = $Load_User::find($LoginUserId);
                                    Flash::success('Successfully Logged In!');
                                    return Redirect::to('/')->with("Successfully Logged In!");

                            endif;
                        }
                    }else{
                            Flash::error('Please Enter Valid Email or Password');
                            return Redirect('/login');
                    }
                } else {
                    return view('auth.login');
                }

            }

        }
        catch (\Cartalyst\Sentinel\Checkpoints\NotActivatedException $e) {

            $errors = 'Account not activated.';
            Flash::error($e->getMessage());

            return Redirect::to('/login')->withErrors(["logininvalid" => "Please Enter Valid Email or Password"]);

        }
        catch (\Cartalyst\Sentinel\Checkpoints\ThrottlingException $e){

            Flash::error($e->getMessage());
            return Redirect::to('/login')->withErrors(["logininvalid" => $e->getMessage()]);

        }

    }

}
