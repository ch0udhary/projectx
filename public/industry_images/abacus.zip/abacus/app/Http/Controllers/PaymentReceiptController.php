<?php

namespace App\Http\Controllers;

use App\PaymentReceipt;
use App\MasterFranchises    ;
use Illuminate\Http\Request;
use Validator;
class PaymentReceiptController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $MasterFranchises = new MasterFranchises;
        $masterfranchisess =$MasterFranchises::select('id','master_franchisee_code')->get();

        return view('admin.inventory.payment_receipt',compact('masterfranchisess'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'master_franchisee_code' => 'required',
            'franchisee_code' => 'required',  
            'amount' => 'integer'         
        ]);

        if ($validator->fails()) {

            return redirect(route('payment-receipt.create'))->withErrors($validator)->withInput();
        }

        $saveStatus = PaymentReceipt::updatecreate($request);
        if($saveStatus){
            return redirect(route('payment-receipt.create'))->with('success','Payment Receipt Added Successfully.');

        }
        return redirect(route('payment-receipt.create'))->with('error','Some Error Occoured.');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\PaymentReceipt  $paymentReceipt
     * @return \Illuminate\Http\Response
     */
    public function show(PaymentReceipt $paymentReceipt)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\PaymentReceipt  $paymentReceipt
     * @return \Illuminate\Http\Response
     */
    public function edit(PaymentReceipt $paymentReceipt)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\PaymentReceipt  $paymentReceipt
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, PaymentReceipt $paymentReceipt)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\PaymentReceipt  $paymentReceipt
     * @return \Illuminate\Http\Response
     */
    public function destroy(PaymentReceipt $paymentReceipt)
    {
        //
    }
}
