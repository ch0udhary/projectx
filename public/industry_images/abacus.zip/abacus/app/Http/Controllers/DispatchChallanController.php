<?php

namespace App\Http\Controllers;

use App\DispatchChallan;
use App\MasterFranchises;
use App\IssueRequest;
use Illuminate\Http\Request;
use Validator;
class DispatchChallanController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $issueRequest = IssueRequest::all();   
        $MasterFranchises = new MasterFranchises;
        $masterfranchisess =$MasterFranchises::select('id','master_franchisee_code')->get();   

        return view('admin.inventory.dispatch_challan',compact('issueRequest','masterfranchisess'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        $dispatchDetails = $request->all();  
              
        return view('admin.inventory.dispatch_challan_add',compact('dispatchDetails'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'challan_id' => 'required',
            'request_id' => 'required',
        ]);

        if ($validator->fails()) {

            return redirect(route('dispatch-challan.index'))->withErrors($validator)->withInput();
        }

        $saveStatus = DispatchChallan::updatecreate($request);
        if($saveStatus){
            return redirect(route('dispatch-challan.index'))->with('success','Dispatch Challan Added Successfully.');

        }
        return redirect(route('dispatch-challan.index'))->with('error','Some Error Occoured.');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\DispatchChallan  $dispatchChallan
     * @return \Illuminate\Http\Response
     */
    public function show(DispatchChallan $dispatchChallan)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\DispatchChallan  $dispatchChallan
     * @return \Illuminate\Http\Response
     */
    public function edit(DispatchChallan $dispatchChallan)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\DispatchChallan  $dispatchChallan
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, DispatchChallan $dispatchChallan)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\DispatchChallan  $dispatchChallan
     * @return \Illuminate\Http\Response
     */
    public function destroy(DispatchChallan $dispatchChallan)
    {
        //
    }
}
