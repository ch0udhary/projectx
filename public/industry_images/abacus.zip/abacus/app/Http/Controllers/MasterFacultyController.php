<?php

namespace App\Http\Controllers;

use App\MasterFaculty;
use Illuminate\Http\Request;
use App\MasterFranchises;
use App\Centres;
use App\Franchises;
use Illuminate\Support\Facades\Input;
use Sentinel;
use Redirect;
use Response;
use Validator;
use Session;
use Flash;
use Hash;

class MasterFacultyController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $MasterFranchises = new MasterFranchises;
        $masterfranchisess =$MasterFranchises ::select('id','master_franchisee_code')->get();
        $Franchises = new Franchises;
        $franchises_info =$Franchises ::select('id','franchisee_code')->get();
        return view('admin.centre.faculty',compact('masterfranchisess','franchises_info'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //

       //echo '<pre>'; print_r($request->all()); echo '</pre>'; die;

        $rules = array(
            'masterFranchisesId'=>'required',
            'franchisesId'=>'required',
            'centreCode'=>'required',
            'fname'=>'required',
            'lname'=>'required',
            'gender'=>'required',

        );

        $messsages = array(
            'masterFranchisesId.required'=>'The Master Franchises field is required.',
            'franchisesId.required'=>'The franchises field is required.',
            'centreCode.required'=>'The First Name field is required.',
            'fname.required'=>'The First Name field is required.',
            'lname.required'=>'The Last Name field is required.',
            'gender.required'=>'The Gender field is required.',

        );

        $validation = Validator::make(Input::all(), $rules,$messsages);



        if ($validation->fails())
        {
            return Redirect::back()->withErrors($validation)->withInput();
        }else{

            $masterFaculty = new MasterFaculty;
            $masterFaculty->master_franchisee_id = $request->masterFranchisesId;
            $masterFaculty->franchisee_id = $request->franchisesId;
            $masterFaculty->center_id = $request->centreCode;
            $masterFaculty->fname = $request->fname;
            $masterFaculty->lname = $request->lname;
            $masterFaculty->gender = $request->gender;
            $masterFaculty->save();


            Flash::success('Faculty is added successfully.');

            return Redirect::to('/admin/center-faculty')->with('success', "Faculty is added successfully.");



        }

    }

    /**
     * Display the specified resource.
     *
     * @param  \App\MasterFaculty  $masterFaculty
     * @return \Illuminate\Http\Response
     */
    public function show(MasterFaculty $masterFaculty)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\MasterFaculty  $masterFaculty
     * @return \Illuminate\Http\Response
     */
    public function edit(MasterFaculty $masterFaculty)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\MasterFaculty  $masterFaculty
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, MasterFaculty $masterFaculty)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\MasterFaculty  $masterFaculty
     * @return \Illuminate\Http\Response
     */
    public function destroy(MasterFaculty $masterFaculty)
    {
        //
    }
}
