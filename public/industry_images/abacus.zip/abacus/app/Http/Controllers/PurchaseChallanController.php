<?php

namespace App\Http\Controllers;

use App\PurchaseChallan;
use Illuminate\Http\Request;
use Validator;
class PurchaseChallanController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.inventory.purchase_challan');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'challan_number' => 'required',
            'supplier_bill_no' => 'required',           
        ]);

        if ($validator->fails()) {
            return redirect(route('purchase-challan.create'))->withErrors($validator)->withInput();
        }

        $saveStatus = PurchaseChallan::updatecreate($request);
        if($saveStatus){
            return redirect(route('purchase-challan.create'))->with('success','Chalan Added Successfully.');

        }
        return redirect(route('purchase-challan.create'))->with('error','Some Error Occoured.');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\PurchaseChallan  $purchaseChallan
     * @return \Illuminate\Http\Response
     */
    public function show(PurchaseChallan $purchaseChallan)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\PurchaseChallan  $purchaseChallan
     * @return \Illuminate\Http\Response
     */
    public function edit(PurchaseChallan $purchaseChallan)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\PurchaseChallan  $purchaseChallan
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, PurchaseChallan $purchaseChallan)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\PurchaseChallan  $purchaseChallan
     * @return \Illuminate\Http\Response
     */
    public function destroy(PurchaseChallan $purchaseChallan)
    {
        //
    }
}
