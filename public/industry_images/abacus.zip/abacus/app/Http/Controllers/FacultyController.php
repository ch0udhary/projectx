<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Faculty;
use App\MasterFranchises;
use Validator;

class FacultyController extends Controller
{

    public function index(){

        $feesListing = new Faculty;
        $listing = $feesListing->all();

        $MasterFranchises = new MasterFranchises;
        $masterfranchisess =$MasterFranchises::select('id','master_franchisee_code')->get();

        return view('admin.faculty.index',compact('listing','masterfranchisess'));
    }


    public function create(){

        $MasterFranchises = new MasterFranchises;
        $masterfranchisess =$MasterFranchises::select('id','master_franchisee_code')->get();
       
        return view('admin.faculty.create',compact('masterfranchisess'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        
        $validator = Validator::make($request->all(), [
            'facultyCode' => 'required',
            'facultyName' => 'required',           
        ]);

        if ($validator->fails()) {

            return redirect(route('faculty.create'))->withErrors($validator)->withInput();
        }

        $saveStatus = Faculty::updatecreate($request);
        if($saveStatus){
            return redirect(route('faculty.create'))->with('success','Faculty Added Successfully.');

        }
        return redirect(route('faculty.create'))->with('error','Some Error Occoured.');
    }

    // To View The Facutly list section
    public function facultylist(Request $request){
        $faculty = Faculty::where('centreCode',$request->centreCode)->get();
        
        $html = '<option selected value="">Select Faculty</option>';
        if(!empty($faculty)){
            foreach ($faculty as $key => $value) {
                $html .= '<option value='.$value->id.'>'.$value->facultyName.'</option>';
            }
        }
        return $html;
        die;

    }

    public function getfaculty(Request $request){
         
        if(!empty($request->regNo)){
            $getListing = Faculty::where('facultyCode',$request->regNo)->first();
        }elseif(!empty($request->id)){
            $getListing = Faculty::find($request->id);
        }
        $html = '';
        if(!empty($getListing)){
            $html .= '<div class="row gutters">
                        <div class="col">
                            <label for="">Registration Date</label>
                        </div>
                        <div class="col">
                            '.$getListing->created_at.'
                        </div>
                    </div>';
            $html .= '<div class="row gutters">
                        <div class="col">
                            <label for="">Master Franchisee</label>
                        </div>
                        <div class="col">
                            '.$getListing->masterFranchieses->name.'
                        </div>
                    </div>'; 
            $html .= '<div class="row gutters">
                        <div class="col">
                            <label for="">Centre</label>
                        </div>
                        <div class="col">
                            '.$getListing->center->centre_name.'
                        </div>
                    </div>';
            $html .= '<div class="row gutters">
                        <div class="col">
                            <label for="">Faculty</label>
                        </div>
                        <div class="col">
                            '.$getListing->facultyName.'
                        </div>
                    </div>';
            $html .= '<div class="row gutters">
                        <div class="col">
                            <label for="">DOB</label>
                        </div>
                        <div class="col">
                            '.$getListing->dob.'
                        </div>
                    </div>';

            $html .= '<div class="row gutters">
                        <div class="col">
                            <label for="">Contact number</label>
                        </div>
                        <div class="col">
                            '.$getListing->mobileNo.'
                        </div>
                    </div>';           
           
            
        }
        return $html;
        die;
    }
}
