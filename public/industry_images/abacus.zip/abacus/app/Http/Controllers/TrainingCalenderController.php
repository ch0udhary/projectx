<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\TrainingCalender;
use App\MasterFranchises;
use App\ProgramMaster;
use Validator;
use App\ProgramLevel;

class TrainingCalenderController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $calListing = new TrainingCalender;
        $listing = $calListing->all();

        $MasterFranchises = new MasterFranchises;
        $masterfranchisess =$MasterFranchises::select('id','master_franchisee_code')->get();

        $prlist = ProgramMaster::all();
        return view('admin.faculty.trainingcalender',compact('listing','masterfranchisess','prlist'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
       
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        
        $validator = Validator::make($request->all(), [
            'trainingDate' => 'required',
            'level' => 'required',
            'programId' => 'required'
            
        ]);

        if ($validator->fails()) {

            return redirect(route('training-calender.index'))->withErrors($validator)->withInput();
        }

        $saveStatus = TrainingCalender::updatecreate($request);
        if($saveStatus){
            return redirect(route('training-calender.index'))->with('success','Training Calender Date Added Successfully.');

        }
        return redirect(route('training-calender.index'))->with('error','Some Error Occoured.');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {        
        if(!empty($id)){
        	$delete = TrainingCalender::destroy($id);
        	if($delete){
        		return redirect(route('training-calender.index'))->with('success','Training Calender Date Deleted Successfully.');
        	}
        }
        return redirect(route('training-calender.index'))->with('error','Some Error Occoured.');
    }

    // To View The Facutly list section
    public function levellist(Request $request){
        $level = ProgramLevel::where('program_master_id',$request->programId)->get();
        
        $html = '<option selected value="">Select Level</option>';
        if(!empty($level)){
            foreach ($level as $key => $value) {
                $html .= '<option value='.$value->id.'>'.$value->name.'</option>';
            }
        }
        return $html;
        die;

    }
}
