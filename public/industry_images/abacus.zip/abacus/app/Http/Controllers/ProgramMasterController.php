<?php

namespace App\Http\Controllers;

use App\ProgramMaster;
use Illuminate\Http\Request;
use App\FeesManager;
use Validator;
use App\Franchises;
use App\MasterFranchises;
use App\Centres ;
use App\Student ;
use App\StudentFee ;
use Sentinel;
use Redirect;
use Response;
use Session;
use Flash;
use Hash;
use Illuminate\Support\Facades\Input;


class ProgramMasterController extends Controller
{


    public function __construct()
    {
        $this->middleware('admin');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //

        $ProgramMaster = new ProgramMaster();
        $programmasters =$ProgramMaster::get();

        return view('admin.program.master-program',compact('programmasters'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
       return view('admin.program.master-program');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
      extract($request->all());
      $rules = array(
            'masterprogram' => 'required',
        );

        $messsages = array(
            'masterprogram.required'=>'The Master Program field is required.',
        );

        $validation = Validator::make(Input::all(), $rules,$messsages);



        if ($validation->fails())
        {
            return Redirect::back()->withErrors($validation)->withInput();
        }else{

                $attendance = new ProgramMaster();
                $attendance->name = $request->masterprogram;
                $attendance->save();


            //dd($request->all());

            Flash::success('Master Program is added successfully.');
            return Redirect::to('/admin/program-master')->with('success', "Master Program is added successfully.");


        }

    }

    /**
     * Display the specified resource.
     *
     * @param  \App\ProgramMaster  $programMaster
     * @return \Illuminate\Http\Response
     */
    public function show(ProgramMaster $programMaster)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\ProgramMaster  $programMaster
     * @return \Illuminate\Http\Response
     */
    public function edit(ProgramMaster $programMaster)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\ProgramMaster  $programMaster
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ProgramMaster $programMaster)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\ProgramMaster  $programMaster
     * @return \Illuminate\Http\Response
     */
    public function destroy(ProgramMaster $programMaster)
    {
        //
    }


}
