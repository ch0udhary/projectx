<?php

namespace App\Http\Controllers;

use App\Student;
use App\Parents;
use App\Program;
use App\Centres;
use App\ProgramLevel;
use App\Franchises;
use App\MasterFranchises;
use App\GradeMaster;
use App\ProgramMaster;
use App\MasterFaculty;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use Sentinel;
use Redirect;
use Response;
use Validator;
use Session;
use Flash;
use Hash;
use App\DropOut;
use App\ApplyCertificate;

class StudentController extends Controller
{

    public function __construct()
    {
        $this->middleware('admin');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $students = new Student;
        $studentDetails  = $students::with('parents','programs')->get();
        return view('admin.students.index',compact('studentDetails'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        $MasterFranchises = new MasterFranchises;
        $masterfranchisess =$MasterFranchises ::select('id','master_franchisee_code')->get();
        //$Franchises = new Franchises;
        //$franchises_info =$Franchises ::select('id','franchisee_code')->get();
        return view('admin.students.create',compact('masterfranchisess'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $rules = array(
        	'masterFranchisesId' => 'required',
        	'franchisesId' => 'required',
        	'centreCode' => 'required',
        	'registration_no' =>'required',
        	'registration_date'=>'required',
        	'student_photo'=>'required|mimes:jpeg,png,jpg|max:2048',
        	'name'=>'required',
        	'dob'=>'required',
            'address'=>'required',
            'city'=>'required',
            'state'=>'required',
            'pin'=>'required',
            'contact_tel_no'=>'required',
            'gender'=>'required',
            'school_name'=>'required',
            'school_address'=>'required',
            'school_city'=>'required',
            'school_state'=>'required',
            'school_pin'=>'required',
            'class'=>'required',
            'hobby_1'=>'required',
            'hobby_2'=>'required',
            'hobby_3'=>'required',

            'ftitle'=>'required',
            'fathers_name'=>'required',
            'fathers_occupation'=>'required',
            'fathers_office_address'=>'required',
            'fathers_city'=>'required',
            'fathers_state'=>'required',
            'fathers_pin'=>'required',
            'fathers_office_tel_no'=>'required',
            'fathers_mobile_no'=>'required',
            'fathers_email'=>'required',
            'mtitle'=>'required',
            'mothers_name'=>'required',
            'mothers_occupation'=>'required',
            'mothers_office_address'=>'required',
            'mothers_city'=>'required',
            'mothers_state'=>'required',
   			'mothers_pin'=>'required',
            'mothers_office_tel_no'=>'required',
            'mothers_mobile_no'=>'required',
            'mothers_email'=>'required',
			'referred_by'=>'required',
            'purpose_of_enrollment'=>'required',
        );

        $messsages = array(
            'masterFranchisesId.required'=>'You cant leave Master franchisee code field empty. Please select',
            'franchisesId.required'=>'You cant leave franchisee code field empty. Please select',
            'centreCode.required'=>'You cant leave Centre/Name field empty. Please select',
            'name.required'=>'The name field is required.',
            'enquiry_date.required'=>'The enquiry date field is required.',
            'program_interested.required'=>'The program interested field is required.',
            'lead_status.required'=>'The lead status field is required.',
            'address.required'=>'The address field is required.',
            'city.required'=>'The city field is required.',
            'mobile.required'=>'The mobile field is required.',
            'phone.required'=>'The phone field is required.',
            'state.required'=>'The state field is required.',
            'pin.required'=>'The pin code field is required.',

        );

        $validation = Validator::make(Input::all(), $rules,$messsages);



        if ($validation->fails())
        {
            return Redirect::back()->withErrors($validation)->withInput();
        }else{



            $studentPhoto = $request->file('student_photo')->store('student_pics','public');        

            $parent = new Parents;
            $parent->ftitle = $request->ftitle;
            $parent->fathers_name = $request->fathers_name;
            $parent->fathers_occupation = $request->fathers_occupation;
            $parent->fathers_office_address = $request->fathers_office_address;
            $parent->fathers_city = $request->fathers_city;
            $parent->fathers_state = $request->fathers_state;
            $parent->fathers_pin = $request->fathers_pin;
            $parent->fathers_office_tel_no = $request->fathers_office_tel_no;
            $parent->fathers_mobile_no = $request->fathers_mobile_no;
            $parent->fathers_email = $request->fathers_email;
            $parent->mtitle = $request->mtitle;
            $parent->mothers_name = $request->mothers_name;
            $parent->mothers_occupation = $request->mothers_occupation;
            $parent->mothers_office_address = $request->mothers_office_address;
            $parent->mothers_city = $request->mothers_city;
            $parent->mothers_state = $request->mothers_state;
            $parent->mothers_pin = $request->mothers_pin;
            $parent->mothers_office_tel_no = $request->mothers_office_tel_no;
            $parent->mothers_mobile_no = $request->mothers_mobile_no;
            $parent->mothers_email = $request->mothers_email;
            $parent->referred_by = $request->referred_by;
            $parent->purpose_of_enrollment = $request->purpose_of_enrollment;
            $parent->save();
            $id = $parent->id;

            $student = new Student;
            $student->master_franchisee_id  = $request->masterFranchisesId;
            $student->franchisee_id = $request->franchisesId;
            $student->centre_id = $request->centreCode;
            $student->name = $request->name;
            $student->registration_no = $request->registration_no;
            $student->registration_date = $request->registration_date;
            $student->dob = $request->dob;
            $student->address = $request->address;
            $student->city = $request->city;
            $student->state = $request->state;
            $student->pin = $request->pin;
            $student->gender = $request->gender;
            $student->contact_tel_no = $request->contact_tel_no;
            $student->school_name = $request->school_name;
            $student->school_address = $request->school_address;
            $student->school_city = $request->school_city;
            $student->school_state = $request->school_state;
            $student->school_pin = $request->school_pin;
            $student->class = $request->class;
            $student->hobby_1 = $request->hobby_1;
            $student->hobby_2 = $request->hobby_2;
            $student->hobby_3 = $request->hobby_3;
            $student->student_photo = $studentPhoto;
            $student->parent_id = $id;
            $student->save();

            Flash::success('Student is added successfully.');
            return Redirect::to('/admin/students')->with('success', "Student is added successfully.");

        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Student  $student
     * @return \Illuminate\Http\Response
     */
    public function show(Student $student)
    {
        $students = new Student;
        $student_info =$students ::where('id',$student->id)->first();
        $parents = new Parents;
        $parentDetails  = $parents::where('id',$student_info['parent_id'])->first();
        return view('admin.students.view',compact('student_info','parentDetails'));

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Student  $student
     * @return \Illuminate\Http\Response
     */
    public function edit(Student $student)
    {
        $students = new Student;
        $student_info =$students ::where('id',$student->id)->first();
        $parents = new Parents;
        $parentDetails  = $parents::where('id',$student_info['parent_id'])->first();
        $Franchises = new Franchises;
        $franchises_info =$Franchises::select('name')->where('id',$student->franchisee_id)->first();
        $Centre = new Centres;
        $Centres_name =$Centre::select('centre_name')->where('id',$student->centre_id)->first();
        $MasterFranchises = new MasterFranchises;
        $masterfranchisess =$MasterFranchises::select('id','master_franchisee_code')->get();
        return view('admin.students.create',compact('student_info','parentDetails','masterfranchisess','franchises_info','Centres_name'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Student  $student
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Student $student)
    {
        $rules = array(
            'masterFranchisesId' => 'required',
            'franchisesId' => 'required',
            'centreCode' => 'required',
            'registration_no' =>'required',
            'registration_date'=>'required',
           // 'student_photo'=>'required|mimes:jpeg,png,jpg|max:2048',
            'name'=>'required',
            'dob'=>'required',
            'address'=>'required',
            'city'=>'required',
            'state'=>'required',
            'pin'=>'required',
            'contact_tel_no'=>'required',
            'gender'=>'required',
            'school_name'=>'required',
            'school_address'=>'required',
            'school_city'=>'required',
            'school_state'=>'required',
            'school_pin'=>'required',
            'class'=>'required',
            'hobby_1'=>'required',
            'hobby_2'=>'required',
            'hobby_3'=>'required',

            'ftitle'=>'required',
            'fathers_name'=>'required',
            'fathers_occupation'=>'required',
            'fathers_office_address'=>'required',
            'fathers_city'=>'required',
            'fathers_state'=>'required',
            'fathers_pin'=>'required',
            'fathers_office_tel_no'=>'required',
            'fathers_mobile_no'=>'required',
            'fathers_email'=>'required',
            'mtitle'=>'required',
            'mothers_name'=>'required',
            'mothers_occupation'=>'required',
            'mothers_office_address'=>'required',
            'mothers_city'=>'required',
            'mothers_state'=>'required',
            'mothers_pin'=>'required',
            'mothers_office_tel_no'=>'required',
            'mothers_mobile_no'=>'required',
            'mothers_email'=>'required',
            'referred_by'=>'required',
            'purpose_of_enrollment'=>'required',
        );

        $messsages = array(
            'masterFranchisesId.required'=>'You cant leave Master franchisee code field empty. Please select',
            'franchisesId.required'=>'You cant leave franchisee code field empty. Please select',
            'centreCode.required'=>'You cant leave Centre/Name field empty. Please select',
            'name.required'=>'The name field is required.',
            'enquiry_date.required'=>'The enquiry date field is required.',
            'program_interested.required'=>'The program interested field is required.',
            'lead_status.required'=>'The lead status field is required.',
            'address.required'=>'The address field is required.',
            'city.required'=>'The city field is required.',
            'mobile.required'=>'The mobile field is required.',
            'phone.required'=>'The phone field is required.',
            'state.required'=>'The state field is required.',
            'pin.required'=>'The pin code field is required.',

        );

        $validation = Validator::make(Input::all(), $rules,$messsages);



        if ($validation->fails())
        {
            return Redirect::back()->withErrors($validation)->withInput();
        }else{



            $student1 = new Student;
            $student1 = $student1::find($student['id']);
            $parents_details = new Parents;
            $parents_details = $parents_details::find($student1->parent_id);
            $parents_details->ftitle = $request->ftitle;
            $parents_details->fathers_name = $request->fathers_name;
            $parents_details->fathers_occupation = $request->fathers_occupation;
            $parents_details->fathers_office_address = $request->fathers_office_address;
            $parents_details->fathers_city = $request->fathers_city;
            $parents_details->fathers_state = $request->fathers_state;
            $parents_details->fathers_pin = $request->fathers_pin;
            $parents_details->fathers_office_tel_no = $request->fathers_office_tel_no;
            $parents_details->fathers_mobile_no = $request->fathers_mobile_no;
            $parents_details->fathers_email = $request->fathers_email;
            $parents_details->mtitle = $request->mtitle;
            $parents_details->mothers_name = $request->mothers_name;
            $parents_details->mothers_occupation = $request->mothers_occupation;
            $parents_details->mothers_office_address = $request->mothers_office_address;
            $parents_details->mothers_city = $request->mothers_city;
            $parents_details->mothers_state = $request->mothers_state;
            $parents_details->mothers_pin = $request->mothers_pin;
            $parents_details->mothers_office_tel_no = $request->mothers_office_tel_no;
            $parents_details->mothers_mobile_no = $request->mothers_mobile_no;
            $parents_details->mothers_email = $request->mothers_email;
            $parents_details->referred_by = $request->referred_by;
            $parents_details->purpose_of_enrollment = $request->purpose_of_enrollment;
            $parents_details->save();
          
            $student1->master_franchisee_id  = $request->masterFranchisesId;
            $student1->franchisee_id = $request->franchisesId;
            $student1->centre_id = $request->centreCode;

            $student1->name = $request->name;
            $student1->registration_no = $request->registration_no;
            $student1->registration_date = $request->registration_date;
            $student1->dob = $request->dob;
            $student1->address = $request->address;
            $student1->city = $request->city;
            $student1->state = $request->state;
            $student1->pin = $request->pin;
            $student1->gender = $request->gender;
            $student1->contact_tel_no = $request->contact_tel_no;
            $student1->school_name = $request->school_name;
            $student1->school_address = $request->school_address;
            $student1->school_city = $request->school_city;
            $student1->school_state = $request->school_state;
            $student1->school_pin = $request->school_pin;
            $student1->class = $request->class;
            $student1->hobby_1 = $request->hobby_1;
            $student1->hobby_2 = $request->hobby_2;
            $student1->hobby_3 = $request->hobby_3;
            if(!empty($request->file('student_photo'))){
                $studentPhoto = $request->file('student_photo')->store('student_pics','public');
                $student1->student_photo = $studentPhoto;
            }
            $student1->parent_id = $student->parent_id;
            $student1->save();

            Flash::success('Student is updated successfully.');
            return Redirect::to('/admin/students')->with('success', "Student is updated successfully.");
    }
}

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Student  $student
     * @return \Illuminate\Http\Response
     */
    public function destroy(Student $student)
    {
        $students = new Student;
        $student_info =$students ::find($student->id);
        $student_info->forceDelete();
        Flash::success('Successfully Deleted Student!');
        return Redirect::to('/admin/students')->with('success', "Successfully Deleted Student.");
    }

    /* for add program */

    public function add_program()
    {
        $MasterFranchises = new MasterFranchises;
        $masterfranchisess =$MasterFranchises ::select('id','master_franchisee_code')->get();
        $Franchises = new Franchises;
        $franchises_info =$Franchises::select('id','franchisee_code')->get();
        $ProgramMaster = new ProgramMaster;
        $programmasters =$ProgramMaster::get();



        $parents_details = array('1' =>'Ms Shradha Shukla','2'=>'Mr Mohan','3'=>'Mr Ram');
        return view('admin.students.add-program',compact('masterfranchisess','franchises_info','parents_details','programmasters'));
    }

    /* Ajax request for fetch student details */

    public function ajaxRequest(Request $request)
    {
        $students = new Student;
        $student_info =$students::where('registration_no',key($request->all()))->select('registration_date','dob','name','contact_tel_no','parent_id')->first();
        $parent_info = new Parents;
        $parent_name = $parent_info::where('id',$student_info['parent_id'])->select('fathers_name')->first();
        $output ='<div class="form-group" id="student_details"><div class="row gutters"><div class="col"><label for="">Registration Date</label></div><div class="col" id="rg_date">'.$student_info['registration_date'].'</div></div><div class="row gutters"><div class="col"><label for="">Name</label></div><div class="col" id="name">'.$student_info['name'].'</div></div><div class="row gutters"><div class="col"><label for="">DOB, Age</label></div><div class="col" id="dob">'.$student_info['dob'].'</div></div><div class="row gutters"><div class="col"><label for="">Parent Name</label></div>
            <div class="col" id="parentName">'.$parent_name['fathers_name'].'</div></div><div class="row gutters"><div class="col"><label for="">Contact number</label></div><div class="col" id="contact_num">'.$student_info['contact_tel_no'].'</div></div></div>';
        return  $output;
        exit();
    }

    public function saveProgram(Request $request)
    {
         $rules = array(
            'masterFranchisesId'=>'required',
            'franchisesId'=>'required',
            'centreCode' =>'required',
            'registration_no'=>'required',
            'program'=>'required',
            'label'=>'required',
            'class_day'=>'required',
            'time_slot'=>'required',
            'faculty_name'=>'required',
        );

        $messsages = array(
            'masterFranchisesId.required'=>'You cant leave Master franchisee code field empty. Please select',
            'franchisesId.required'=>'You cant leave franchisee code field empty. Please select',
            'centreCode.required'=>'You cant leave centre field empty. Please select',
            'registration_no.required'=>'You cant leave registration_no field empty.',
            'program.required'=>'You cant leave program field empty. Please select',
            'label.required'=>'You cant leave label field empty. Please select',
            'class_day.required'=>'You cant leave class_day field empty. Please select',
            'time_slot.required'=>'You cant leave time_slot field empty. Please select',
            'faculty_name.required'=>'You cant leave faculty field empty. Please select',
        );

        $validation = Validator::make(Input::all(), $rules,$messsages);

        if ($validation->fails())
        {
            return Redirect::back()->withErrors($validation)->withInput();
        }else{
            $program = new Program;
            $program->title = $request->program;
            $program->master_franchises_id = $request->master_franchisee_code;
            $program->franchises_id = $request->franchisee_code;
            $program->centre_id = $request->centre;
            $program->registration_no = $request->registration_no;
            $program->lavel_title = $request->label;
            $program->class = $request->class_day;
            $program->time_slote = $request->time_slot;
            $program->faculty_id = $request->faculty_name;
            $program->save();
            Flash::success('Program is Assign successfully.');
            return Redirect::to('/admin/students')->with('success', "Program is Assign successfully.");;
        }
    }

    //Apply Certificate
    public function applyCertificate(){

        $MasterFranchises = new MasterFranchises;
        $masterfranchisess =$MasterFranchises::select('id','master_franchisee_code')->get();
        $grade_master = new GradeMaster;
        $grade_master_details =$grade_master ::select('grade')->get();
        
        return view('admin.students.apply-certificate',compact('masterfranchisess','grade_master_details'));
    }

    public function applyCertificatePost(Request $request){

        $validator = Validator::make($request->all(), [
            'obtainMarks' => 'required',
            'outOf' => 'required',
        ]);


        if ($validator->fails()) {

            return redirect(route('applyCertificate'))->withErrors($validator)->withInput();
        }

        $saveStatus = ApplyCertificate::updatecreate($request);
        if($saveStatus){
            return redirect(route('applyCertificate'))->with('success','Applied For Certificate Successfully.');

        }
        return redirect(route('applyCertificate'))->with('error','Some Error Occoured.');
    }

    //Drop Out
    public function dropOut(){

        $MasterFranchises = new MasterFranchises;
        $masterfranchisess =$MasterFranchises::select('id','master_franchisee_code')->get();
       
        return view('admin.students.drop-out',compact('masterfranchisess'));
    }

    //Drop Out
    public function dropOutPost(Request $request){


        $validator = Validator::make($request->all(), [
            'withdrawlDate' => 'required',
            'withdrawlReason' => 'required',
        ]);


        if ($validator->fails()) {

            return redirect(route('dropOut'))->withErrors($validator)->withInput();
        }

        $saveStatus = DropOut::updatecreate($request);
        if($saveStatus){
            return redirect(route('dropOut'))->with('success','Drop Added Record Added Successfully.');

        }
        return redirect(route('dropOut'))->with('error','Some Error Occoured.');
    }

    public function createGrade()
    {
        $grade_master = new GradeMaster;
        $percentage = array('0','10','20','30','40','50','60','70','80','90','100');
        $grade_master_details =$grade_master::get();
           
        return view('admin.students.grade-master',compact('percentage','grade_master_details'));
    }

    public function saveGrade(Request $request)
    {
        $grade_master = new GradeMaster;
        $validator = Validator::make($request->all(), [
            'percentage_from' => 'required',
            'percentage_to' => 'required',
            'grade' =>'required',
        ]);

        if ($validator->fails()) {
            $grade_master_details =$grade_master::get();
            return redirect(route('gradeMaster',compact('grade_master_details')))->withErrors($validator)->withInput();
        }
        else{
           
            $grade_master->percentage_from = $request->percentage_from;
            $grade_master->percentage_to = $request->percentage_to;
            $grade_master->grade = $request->grade;
            $grade_master->save();
            $grade_master_details =$grade_master::get();
            Flash::success('grade master is added successfully.');
            return redirect(route('gradeMaster'));
        }

    }

    public function issueCertificate()
    {
        $grade_master = new GradeMaster;
        $percentage = array('0','10','20','30','40','50','60','70','80','90','100');
        $grade_master_details =$grade_master::get();
           
        return view('admin.students.issue-certificate',compact('percentage','grade_master_details'));
    
    }

    public function getprogramlevel(Request $request){

        //die('rrrrrrrrr');

        $programlevel = new ProgramLevel();
        $programlevels =$programlevel::where('program_master_id',$request->id)->get();
        $html = '<option selected value="">Select Level</option>';
        if(!$programlevels->isEmpty()){
            $i = 1;
            foreach ($programlevels as $value) {
                $html .= '<option value='.$value->id.'>'.$value->name.'</option>';
            }
        }
        return $html;
        die;
    }

    public function getfaculty(Request $request){
        $programlevel = new MasterFaculty();
        $programlevels =$programlevel::where('center_id',$request->id)->get();
        $html = '<option selected value="">Select Faculty</option>';
        if(!$programlevels->isEmpty()){
            $i = 1;
            foreach ($programlevels as $value) {
                $html .= '<option value='.$value->id.'>'.$value->fname.' '.$value->lname.'</option>';
            }
        }
        return $html;
        die;


    }  
	
	public function getfaculty_list(Request $request){
        $masterfaculty = new MasterFaculty();
        $masterfacultys =$masterfaculty::where('center_id',$request->id)->get();
		
	
		$html = '<table id="" class="table table-striped table-bordered" width="100%" cellspacing="0" cellpadding="0" border="0"><tbody><tr>
                                            <th width="10%">No</th>
                                            <th width="50%">Faculty Name</th>
                                            <th width="40%">Gender</th>
                                        </tr>'; 
			$i = 1;
			 if(!$masterfacultys->isEmpty()){
			foreach($masterfacultys as $value){
					$html .= '<tr><td>'.$i.'</td><td>'.$value->fname.' '.$value->lname.'</td><td>'.$value->gender.'</td></tr>';
				
			 $i++;}	}						
										
              $html .= '</tbody></table>';
			  
			   return $html;
       echo '<pre>'; print_r($programlevels);
        die;


    }
	
	
}
