<?php

namespace App\Http\Controllers;

use App\ProgramLevel;
use App\ProgramMaster;
use Illuminate\Http\Request;
use App\FeesManager;
use Validator;
use App\Franchises;
use App\MasterFranchises;
use App\Centres ;
use App\Student ;
use App\StudentFee ;
use Sentinel;
use Redirect;
use Response;
use Session;
use Flash;
use Hash;
use Illuminate\Support\Facades\Input;

class ProgramLevelController extends Controller
{


    public function __construct()
    {
        $this->middleware('admin');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $ProgramMaster = new ProgramMaster();
        $programmasters =$ProgramMaster::get();

        return view('admin.program.program-level',compact('programmasters'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //

        //
        extract($request->all());
        $rules = array(
            'master_program' => 'required',
            'program_level' => 'required',
        );

        $messsages = array(
            'master_program.required'=>'The Master Program field is required.',
            'program_level.required'=>'The Program Level field is required.',
        );

        $validation = Validator::make(Input::all(), $rules,$messsages);



        if ($validation->fails())
        {
            return Redirect::back()->withErrors($validation)->withInput();
        }else{

            $attendance = new ProgramLevel();
            $attendance->program_master_id = $request->master_program;
            $attendance->name = $request->program_level;
            $attendance->save();


            //dd($request->all());

            Flash::success('Program level is added successfully.');
            return Redirect::to('/admin/program-level')->with('success', "Program level is added successfully.");


        }


    }

    /**
     * Display the specified resource.
     *
     * @param  \App\ProgramLevel  $programLevel
     * @return \Illuminate\Http\Response
     */
    public function show(ProgramLevel $programLevel)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\ProgramLevel  $programLevel
     * @return \Illuminate\Http\Response
     */
    public function edit(ProgramLevel $programLevel)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\ProgramLevel  $programLevel
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ProgramLevel $programLevel)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\ProgramLevel  $programLevel
     * @return \Illuminate\Http\Response
     */
    public function destroy(ProgramLevel $programLevel)
    {
        //
    }


    public function get_levellist(Request $request){
         $array_return =array();
         $retuenhtml = '';
         $retuenhtml .='<table id="" class="table table-striped table-bordered" width="100%" cellspacing="0" cellpadding="0" border="0">
                                        <tbody><tr>
                                            <th width="20%">No</th>
                                            <th width="30%">Name</th>
                                        </tr>';

        $programlevel = new ProgramLevel();
        $programlevels =$programlevel::where('program_master_id',$request->masterId)->get();

        if(!$programlevels->isEmpty()){
            $i = 1;
            foreach ($programlevels as $value) {
                $retuenhtml  .='<tr><td >'.$i.'</td ><td >'.$value["name"].'</td ></tr>';
                                                
           $i++; }
        }else{
            $retuenhtml .='<tr><td colspan="2" style="text-align: center">No record found</td ></tr>';

        }
                             $retuenhtml .= '</tbody></table>';



        $array_return['program_list'] = $retuenhtml;

        return $array_return;

    }
}
