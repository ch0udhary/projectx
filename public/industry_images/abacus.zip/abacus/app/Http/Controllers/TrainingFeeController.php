<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\TrainingFee;
use App\MasterFranchises;
use App\ProgramMaster;
use Validator;

class TrainingFeeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $feesListing = new TrainingFee;
        $listing = $feesListing->all();

        $MasterFranchises = new MasterFranchises;
        $masterfranchisess =$MasterFranchises::select('id','master_franchisee_code')->get();

        return view('admin.faculty.trainingfeeindex',compact('listing','masterfranchisess'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
       	$MasterFranchises = new MasterFranchises;
        $masterfranchisess =$MasterFranchises::select('id','master_franchisee_code')->get();

        $prlist = ProgramMaster::all();
       	return view('admin.faculty.trainingfeecreate',compact('masterfranchisess','prlist'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        
        $validator = Validator::make($request->all(), [
            'facultyId' => 'required',            
        ]);

        if ($validator->fails()) {

            return redirect(route('training-fee.create'))->withErrors($validator)->withInput();
        }

        $saveStatus = TrainingFee::updatecreate($request);
        if($saveStatus){
            return redirect(route('training-fee.create'))->with('success','Fees Added Successfully.');

        }
        return redirect(route('training-fee.create'))->with('error','Some Error Occoured.');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
