<?php

namespace App\Http\Controllers;

use App\Attendance;
use Illuminate\Http\Request;
use App\FeesManager;
use Validator;
use App\Franchises;
use App\MasterFranchises;
use App\Centres ;
use App\Student ;
use App\StudentFee ;
use Sentinel;
use Redirect;
use Response;
use Session;
use Flash;
use Hash;
use Illuminate\Support\Facades\Input;

class AttendanceController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $MasterFranchises = new MasterFranchises;
        $masterfranchisess =$MasterFranchises::select('id','master_franchisee_code')->get();

        return view('admin.attendance.index',compact('masterfranchisess'));

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
//echo $request->all('studentId'); die;


        extract($request->all());

        if(!isset($studentId)){
            return Redirect::back()->withErrors( 'Please Enter Registration Number.');
        }


        $rules = array(
            'masterFranchisesId' => 'required',
            'franchisesId' => 'required',
            'centreCode' => 'required',
          /*  'student.*.date' => 'required',
            'student.*.time' => 'required',
            'student.*.remark' => 'required',*/

        );

        $messsages = array(
            'masterFranchisesId.required'=>'You cant leave Master franchisee code field empty. Please select',
            'franchisesId.required'=>'You cant leave franchisee code field empty. Please select',
            'centreCode.required'=>'You cant leave Centre/Name field empty. Please select',
        /*    'student.*.date' => [
                'required' => 'Each person must have a unique e-mail address',
            ],
            'student.*.time' => [
                'required' => 'Each person must have a unique e-mail address',
            ],
            'student.*.remark' => [
                'required' => 'Each person must have a unique e-mail address',
            ],*/
          );

        $validation = Validator::make(Input::all(), $rules,$messsages);



        if ($validation->fails())
        {
            return Redirect::back()->withErrors($validation)->withInput();
        }else{

            foreach ($student as $value){
                $attendance = new Attendance;
                $attendance->student_id = $request->studentId;
                $attendance->date = $value['date'];
                $attendance->time = $value['time'];
                $attendance->remarks = $value['remark'];
                $attendance->save();

            }
            //dd($request->all());

            Flash::success('Attendance is added successfully.');
            return Redirect::to('/admin/attendance')->with('success', "Attendance is added successfully.");


        }


    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Attendance  $attendance
     * @return \Illuminate\Http\Response
     */
    public function show(Attendance $attendance)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Attendance  $attendance
     * @return \Illuminate\Http\Response
     */
    public function edit(Attendance $attendance)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Attendance  $attendance
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Attendance $attendance)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Attendance  $attendance
     * @return \Illuminate\Http\Response
     */
    public function destroy(Attendance $attendance)
    {
        //
    }

    public function getStudent(Request $request){

        $getListing = Student::where('registration_no',$request->regNo)->first();

        $return_data = array();

        $student_info = '';
        $student_attendance = '';
        if(!empty($getListing)){
            $student_info .= '<div class="row gutters">
                        <div class="col">
                            <label for="">Registration Date</label>
                        </div>
                        <div class="col">
                            '.$getListing->registration_date.'
                        </div>
                    </div>';
            $student_info .= '<div class="row gutters">
                        <div class="col">
                            <label for="">Name</label>
                        </div>
                        <div class="col">
                            '.$getListing->name.'
                        </div>
                    </div>';
            $student_info .= '<div class="row gutters">
                        <div class="col">
                            <label for="">DOB</label>
                        </div>
                        <div class="col">
                            '.$getListing->registration_date.'
                        </div>
                    </div>';
            $student_info .= '<div class="row gutters">
                        <div class="col">
                            <label for="">Parent Name</label>
                        </div>
                        <div class="col">
                            '.$getListing->name.'
                        </div>
                    </div>';

            $student_info .= '<div class="row gutters">
                        <div class="col">
                            <label for="">Contact number</label>
                        </div>
                        <div class="col">
                            '.$getListing->contact_tel_no.'
                        </div>
                    </div>';
            $student_info .= '<div class="row gutters">
                        <div class="col">
                            <label for="">Program</label>
                        </div>
                        <div class="col">
                            '.$getListing->registration_date.'
                        </div>
                    </div>';
            $student_info .= '<div class="row gutters">
                        <div class="col">
                            <label for="">Level</label>
                        </div>
                        <div class="col">
                            '.$getListing->registration_date.'
                        </div>
                    </div>';
            $student_info .= '<input type="hidden" name="studentId" value="'.$getListing->id.'">';

        }

        $student_attendance = '  <table id="" class="table table-striped table-bordered" width="100%" cellspacing="0" cellpadding="0" border="0"><tr>
                                            <th width="30%">Date</th>
                                            <th width="30%">Time</th>
                                            <th width="40%">Remarks</th>
                                        </tr>';

               $addendance = new Attendance();

        $addendance = $addendance::where('student_id',$getListing->id)->orderBy('id','desc')->get();

       // echo '<pre>'; print_r($addendance); die;

        if(!$addendance->isEmpty()){

            foreach ($addendance as $value){
                $student_attendance .= ' 
                                        <tr>
                                            <td>'.$value["date"].'</td>
                                            <td>'.$value["time"].'</td>
                                            <td>'.$value["remarks"].'</td>
                                        </tr>';
        }

        }
        $student_attendance .=' </table>';

        $return_data['student_attendance'] = $student_attendance;
        $return_data['student_info'] = $student_info;

        return $return_data;
        die;
    }




}
