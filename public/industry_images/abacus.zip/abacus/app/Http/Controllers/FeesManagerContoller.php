<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\FeesManager;
use Validator;
use App\Franchises;
use App\MasterFranchises;
use App\Centres ;
use App\Student ;
use App\StudentFee ;
use Sentinel;
use Redirect;
use Response;
use Session;
use Flash;
use Hash;

class FeesManagerContoller extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
	 public function __construct()
    {
        $this->middleware('admin');
    }
	 
	 
	 
    public function index()
    {
        $feesListing = new FeesManager;
        $listing = $feesListing->getListing();

        $prList = $feesListing->prList();
        return view('admin.fees-manager.index',compact('listing','prList'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
       
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        
        $validator = Validator::make($request->all(), [
            'price' => 'required',
            'duration' => 'required',
            'level' => 'required',
            'programId' => 'required',
        ]);

        if ($validator->fails()) {

            return redirect(route('fees-master.index'))->withErrors($validator)->withInput();
        }

        $saveStatus = FeesManager::updatecreate($request);
        if($saveStatus){
            return redirect(route('fees-master.index'))->with('success','Fees Added Successfully.');

        }
        return redirect(route('fees-master.index'))->with('error','Some Error Occoured.');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function generatereceipt(){

        $MasterFranchises = new MasterFranchises;
        $masterfranchisess =$MasterFranchises::select('id','master_franchisee_code')->get();
       
        return view('admin.fees-manager.generate-receipt',compact('masterfranchisess'));
    }

    public function getFranchisee(Request $request){
        $getListing = Franchises::where('master_franchisee_id',$request->masterId)->get();
        $html = '<option selected value="">Select</option>';
        if(!empty($getListing)){
            foreach ($getListing as $key => $value) {
                $html .= '<option value='.$value->id.'>'.$value->franchisee_code.'</option>';
            }
        }
        return $html;
        die;
    }

    public function getCenter(Request $request){
         
        $centers = Centres::where('master_franchisee_id',$request->masterId);
        if(!empty($request->id)){
            $centers->where('franchisee_id',$request->id);
        }
        $getListing = $centers->get();
        $html = '<option selected value="">Select</option>';
        if(!empty($getListing)){
            foreach ($getListing as $key => $value) {
                $html .= '<option value='.$value->id.'>'.$value->centre_name.'</option>';
            }
        }
        return $html;
        die;
    }

    public function getStudent(Request $request){
         
        $getListing = Student::where('registration_no',$request->regNo)->first();
        $html = '';
        if(!empty($getListing)){
            $html .= '<div class="row gutters">
                        <div class="col">
                            <label for="">Registration Date</label>
                        </div>
                        <div class="col">
                            '.$getListing->registration_date.'
                        </div>
                    </div>';
            $html .= '<div class="row gutters">
                        <div class="col">
                            <label for="">Name</label>
                        </div>
                        <div class="col">
                            '.$getListing->name.'
                        </div>
                    </div>';
            $html .= '<div class="row gutters">
                        <div class="col">
                            <label for="">DOB</label>
                        </div>
                        <div class="col">
                            '.$getListing->registration_date.'
                        </div>
                    </div>';
            $html .= '<div class="row gutters">
                        <div class="col">
                            <label for="">Parent Name</label>
                        </div>
                        <div class="col">
                            '.$getListing->name.'
                        </div>
                    </div>';

            $html .= '<div class="row gutters">
                        <div class="col">
                            <label for="">Contact number</label>
                        </div>
                        <div class="col">
                            '.$getListing->contact_tel_no.'
                        </div>
                    </div>';
            $html .= '<div class="row gutters">
                        <div class="col">
                            <label for="">Program</label>
                        </div>
                        <div class="col">
                            '.$getListing->registration_date.'
                        </div>
                    </div>';
            $html .= '<div class="row gutters">
                        <div class="col">
                            <label for="">Level</label>
                        </div>
                        <div class="col">
                            '.$getListing->registration_date.'
                        </div>
                    </div>';
            $html .= '<input type="hidden" name="studentId" value="'.$getListing->id.'">';
            
        }
        return $html;
        die;
    }
    public function savefees(Request $request){

        $validator = Validator::make($request->all(), [
            'masterFranchisesId' => 'required',
            'franchisesId' => 'required',
            'centreCode' => 'required',
            'studentId' => 'required',
            'receiptNo' => 'required',
            'manualReceiptNo' => 'required',
            'receiptDate' => 'required',
            'fees' => 'required',
            'kitCost' => 'required',
            'bookCost' => 'required',
            'abacusCost' => 'required',
            'bagCost' => 'required',
            'studentId' => 'required',
            'miscellaneous' => 'required',
            'concession' => 'required',
            'reasonConcession' => 'required',
            'total' => 'required',
        ]);

        if ($validator->fails()) {

            return redirect(route('generatereceipt'))->withErrors($validator)->withInput();
        }
        $saveStatus = StudentFee::updatecreate($request);
        if($saveStatus){
            return redirect(route('generatereceipt'))->with('success','Fees Added Successfully.');

        }
        return redirect(route('generatereceipt'))->with('error','Some Error Occoured.');
    }

    // To View The Fee list section
    public function feelist(){
        $MasterFranchises = new MasterFranchises;
        $masterfranchisess =$MasterFranchises::select('id','master_franchisee_code')->get();
        $feeList = StudentFee::all();
       
        return view('admin.fees-manager.fee-list',compact('masterfranchisess','feeList'));

    }

    public function feeserach(Request $request){

    }
}
