<?php

namespace App\Http\Controllers;

use App\MasterFranchises;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use Sentinel;
use Redirect;
use Response;
use Validator;
use Session;
use Flash;
use Hash;


class MasterFranchisesController extends Controller
{

    public function __construct()
    {
        $this->middleware('admin');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $MasterFranchises = new MasterFranchises;
        $masterfranchisess =$MasterFranchises ::get();
        return view('admin.master-franchises.index',compact('masterfranchisess'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        return view('admin.master-franchises.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $rules = array(
            'email'=>'required|unique:master_franchises',
            'name'=>'required',
            'master_franchisee_code'=>'required',
            'date_of_agreement'=>'required',
            'date_of_establishment'=>'required',
            'address'=>'required',
            'city'=>'required',
            'state'=>'required',
            'pin'=>'required',
            'mobile_no'=>'required',
            'phone_no'=>'required',
            'education'=>'required',
            'years_experience_in_business'=>'required',
            'years_experience_in_teaching'=>'required',
            'centre_code'=>'required',
            'licensed_territory'=>'required',
            'pin_code'=>'required',
            'license_certificate_no'=>'required',
            'license_period_from'=>'required',
            'license_period_to'=>'required',
            'receipt_date'=>'required',
            'license_fee_receipt_no'=>'required',
            'renewal_fee'=>'required',
            'renewed_period_from'=>'required',
            'renewed_period_to'=>'required',
            'royalty'=>'required',
            'material_discount'=>'required',
            'franchisee_license_fee'=>'required',
        );

        $messsages = array(
            'email.required'=>'You cant leave Email field empty',
            'name.required'=>'You cant leave Organisation/Name field empty',
            'master_franchisee_code.required'=>'You cant leave Master franchisee code field empty',
            'date_of_agreement.required'=>'You cant leave date of agreement field empty',
            'date_of_establishment.required'=>'You cant leave date of establishment field empty',
            'mobile_no.required'=>'The mobile field is required.',
            'phone_no.required'=>'The phone field is required.',
            'centre_code.required'=>'The centre code field is required.',
            'pin_code.required'=>'The pin code field is required.',
            'license_certificate_no.required'=>'The license certificate no field is required.',
            'licensed_territory.required'=>'The licensed territory field is required.',
            'license_period_from.required'=>'The license period from field is required.',
            'license_period_to.required'=>'The license period to field is required.',
            'franchisee_license_fee.required'=>'The franchisee license fee field is required.',
            'license_fee_receipt_no.required'=>'The license fee receipt no field is required.',
            'receipt_date.required'=>'The receipt date field is required.',
            'renewal_fee.required'=>'The renewal fee field is required.',
            'renewed_period_from.required'=>'The renewed period from field is required.',
            'renewed_period_to.required'=>'The renewed period to field is required.',
            'royalty.required'=>'The royalty field is required.',
            'material_discount.required'=>'The material discount field is required.',
            'years_experience_in_teaching.required'=>'The years experience in teaching field is required.',
            'years_experience_in_business.required'=>'The years experience in business field is required.',
            'name.min'=>'The field has to be :min chars long',
        );

        $validation = Validator::make(Input::all(), $rules,$messsages);



        if ($validation->fails())
        {
            return Redirect::back()->withErrors($validation)->withInput();
        }else{

            $MasterFranchises = new MasterFranchises;

            $MasterFranchises->master_franchisee_code = $request->master_franchisee_code;
            $MasterFranchises->date_of_agreement = $request->date_of_agreement;
            $MasterFranchises->name = $request->name;
            $MasterFranchises->date_of_establishment = $request->date_of_establishment;
            $MasterFranchises->address = $request->address;
            $MasterFranchises->city = $request->city;
            $MasterFranchises->state = $request->state;
            $MasterFranchises->pin = $request->pin;
            $MasterFranchises->phone_no = $request->phone_no;
            $MasterFranchises->mobile_no = $request->mobile_no;
            $MasterFranchises->email = $request->email;
            $MasterFranchises->education = $request->education;
            $MasterFranchises->years_experience_in_teaching = $request->years_experience_in_teaching;
            $MasterFranchises->years_experience_in_business = $request->years_experience_in_business;
            $MasterFranchises->centre_code = $request->centre_code;
            $MasterFranchises->licensed_territory = $request->licensed_territory;
            $MasterFranchises->pin_code = $request->pin_code;
            $MasterFranchises->license_certificate_no = $request->license_certificate_no;
            $MasterFranchises->license_period_from = $request->license_period_from;
            $MasterFranchises->license_period_to = $request->license_period_to;
            $MasterFranchises->franchisee_license_fee = $request->franchisee_license_fee;
            $MasterFranchises->license_fee_receipt_no = $request->license_fee_receipt_no;
            $MasterFranchises->receipt_date = $request->receipt_date;
            $MasterFranchises->renewal_fee = $request->renewal_fee;
            $MasterFranchises->renewed_period_from = $request->renewed_period_from;
            $MasterFranchises->renewed_period_to = $request->renewed_period_to;
            $MasterFranchises->royalty = $request->royalty;
            $MasterFranchises->material_discount = $request->material_discount;
            $MasterFranchises->save();


            Flash::success('Master Franchises is added successfully.');


            return Redirect::to('/admin/master-franchises')->with('success', "Master Franchises is added successfully.");


        }


    }

    /**
     * Display the specified resource.
     *
     * @param  \App\MasterFranchises  $masterFranchises
     * @return \Illuminate\Http\Response
     */
    public function show(MasterFranchises $masterFranchises, $id)
    {

        //
        $MasterFranchises = new MasterFranchises;
        $masterfranchises_info =$MasterFranchises ::where('id',$id)->first();
        return view('admin.master-franchises.view',compact('masterfranchises_info'));

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\MasterFranchises  $masterFranchises
     * @return \Illuminate\Http\Response
     */
    public function edit(MasterFranchises $masterFranchises,$id)
    {
        $MasterFranchises = new MasterFranchises;
        $MasterFranchises_info =$MasterFranchises ::where('id',$id)->first();
        return view('admin.master-franchises.create',compact('MasterFranchises_info'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\MasterFranchises  $masterFranchises
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, MasterFranchises $masterFranchises,$id)
    {
        $rules = array(
            'email' => 'required',
            'name' => 'required',
            'master_franchisee_code' => 'required',
            'date_of_agreement' => 'required',
            'date_of_establishment' => 'required',
            'address' => 'required',
            'city' => 'required',
            'state' => 'required',
            'pin' => 'required',
            'mobile_no' => 'required',
            'phone_no' => 'required',
            'education' => 'required',
            'years_experience_in_business' => 'required',
            'years_experience_in_teaching' => 'required',
            'centre_code' => 'required',
            'licensed_territory' => 'required',
            'pin_code' => 'required',
            'license_certificate_no' => 'required',
            'license_period_from' => 'required',
            'license_period_to' => 'required',
            'receipt_date' => 'required',
            'license_fee_receipt_no' => 'required',
            'renewal_fee' => 'required',
            'renewed_period_from' => 'required',
            'renewed_period_to' => 'required',
            'royalty' => 'required',
            'material_discount' => 'required',
            'franchisee_license_fee' => 'required',
        );

        $messsages = array(
            'email.required' => 'You cant leave Email field empty',
            'name.required' => 'You cant leave Organisation/Name field empty',
            'master_franchisee_code.required' => 'You cant leave Master franchisee code field empty',
            'date_of_agreement.required' => 'You cant leave date of agreement field empty',
            'date_of_establishment.required' => 'You cant leave date of establishment field empty',
            'mobile_no.required' => 'The mobile field is required.',
            'phone_no.required' => 'The phone field is required.',
            'centre_code.required' => 'The centre code field is required.',
            'pin_code.required' => 'The pin code field is required.',
            'license_certificate_no.required' => 'The license certificate no field is required.',
            'licensed_territory.required' => 'The licensed territory field is required.',
            'license_period_from.required' => 'The license period from field is required.',
            'license_period_to.required' => 'The license period to field is required.',
            'franchisee_license_fee.required' => 'The franchisee license fee field is required.',
            'license_fee_receipt_no.required' => 'The license fee receipt no field is required.',
            'receipt_date.required' => 'The receipt date field is required.',
            'renewal_fee.required' => 'The renewal fee field is required.',
            'renewed_period_from.required' => 'The renewed period from field is required.',
            'renewed_period_to.required' => 'The renewed period to field is required.',
            'royalty.required' => 'The royalty field is required.',
            'material_discount.required' => 'The material discount field is required.',
            'years_experience_in_teaching.required' => 'The years experience in teaching field is required.',
            'years_experience_in_business.required' => 'The years experience in business field is required.',
            'name.min' => 'The field has to be :min chars long',
        );

        $validation = Validator::make(Input::all(), $rules, $messsages);


        if ($validation->fails()) {
            return Redirect::back()->withErrors($validation)->withInput();
        } else {
           /* echo '<pre>';
            print_r($request->all());
            die();*/
            $MasterFranchises = new MasterFranchises;
            $MasterFranchises = $MasterFranchises::find($id);
            $MasterFranchises->master_franchisee_code = $request->master_franchisee_code;
            $MasterFranchises->date_of_agreement = $request->date_of_agreement;
            $MasterFranchises->name = $request->name;
            $MasterFranchises->date_of_establishment = $request->date_of_establishment;
            $MasterFranchises->address = $request->address;
            $MasterFranchises->city = $request->city;
            $MasterFranchises->state = $request->state;
            $MasterFranchises->pin = $request->pin;
            $MasterFranchises->phone_no = $request->phone_no;
            $MasterFranchises->mobile_no = $request->mobile_no;
            $MasterFranchises->email = $request->email;
            $MasterFranchises->education = $request->education;
            $MasterFranchises->years_experience_in_teaching = $request->years_experience_in_teaching;
            $MasterFranchises->years_experience_in_business = $request->years_experience_in_business;
            $MasterFranchises->centre_code = $request->centre_code;
            $MasterFranchises->licensed_territory = $request->licensed_territory;
            $MasterFranchises->pin_code = $request->pin_code;
            $MasterFranchises->license_certificate_no = $request->license_certificate_no;
            $MasterFranchises->license_period_from = $request->license_period_from;
            $MasterFranchises->license_period_to = $request->license_period_to;
            $MasterFranchises->franchisee_license_fee = $request->franchisee_license_fee;
            $MasterFranchises->license_fee_receipt_no = $request->license_fee_receipt_no;
            $MasterFranchises->receipt_date = $request->receipt_date;
            $MasterFranchises->renewal_fee = $request->renewal_fee;
            $MasterFranchises->renewed_period_from = $request->renewed_period_from;
            $MasterFranchises->renewed_period_to = $request->renewed_period_to;
            $MasterFranchises->royalty = $request->royalty;
            $MasterFranchises->material_discount = $request->material_discount;
            $MasterFranchises->save();


            Flash::success('Master Franchises is updated successfully.');


            return Redirect::to('/admin/master-franchises')->with('success', "Master Franchises is updated successfully.");
        }
    }
    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\MasterFranchises  $masterFranchises
     * @return \Illuminate\Http\Response
     */
    public function destroy(MasterFranchises $masterFranchises,$id)
    {
        $MasterFranchises = new MasterFranchises;
        $MasterFranchises = $MasterFranchises::find($id);
        $MasterFranchises->delete();
        Flash::success('Master Franchises is deleted successfully.');
        return Redirect::to('/admin/master-franchises')->with('success', "Master Franchises is deleted successfully");
    }
}
