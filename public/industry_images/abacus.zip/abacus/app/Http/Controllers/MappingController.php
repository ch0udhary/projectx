<?php

namespace App\Http\Controllers;

use App\Franchises;
use App\MasterFranchises;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use Sentinel;
use Redirect;
use Response;
use Validator;
use Session;
use Flash;
use Hash;

class MappingController extends Controller
{

    public function __construct()
    {
        $this->middleware('admin');
    }

    public function create(){
        $MasterFranchises = new MasterFranchises;
        $masterfranchisess =$MasterFranchises ::select('id','master_franchisee_code')->get();
        $Franchises = new Franchises;
        $franchises_info =$Franchises ::select('id','franchisee_code')->get();
        return view('admin.franchise-mapping.create',compact('masterfranchisess','franchises_info'));
    }

    public function store(Request $request){
        $rules = array(
            'master_franchisee_code'=>'required',
            'franchisee_code'=>'required',
        );

        $messsages = array(
            'master_franchisee_code.required'=>'You cant leave Master franchisee code field empty. Please select',
            'franchisee_code.required'=>'You cant leave franchisee code field empty. Please select',
        );

        $validation = Validator::make(Input::all(), $rules,$messsages);

        if ($validation->fails())
        {
            return Redirect::back()->withErrors($validation)->withInput();
        }else{
            $Franchises = new Franchises;
            $Franchises = $Franchises::find($request->franchisee_code);
            $Franchises->master_franchisee_id = $request->master_franchisee_code;
            $Franchises->save();
            Flash::success('Master Franchises is changed successfully.');
            return Redirect::to('/admin/franchisee-mapping/create')->with('success', "Master Franchises is changed successfully.");;


        }
    }

    public  function  ajaxRequest(Request $request){
        $Franchises = new Franchises;
        $franchises_data =$Franchises ::where('id',key($request->all()))->select('id','licensed_territory','master_franchisee_id')->first();
        $MasterFranchises = new MasterFranchises;
        $masterfranchisess = $MasterFranchises::where('id',$franchises_data['master_franchisee_id'])->select('id','master_franchisee_code')->first();
        $data[] = $franchises_data['licensed_territory'];
        $data[] = $masterfranchisess['master_franchisee_code'];
        return $data;
        exit();
    }

}
