<?php

namespace App\Http\Controllers;

use App\Franchises;
use App\MasterFranchises;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use Sentinel;
use Redirect;
use Response;
use Validator;
use Session;
use Flash;
use Hash;

class FranchisesController extends Controller
{


    public function __construct()
    {
        $this->middleware('admin');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $Franchises = new Franchises;
        $franchisess = $Franchises ::with('masterfrancies')->get();
        return view('admin.franchises.index',compact('franchisess'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //

        $MasterFranchises = new MasterFranchises;
        $masterfranchisess =$MasterFranchises ::select('id','master_franchisee_code')->get();
        return view('admin.franchises.create',compact('masterfranchisess'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $rules = array(
            'email'=>'required|unique:master_franchises',
            'name'=>'required',
            'master_franchisee_code'=>'required',
            'franchisee_code'=>'required',
            'date_of_agreement'=>'required',
            'date_of_establishment'=>'required',
            'address'=>'required',
            'city'=>'required',
            'state'=>'required',
            'pin'=>'required',
            'mobile_no'=>'required',
            'phone_no'=>'required',
            'education'=>'required',
            'years_experience_in_business'=>'required',
            'years_experience_in_teaching'=>'required',
            'licensed_territory'=>'required',
            'pin_code'=>'required',
            'license_certificate_no'=>'required',
            'license_period_from'=>'required',
            'license_period_to'=>'required',
            'receipt_date'=>'required',
            'license_fee_receipt_no'=>'required',
            'renewal_fee'=>'required',
            'renewed_period_from'=>'required',
            'renewed_period_to'=>'required',
            'royalty'=>'required',
            'material_discount'=>'required',
            'franchisee_license_fee'=>'required',
        );

        $messsages = array(
            'email.required'=>'You cant leave Email field empty',
            'name.required'=>'You cant leave Organisation/Name field empty',
            'master_franchisee_code.required'=>'You cant leave Master franchisee code field empty. Please select',
            'franchisee_code.required'=>'You cant leave franchisee code field empty',
            'date_of_agreement.required'=>'You cant leave date of agreement field empty',
            'date_of_establishment.required'=>'You cant leave date of establishment field empty',
            'mobile_no.required'=>'The mobile field is required.',
            'phone_no.required'=>'The phone field is required.',
            'pin_code.required'=>'The pin code field is required.',
            'license_certificate_no.required'=>'The license certificate no field is required.',
            'licensed_territory.required'=>'The licensed territory field is required.',
            'license_period_from.required'=>'The license period from field is required.',
            'license_period_to.required'=>'The license period to field is required.',
            'franchisee_license_fee.required'=>'The franchisee license fee field is required.',
            'license_fee_receipt_no.required'=>'The license fee receipt no field is required.',
            'receipt_date.required'=>'The receipt date field is required.',
            'renewal_fee.required'=>'The renewal fee field is required.',
            'renewed_period_from.required'=>'The renewed period from field is required.',
            'renewed_period_to.required'=>'The renewed period to field is required.',
            'royalty.required'=>'The royalty field is required.',
            'material_discount.required'=>'The material discount field is required.',
            'years_experience_in_teaching.required'=>'The years experience in teaching field is required.',
            'years_experience_in_business.required'=>'The years experience in business field is required.',
            'name.min'=>'The field has to be :min chars long',
        );

        $validation = Validator::make(Input::all(), $rules,$messsages);



        if ($validation->fails())
        {
            return Redirect::back()->withErrors($validation)->withInput();
        }else{
            $Franchises = new Franchises;
            $Franchises->master_franchisee_id = $request->master_franchisee_code;
            $Franchises->franchisee_code = $request->franchisee_code;
            $Franchises->date_of_agreement = $request->date_of_agreement;
            $Franchises->name = $request->name;
            $Franchises->date_of_establishment = $request->date_of_establishment;
            $Franchises->address = $request->address;
            $Franchises->city = $request->city;
            $Franchises->state = $request->state;
            $Franchises->pin = $request->pin;
            $Franchises->phone_no = $request->phone_no;
            $Franchises->mobile_no = $request->mobile_no;
            $Franchises->email = $request->email;
            $Franchises->education = $request->education;
            $Franchises->years_experience_in_teaching = $request->years_experience_in_teaching;
            $Franchises->years_experience_in_business = $request->years_experience_in_business;
            $Franchises->licensed_territory = $request->licensed_territory;
            $Franchises->pin_code = $request->pin_code;
            $Franchises->license_certificate_no = $request->license_certificate_no;
            $Franchises->license_period_from = $request->license_period_from;
            $Franchises->license_period_to = $request->license_period_to;
            $Franchises->franchisee_license_fee = $request->franchisee_license_fee;
            $Franchises->license_fee_receipt_no = $request->license_fee_receipt_no;
            $Franchises->receipt_date = $request->receipt_date;
            $Franchises->renewal_fee = $request->renewal_fee;
            $Franchises->renewed_period_from = $request->renewed_period_from;
            $Franchises->renewed_period_to = $request->renewed_period_to;
            $Franchises->royalty = $request->royalty;
            $Franchises->material_discount = $request->material_discount;
            $Franchises->save();


            Flash::success('Franchises is added successfully.');


            return Redirect::to('/admin/franchises')->with('success', "Franchises is added successfully.");


        }


    }


    /**
     * Display the specified resource.
     *
     * @param  \App\Franchises  $franchises
     * @return \Illuminate\Http\Response
     */
    public function show(Franchises $Franchises, $id)
    {

        //
        $Franchises = new Franchises;
        $franchises_info =$Franchises ::where('id',$id)->first();
        $MasterFranchises = new MasterFranchises;
        $masterfranchisess =$MasterFranchise::where('id',$franchises_info['master_franchisee_id'])->select('master_franchisee_code')->first();
        return view('admin.franchises.view',compact('franchises_info','masterfranchisess'));

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Franchises  $franchises
     * @return \Illuminate\Http\Response
     */
    public function edit(Franchises $franchises, $id)
    {
        $Franchises = new Franchises;
        $franchises_info =$Franchises::where('id',$id)->first();
        $MasterFranchises = new MasterFranchises;
        $masterfranchisess =$MasterFranchises::select('id','master_franchisee_code')->get();
        return view('admin.franchises.create',compact('franchises_info','masterfranchisess'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Franchises  $franchises
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Franchises $franchises,$id)
    {
        $rules = array(
            'email' => 'required|unique:master_franchises',
            'name' => 'required',
            'master_franchisee_code' => 'required',
            'franchisee_code' => 'required',
            'date_of_agreement' => 'required',
            'date_of_establishment' => 'required',
            'address' => 'required',
            'city' => 'required',
            'state' => 'required',
            'pin' => 'required',
            'mobile_no' => 'required',
            'phone_no' => 'required',
            'education' => 'required',
            'years_experience_in_business' => 'required',
            'years_experience_in_teaching' => 'required',
            'licensed_territory' => 'required',
            'pin_code' => 'required',
            'license_certificate_no' => 'required',
            'license_period_from' => 'required',
            'license_period_to' => 'required',
            'receipt_date' => 'required',
            'license_fee_receipt_no' => 'required',
            'renewal_fee' => 'required',
            'renewed_period_from' => 'required',
            'renewed_period_to' => 'required',
            'royalty' => 'required',
            'material_discount' => 'required',
            'franchisee_license_fee' => 'required',
        );

        $messsages = array(
            'email.required' => 'You cant leave Email field empty',
            'name.required' => 'You cant leave Organisation/Name field empty',
            'master_franchisee_code.required' => 'You cant leave Master franchisee code field empty. Please select',
            'franchisee_code.required' => 'You cant leave franchisee code field empty',
            'date_of_agreement.required' => 'You cant leave date of agreement field empty',
            'date_of_establishment.required' => 'You cant leave date of establishment field empty',
            'mobile_no.required' => 'The mobile field is required.',
            'phone_no.required' => 'The phone field is required.',
            'pin_code.required' => 'The pin code field is required.',
            'license_certificate_no.required' => 'The license certificate no field is required.',
            'licensed_territory.required' => 'The licensed territory field is required.',
            'license_period_from.required' => 'The license period from field is required.',
            'license_period_to.required' => 'The license period to field is required.',
            'franchisee_license_fee.required' => 'The franchisee license fee field is required.',
            'license_fee_receipt_no.required' => 'The license fee receipt no field is required.',
            'receipt_date.required' => 'The receipt date field is required.',
            'renewal_fee.required' => 'The renewal fee field is required.',
            'renewed_period_from.required' => 'The renewed period from field is required.',
            'renewed_period_to.required' => 'The renewed period to field is required.',
            'royalty.required' => 'The royalty field is required.',
            'material_discount.required' => 'The material discount field is required.',
            'years_experience_in_teaching.required' => 'The years experience in teaching field is required.',
            'years_experience_in_business.required' => 'The years experience in business field is required.',
            'name.min' => 'The field has to be :min chars long',
        );

        $validation = Validator::make(Input::all(), $rules, $messsages);

        if ($validation->fails()) {
            return Redirect::back()->withErrors($validation)->withInput();
        } else {
            $Franchises = new Franchises;
            $Franchises = $Franchises::find($id);
            $Franchises->master_franchisee_id = $request->master_franchisee_code;
            $Franchises->franchisee_code = $request->franchisee_code;
            $Franchises->date_of_agreement = $request->date_of_agreement;
            $Franchises->name = $request->name;
            $Franchises->date_of_establishment = $request->date_of_establishment;
            $Franchises->address = $request->address;
            $Franchises->city = $request->city;
            $Franchises->state = $request->state;
            $Franchises->pin = $request->pin;
            $Franchises->phone_no = $request->phone_no;
            $Franchises->mobile_no = $request->mobile_no;
            $Franchises->email = $request->email;
            $Franchises->education = $request->education;
            $Franchises->years_experience_in_teaching = $request->years_experience_in_teaching;
            $Franchises->years_experience_in_business = $request->years_experience_in_business;
            $Franchises->licensed_territory = $request->licensed_territory;
            $Franchises->pin_code = $request->pin_code;
            $Franchises->license_certificate_no = $request->license_certificate_no;
            $Franchises->license_period_from = $request->license_period_from;
            $Franchises->license_period_to = $request->license_period_to;
            $Franchises->franchisee_license_fee = $request->franchisee_license_fee;
            $Franchises->license_fee_receipt_no = $request->license_fee_receipt_no;
            $Franchises->receipt_date = $request->receipt_date;
            $Franchises->renewal_fee = $request->renewal_fee;
            $Franchises->renewed_period_from = $request->renewed_period_from;
            $Franchises->renewed_period_to = $request->renewed_period_to;
            $Franchises->royalty = $request->royalty;
            $Franchises->material_discount = $request->material_discount;
            $Franchises->save();
            Flash::success('Franchises is updated successfully.');
            return Redirect::to('/admin/franchises')->with('success', "Franchises is updated successfully.");
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Franchises  $franchises
     * @return \Illuminate\Http\Response
     */
    public function destroy(Franchises $franchises,$id)
    {
        $Franchises = new Franchises;
        $Franchises = $Franchises::find($id);
        $Franchises->forceDelete();
        Flash::success('Successfully Deleted franchise!');
        return Redirect::to('/admin/franchises')->with('success', "Leads is Deleted successfully.");
    }
}
