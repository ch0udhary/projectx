<?php

namespace App\Http\Controllers;

use App\Lead;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use Sentinel;
use Redirect;
use Response;
use Validator;
use Session;
use Flash;
use Hash;

class LeadController extends Controller
{


    public function __construct()
    {
        $this->middleware('admin');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $Lead = new Lead;
        $leads = $Lead::get();
        return view('admin.leads.index',compact('leads'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        return view('admin.leads.create');

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
      //  dd($request->all());
        $rules = array(
            'email'=>'required',
            'name'=>'required',
            'enquiry_date'=>'required',
            'program_interested'=>'required',
            'lead_status'=>'required',
            'address'=>'required',
            'city'=>'required',
            'state'=>'required',
            'pin'=>'required',
            'mobile'=>'required',
            'phone'=>'required',

        );

        $messsages = array(
            'email.required'=>'The email field is required.',
            'name.required'=>'The name field is required.',
            'enquiry_date.required'=>'The enquiry date field is required.',
            'program_interested.required'=>'The program interested field is required.',
            'lead_status.required'=>'The lead status field is required.',
            'address.required'=>'The address field is required.',
            'city.required'=>'The city field is required.',
            'mobile.required'=>'The mobile field is required.',
            'phone.required'=>'The phone field is required.',
            'state.required'=>'The state field is required.',
            'pin.required'=>'The pin code field is required.',

        );

        $validation = Validator::make(Input::all(), $rules,$messsages);



        if ($validation->fails())
        {
            return Redirect::back()->withErrors($validation)->withInput();
        }else{

            $Leads = new Lead;

            $Leads->enquiry_date = $request->enquiry_date;
            $Leads->name = $request->name;
            $Leads->program_interested = $request->program_interested;
            $Leads->address = $request->address;
            $Leads->city = $request->city;
            $Leads->lead_status = $request->lead_status;
            $Leads->state = $request->state;
            $Leads->pin = $request->pin;
            $Leads->phone = $request->phone;
            $Leads->mobile = $request->mobile;
            $Leads->email = $request->email;
            $Leads->save();
            Flash::success('Leads is added successfully.');
            return Redirect::to('/admin/leads')->with('success', "Leads is added successfully.");;


        }



    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Lead  $lead
     * @return \Illuminate\Http\Response
     */
    public function show(Lead $lead)
    {
        //

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Lead  $lead
     * @return \Illuminate\Http\Response
     */
    public function edit(Lead $lead)
    {

        return view('admin.leads.create',compact('lead'));


    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Lead  $lead
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Lead $lead)
    {
        //
        $rules = array(
            'email'=>'required',
            'name'=>'required',
            'enquiry_date'=>'required',
            'program_interested'=>'required',
            'lead_status'=>'required',
            'address'=>'required',
            'city'=>'required',
            'state'=>'required',
            'pin'=>'required',
            'mobile'=>'required',
            'phone'=>'required',

        );

        $messsages = array(
            'email.required'=>'The email field is required.',
            'name.required'=>'The name field is required.',
            'enquiry_date.required'=>'The enquiry date field is required.',
            'program_interested.required'=>'The program interested field is required.',
            'lead_status.required'=>'The lead status field is required.',
            'address.required'=>'The address field is required.',
            'city.required'=>'The city field is required.',
            'mobile.required'=>'The mobile field is required.',
            'phone.required'=>'The phone field is required.',
            'state.required'=>'The state field is required.',
            'pin.required'=>'The pin code field is required.',

        );

        $validation = Validator::make(Input::all(), $rules,$messsages);



        if ($validation->fails())
        {
            return Redirect::back()->withErrors($validation)->withInput();
        }else{

            $Leads = new Lead;
            $Leads = $Leads::find( $lead['id']);
            $Leads->enquiry_date = $request->enquiry_date;
            $Leads->name = $request->name;
            $Leads->program_interested = $request->program_interested;
            $Leads->address = $request->address;
            $Leads->city = $request->city;
            $Leads->lead_status = $request->lead_status;
            $Leads->state = $request->state;
            $Leads->pin = $request->pin;
            $Leads->phone = $request->phone;
            $Leads->mobile = $request->mobile;
            $Leads->email = $request->email;
            $Leads->save();
            Flash::success('Leads is update successfully.');
            return Redirect::to('/admin/leads')->with('success', "Leads is update successfully.");


        }


    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Lead  $lead
     * @return \Illuminate\Http\Response
     */
    public function destroy(Lead $lead)
    {
        //
        $Leads = new Lead;
        $Leads = $Leads::find( $lead['id']);
        $Leads->forceDelete();
        Flash::success('Successfully Deleted Leads!');
        return Redirect::to('/admin/leads')->with('success', "Leads is Deleted successfully.");
    }
}
