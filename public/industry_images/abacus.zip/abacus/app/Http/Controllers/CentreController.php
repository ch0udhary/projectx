<?php

namespace App\Http\Controllers;

use App\Franchises;
use App\MasterFranchises;
use App\Centres;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use Sentinel;
use Redirect;
use Response;
use Validator;
use Session;
use Flash;
use Hash;

class CentreController extends Controller
{

    public function __construct()
    {
        $this->middleware('admin');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $MasterFranchises = new MasterFranchises;
        $masterfranchisess =$MasterFranchises ::select('id','master_franchisee_code')->get();
        $Franchises = new Franchises;
        $franchises_info =$Franchises ::select('id','franchisee_code')->get();
        return view('admin.centre.create',compact('masterfranchisess','franchises_info'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
         $rules = array(
            'centre'=>'required',
            'master_franchisee_code'=>'required',
            'franchisee_code'=>'required',
        );

        $messsages = array(
            'centre.required'=>'You cant leave Centre/Name field empty',
            'master_franchisee_code.required'=>'You cant leave Master franchisee code field empty. Please select',
            'franchisee_code.required'=>'You cant leave franchisee code field empty. Please select',
        );

        $validation = Validator::make(Input::all(), $rules,$messsages);



        if ($validation->fails())
        {
            return Redirect::back()->withErrors($validation)->withInput();
        }else{
            $Centres = new Centres;
            $Centres->master_franchisee_id = $request->master_franchisee_code;
            $Centres->franchisee_id = $request->franchisee_code;
            $Centres->centre_name = $request->centre;
            $Centres->save();


            Flash::success('Centre is added successfully.');

            return Redirect::to('/admin/centres/create')->with('success', "Centre is added successfully.");;

        }


    }


    /**
     * Display the specified resource.
     *
     * @param  \App\Centres  $Centres
     * @return \Illuminate\Http\Response
     */
    public function show(Centres $Centres, $id)
    {


    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Franchises  $franchises
     * @return \Illuminate\Http\Response
     */
    public function edit(Centres $Centres, $id)
    {

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param   \App\Centres  $Centres
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Centres $Centres)
    {

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param   \App\Centres  $Centres
     * @return \Illuminate\Http\Response
     */
    public function destroy(Centres $Centres)
    {
        //
    }
}
