<?php

namespace App\Http\Controllers;

use App\IssueRequest;
use Illuminate\Http\Request;
use Validator;
class IssueRequestController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.inventory.issue_request');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'request_no' => 'required|integer',
            'franchisee_code' => 'required',           
        ]);

        if ($validator->fails()) {
            return redirect(route('issue-request.create'))->withErrors($validator)->withInput();
        }

        $saveStatus = IssueRequest::updatecreate($request);
        if($saveStatus){
            return redirect(route('issue-request.create'))->with('success','Issue Request Added Successfully.');

        }
        return redirect(route('issue-request.create'))->with('error','Some Error Occoured.');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\IssueRequest  $issueRequest
     * @return \Illuminate\Http\Response
     */
    public function show(IssueRequest $issueRequest)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\IssueRequest  $issueRequest
     * @return \Illuminate\Http\Response
     */
    public function edit(IssueRequest $issueRequest)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\IssueRequest  $issueRequest
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, IssueRequest $issueRequest)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\IssueRequest  $issueRequest
     * @return \Illuminate\Http\Response
     */
    public function destroy(IssueRequest $issueRequest)
    {
        //
    }
}
