<?php

namespace App\Http\Controllers;

use App\ItemMaster;
use App\MasterFranchises;
use Illuminate\Http\Request;
use Validator;

class ItemMasterController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $itemmasters = ItemMaster::all();
        $MasterFranchises = new MasterFranchises;
        $masterfranchisess =$MasterFranchises::select('id','master_franchisee_code')->get();
        return view('admin.inventory.itemaster.list',compact('itemmasters','masterfranchisess'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.inventory.itemaster.add');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'code' => 'required',
            'title' => 'required',           
        ]);

        if ($validator->fails()) {

            return redirect(route('item-master.create'))->withErrors($validator)->withInput();
        }

        $saveStatus = ItemMaster::updatecreate($request);
        if($saveStatus){
            return redirect(route('item-master.index'))->with('success','Item Master Added Successfully.');

        }
        return redirect(route('item-master.index'))->with('error','Some Error Occoured.');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\ItemMaster  $itemMaster
     * @return \Illuminate\Http\Response
     */
    public function show(ItemMaster $itemMaster)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\ItemMaster  $itemMaster
     * @return \Illuminate\Http\Response
     */
    public function edit(ItemMaster $itemMaster)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\ItemMaster  $itemMaster
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ItemMaster $itemMaster)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\ItemMaster  $itemMaster
     * @return \Illuminate\Http\Response
     */
    public function destroy(ItemMaster $itemMaster)
    {
        //
    }
}
