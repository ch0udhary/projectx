<?php

namespace App\Http\Controllers;

use App\PartyMaster;
use App\MasterFranchises;
use Illuminate\Http\Request;
use Validator;

class PartyMasterController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $partymasters = PartyMaster::all();
        $MasterFranchises = new MasterFranchises;
        $masterfranchisess =$MasterFranchises::select('id','master_franchisee_code')->get();
        return view('admin.inventory.partymaster.list',compact('partymasters','masterfranchisess'));
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {

        return view('admin.inventory.partymaster.add');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'code' => 'required',
            'name' => 'required',           
        ]);

        if ($validator->fails()) {

            return redirect(route('party-master.create'))->withErrors($validator)->withInput();
        }

        $saveStatus = PartyMaster::updatecreate($request);
        if($saveStatus){
            return redirect(route('party-master.index'))->with('success','Party Master Added Successfully.');

        }
        return redirect(route('party-master.index'))->with('error','Some Error Occoured.');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\PartyMaster  $partyMaster
     * @return \Illuminate\Http\Response
     */
    public function show(PartyMaster $partyMaster)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\PartyMaster  $partyMaster
     * @return \Illuminate\Http\Response
     */
    public function edit(PartyMaster $partyMaster)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\PartyMaster  $partyMaster
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, PartyMaster $partyMaster)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\PartyMaster  $partyMaster
     * @return \Illuminate\Http\Response
     */
    public function destroy(PartyMaster $partyMaster)
    {
        //
    }
}
