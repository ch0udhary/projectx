<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Sentinel;

class HomeController extends Controller
{
    //
/*    public function __construct()
    {
        $check_auth = $this->middleware('auth')->except('index');
    }*/

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request){
        if(Sentinel::check())
        {
            if (Sentinel::inRole('admin')) {
                $user = Sentinel::getUser();
                $user_id = $user->id;
                $user_email = $user->email;
                return view('admin.home');

            }


        } else

            {

                return view('auth.login');


        }


    }
}
