<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PartyMaster extends Model
{
    protected $fillable = ['code', 'name','address','gst_no'];

    
    protected function updatecreate($request,$id = null){
    	if(empty($id)){
            $partymaster = new PartyMaster;
        }else{
            $partymaster = PartyMaster::find($id);
        }
        $partymaster->fill($request->all());
        $upsave = $partymaster->save();
        return $upsave;
    }
}
