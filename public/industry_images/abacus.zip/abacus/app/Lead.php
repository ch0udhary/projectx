<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Database\Eloquent\Model;

class Lead extends Model
{
    //
    use Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'program_interested', 'address', 'city', 'state', 'pin', 'phone', 'mobile', 'email', 'lead_status','enquiry_date'
        ];

    protected $table = 'leads';


}
