<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProgramMaster extends Model
{
    protected $fillable = [ 'name'];

    protected $table = 'program_masters';
}
