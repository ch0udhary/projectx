<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TrainingFee extends Model
{
    protected $fillable = ['masterFranchisesId', 'franchisesId','centreCode','facultyId','receiptNo','manualReceiptNo','receiptDate','programId','trainingFee','feeConcession','reasonConcession','total'];

    
    protected function updatecreate($request,$id = null){
    	if(empty($id)){
            $fee = new TrainingFee;
        }else{
            $fee = TrainingFee::find($id);
        }
        $fee->fill($request->all());
        $upsave = $fee->save();
        return $upsave;
    }

    public function faculty_detail()
    {
        return $this->hasOne('App\Faculty','id','facultyId');
    }

    public function center_detail()
    {
        return $this->hasOne('App\Centres','id','centreCode');
    }
}
