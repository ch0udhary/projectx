<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class StudentFee extends Model
{
	protected $fillable = ['masterFranchisesId', 'franchisesId','centreCode','studentId','receiptNo','manualReceiptNo','receiptDate','fees','kitCost','bookCost','abacusCost','bagCost','studentId','miscellaneous','concession','reasonConcession','total'];
    protected function updatecreate($request,$id = null){
    	if(empty($id)){
            $fee = new StudentFee;
        }else{
            $fee = StudentFee::find($id);
        }
        $fee->fill($request->all());
        $upsave = $fee->save();
        return $upsave;
    }

    public function masterFranchieses()
    {
        return $this->hasOne('App\MasterFranchises','id','masterFranchisesId');
    }

    public function franchieses()
    {
        return $this->hasOne('App\Franchises','id','franchisesId');
    }

    public function center()
    {
        return $this->hasOne('App\Centres','id','centreCode');
    }

    public function student()
    {
        return $this->hasOne('App\Student','id','studentId');
    }
}
