<?php

namespace App;
use Illuminate\Notifications\Notifiable;
use Illuminate\Database\Eloquent\Model;

class Student extends Model
{
    //
    use Notifiable;


    protected $fillable = [
        'master_franchisee_id', 'franchisee_id', 'centre_id', 'registration_no', 'registration_date', 'student_photo', 'name', 'dob', 'address', 'city', 'state', 'pin', 'contact_tel_no', 'gender', 'school_name', 'school_address', 'school_city', 'school_state', 'school_pin', 'class', 'hobby_1', 'hobby_2', 'hobby_3', 'parent_id'
    ];

    protected $table = 'students';

    public function parents(){
        return $this->hasOne('App\Parents','id','parent_id');
    }
    public function programs(){
        return $this->hasOne('App\Program','registration_no','registration_no');
    }
}
