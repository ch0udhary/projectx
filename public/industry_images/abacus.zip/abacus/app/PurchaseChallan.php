<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use DB;
class PurchaseChallan extends Model
{
    protected $fillable = ['challan_number','supplier_bill_no','supplier_name','challan_date'];
    
    protected function updatecreate($request,$id = null){
    	if(empty($id)){
            $purchasechallan = new PurchaseChallan;
        }else{
            $purchasechallan = PurchaseChallan::find($id);
        }
        $purchasechallan->fill($request->all());
        $upsave = $purchasechallan->save();
        if(!empty($request->itemcount) && !empty($purchasechallan->id)){
            for($i = 0; $i < $request->itemcount; $i++){
                DB::table('purchase_challans_item')->insert(
                    ['challan_id' => $purchasechallan->id, 
                    'item_code' => $request->item_code[$i],
                    'quantity' => $request->quantity[$i],
                    'purchase_price' => $request->purchase_price[$i],
                    'amount' => $request->amount[$i]
                    ]
       
                );
            }
        }       

        return $upsave;
    }
}
