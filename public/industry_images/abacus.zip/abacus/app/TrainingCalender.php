<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TrainingCalender extends Model
{
    protected $fillable = ['trainingDate', 'level','programId'];

    
    protected function updatecreate($request,$id = null){
    	if(empty($id)){
            $fee = new TrainingCalender;
        }else{
            $fee = TrainingCalender::find($id);
        }
        $fee->fill($request->all());
        $upsave = $fee->save();
        return $upsave;
    }

    public function program()
    {
        return $this->hasOne('App\ProgramMaster','id','programId');
    }

    public function level_rel()
    {
        return $this->hasOne('App\ProgramLevel','id','level');
    }
}
