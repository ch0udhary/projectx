<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ApplyCertificate extends Model
{
    protected $fillable = ['masterFranchisesId','franchisesId','centreCode','studentId','dateCompletion','certificateDate','obtainMarks','outOf','gradeObtain','certificateStatus','parentsFeedback'];

    protected function updatecreate($request,$id = null){
    	if(empty($id)){
            $apply = new ApplyCertificate;
        }else{
            $apply = ApplyCertificate::find($id);
        }
        $apply->fill($request->all());
        $upsave = $apply->save();
        return $upsave;
    }

}

