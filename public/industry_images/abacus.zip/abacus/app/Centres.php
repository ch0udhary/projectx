<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Database\Eloquent\Model;
class Centres extends Model
{
    //

    //
    use Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'master_franchisee_id', 'franchisee_id', 'centre_name'
    ];

    protected $table = 'centres';

}
