<?php

namespace App;
use Illuminate\Notifications\Notifiable;
use Illuminate\Database\Eloquent\Model;

class Program extends Model
{
    use Notifiable;


    protected $fillable = [
        'title', 'lavel_title', 'class', 'time_slote', 'registration_no', 'master_franchises_id', 'franchises_id', 'centre_code', 'faculty_id'
    ];

    protected $table = 'program';
}
