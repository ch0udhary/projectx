<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DropOut extends Model
{
    protected $fillable = ['masterFranchisesId','franchisesId','centreCode','withdrawlDate','withdrawlReason','studentId'];


    protected function updatecreate($request,$id = null){
    	if(empty($id)){
            $drop = new DropOut;
        }else{
            $drop = DropOut::find($id);
        }
        $drop->fill($request->all());
        $upsave = $drop->save();
        return $upsave;
    }

}
