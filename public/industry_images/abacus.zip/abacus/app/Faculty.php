<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Faculty extends Model
{
    protected $fillable = ['masterFranchisesId','franchisesId','centreCode','facultyType','facultyCode','facultyName','dob','address','city','state','pincode','education','skills','residenceNo','mobileNo','email','experienceTotal','experienceAbcus','experienceVMath','trainingRequire'];


    protected function updatecreate($request,$id = null){
    	if(empty($id)){
            $drop = new Faculty;
        }else{
            $drop = Faculty::find($id);
        }
        $drop->fill($request->all());
        $upsave = $drop->save();
        return $upsave;
    }

    public function masterFranchieses()
    {
        return $this->hasOne('App\MasterFranchises','id','masterFranchisesId');
    }

    public function center()
    {
        return $this->hasOne('App\Centres','id','centreCode');
    }

    
}
