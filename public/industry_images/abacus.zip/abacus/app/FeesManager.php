<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FeesManager extends Model
{
	protected $fillable = ['programId', 'level','price','duration'];

    public function getListing(){
    	$forum = FeesManager::join('program_manager','fees_managers.programId','=','program_manager.id')
    		->select('program_manager.id as pid','fees_managers.*','program_manager.title')		    
		    ->get();
		return $forum;
    }

    protected function updatecreate($request,$id = null){
    	if(empty($id)){
            $fee = new FeesManager;
        }else{
            $fee = FeesManager::find($id);
        }
        $fee->fill($request->all());
        $upsave = $fee->save();
        return $upsave;
    }

    public function prList(){
    	return \DB::table('program_manager')->get();
    }

    
}
