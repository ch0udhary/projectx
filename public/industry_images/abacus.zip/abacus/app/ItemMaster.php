<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ItemMaster extends Model
{
    protected $fillable = ['code','title'];

    
    protected function updatecreate($request,$id = null){
    	if(empty($id)){
            $itemaster = new ItemMaster;
        }else{
            $itemaster = ItemMaster::find($id);
        }
        $itemaster->fill($request->all());
        $upsave = $itemaster->save();
        return $upsave;
    }
}
