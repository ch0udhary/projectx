<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use DB;
class IssueRequest extends Model
{
    protected $fillable = ['request_no','request_date','franchisee_code'];
    
    protected function updatecreate($request,$id = null){
    	if(empty($id)){
            $issuerequest = new IssueRequest;
        }else{
            $issuerequest = IssueRequest::find($id);
        }
        $issuerequest->fill($request->all());
        $upsave = $issuerequest->save();
        if(!empty($request->itemcount) && !empty($issuerequest->id)){
            for($i = 0; $i < $request->itemcount; $i++){
                DB::table('issue_requests_item')->insert(
                    ['request_id' => $issuerequest->id, 
                    'item_code' => $request->item_code[$i],
                    'quantity' => $request->quantity[$i],                  
                    ]
       
                );
            }
        }

        return $upsave;
    }
}
