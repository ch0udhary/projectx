<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Database\Eloquent\Model;
class Franchises extends Model
{
    //

    //
    use Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'master_franchisee_id', 'franchisee_code', 'date_of_agreement', 'name', 'date_of_establishment', 'address', 'city', 'state', 'pin', 'phone_no', 'mobile_no', 'email', 'education', 'years_experience_in_teaching', 'years_experience_in_business', 'licensed_territory', 'pin_code', 'license_certificate_no', 'license_period_from', 'license_period_to', 'franchisee_license_fee', 'license_fee_receipt_no', 'receipt_date', 'renewal_fee', 'renewed_period_from', 'renewed_period_to', 'royalty', 'material_discount'
    ];

    protected $table = 'franchises';

    public function masterfrancies(){
        return $this->hasOne('App\MasterFranchises','id','master_franchisee_id')->select('id','master_franchisee_code');
    }

}
