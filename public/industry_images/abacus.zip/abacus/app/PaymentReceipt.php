<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PaymentReceipt extends Model
{
    protected $fillable = ['master_franchisee_code','franchisee_code','amount','payment_mode','payment_date','payment_mode_no','bank'];
    
    protected function updatecreate($request,$id = null){
    	if(empty($id)){
            $paymentreceipt = new PaymentReceipt;
        }else{
            $paymentreceipt = PaymentReceipt::find($id);
        }
        $paymentreceipt->fill($request->all());
        $upsave = $paymentreceipt->save();
        return $upsave;
    }
}
