<?php

namespace App;
use Illuminate\Notifications\Notifiable;
use Illuminate\Database\Eloquent\Model;

class Parents extends Model
{
    //
    use Notifiable;


    protected $fillable = [
        'ftitle','fathers_name', 'fathers_occupation', 'fathers_office_address', 'fathers_city', 'fathers_state', 'fathers_pin', 'fathers_office_tel_no', 'fathers_mobile_no', 'fathers_email','mtitle', 'mothers_name', 'mothers_occupation', 'mothers_office_address', 'mothers_city', 'mothers_state', 'mothers_pin', 'mothers_office_tel_no', 'mothers_mobile_no', 'mothers_email', 'referred_by', 'purpose_of_enrollment'
    ];

    protected $table = 'parents';

}
