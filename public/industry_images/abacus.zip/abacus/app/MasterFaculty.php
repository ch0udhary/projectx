<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MasterFaculty extends Model
{
    //
	
	
	 public function getFnameAttribute($value)
    {
        return ucfirst($value);
    } 
	public function getGenderAttribute($value)
    {
        return ucfirst($value);
    }public function getLnameAttribute($value)
    {
        return ucfirst($value);
    }
	
	
}
