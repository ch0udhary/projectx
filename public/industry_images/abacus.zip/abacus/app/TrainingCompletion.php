<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TrainingCompletion extends Model
{
    protected $fillable = ['facultyId', 'programId','level','completionDate','examDate','obtainMarks','outOf','trainerName','certificateNo','certificateDate'];

    
    protected function updatecreate($request,$id = null){
    	if(empty($id)){
            $fee = new TrainingCompletion;
        }else{
            $fee = TrainingCompletion::find($id);
        }
        $fee->fill($request->all());
        $upsave = $fee->save();
        return $upsave;
    }

    /*public function getListing(){
        $forum = TrainingCompletion::join('program_manager','training_completions.facultyId','=','program_manager.id')
            ->select('program_manager.id as pid','fees_managers.*','program_manager.title')         
            ->get();
        return $forum;
    }*/
}
