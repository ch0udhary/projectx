<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class GradeMaster extends Model
{
    protected $fillable = ['percentage_from','percentage_to','grade'];
}
