<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DispatchChallan extends Model
{
    protected $fillable = ['request_id','challan_id','delivery_date','delivery_executive'];
    
    protected function updatecreate($request,$id = null){
    	if(empty($id)){
            $dispatchchallan = new DispatchChallan;
        }else{
            $dispatchchallan = DispatchChallan::find($id);
        }
        $dispatchchallan->fill($request->all());
        $upsave = $dispatchchallan->save();
        
        return $upsave;
    }}
