<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

/*Route::get('/', function () {
    echo "sjkfjsldf";
    die;
});*/
Route::get('/','HomeController@index')->name('home');

Route::get('register','UserController@register')->name('register');
Route::post('register','UserController@postregister');

Route::get('login','UserController@login')->name('login');
Route::post('login','UserController@postlogin');
Route::post('logout','UserController@logout')->name('logout');
Route::get('logout','UserController@logout');




Route::group(['prefix' => 'admin', 'middlewareGroups' => ['web']], function () {
    Route::resource('/leads', 'LeadController');
    Route::resource('/franchises', 'FranchisesController');
    Route::resource('/master-franchises', 'MasterFranchisesController');
    Route::resource('/centres', 'CentreController');
    Route::resource('/franchisee-mapping','MappingController');
    Route::resource('/students','StudentController');
    Route::get('/add-program','StudentController@add_program');
    Route::post('/students/ajaxRequest','StudentController@ajaxRequest');
    Route::post('/students/store-program','StudentController@saveProgram');
    Route::post('/franchisee-mapping/ajaxRequest','MappingController@ajaxRequest');
    Route::resource('/fees-master', 'FeesManagerContoller');
    Route::resource('/center-faculty', 'MasterFacultyController');

    //Apply Certificate
    Route::get('/apply-certificate','StudentController@applyCertificate')->name('applyCertificate');
    Route::post('/apply-certificate','StudentController@applyCertificatePost')->name('applyCertificate');
    Route::get('/issue-certificate','StudentController@issueCertificate');
    Route::get('/drop-out','StudentController@dropOut')->name('dropOut');
    Route::post('/drop-out','StudentController@dropOutPost')->name('dropOut');

    Route::get('/grade-master','StudentController@createGrade')->name('gradeMaster');
    Route::post('/grade-master','StudentController@saveGrade')->name('gradeMastersubmit');
    Route::post('/getfaculty','StudentController@getfaculty')->name('centergetfaculty');
    Route::post('/getfaculty_list','StudentController@getfaculty_list')->name('getfaculty_list');


    //GEnerate Receipt

    Route::get('/generate-receipt', 'FeesManagerContoller@generatereceipt')->name('generatereceipt');
    Route::post('/get-franchisee', 'FeesManagerContoller@getFranchisee')->name('getFranchisee');
    Route::post('/get-center', 'FeesManagerContoller@getCenter')->name('getcenter');
    Route::post('/get-student', 'FeesManagerContoller@getStudent')->name('getstudent');
    Route::post('/save-fees', 'FeesManagerContoller@savefees')->name('savefees');

    Route::get('/fee-list', 'FeesManagerContoller@feelist')->name('feelist');

    Route::post('/fee-search', 'FeesManagerContoller@feeserach')->name('feeserach');
    Route::get('/fee-pending-list', 'FeesManagerContoller@feelist')->name('feelistpending');
    Route::resource('/attendance', 'AttendanceController');
    Route::post('/get-student-attendance', 'AttendanceController@getStudent')->name('getstudentattendance');

    Route::resource('/program-master', 'ProgramMasterController');
    Route::resource('/program-level', 'ProgramLevelController');

    Route::post('/get_levellist','ProgramLevelController@get_levellist')->name('getlevellist');
    Route::post('/getprogramlevel','StudentController@getprogramlevel')->name('getprogramlevel');

    //Faculty Management

    Route::resource('/faculty', 'FacultyController');

    Route::post('/faculty-list', 'FacultyController@facultylist')->name('facultylist');

    Route::post('/get-faculty', 'FacultyController@getfaculty')->name('getfaculty');
    //Training Fee
    Route::resource('/training-fee', 'TrainingFeeController');

    //Training Calender
    Route::resource('/training-calender', 'TrainingCalenderController');

    Route::post('/level-list', 'TrainingCalenderController@levellist')->name('getlevel');

    //Training Completion
    Route::resource('/training-completion', 'TrainingCompletionController');

    //Party Master
    Route::resource('/party-master', 'PartyMasterController');

    //Item Master
    Route::resource('/item-master', 'ItemMasterController');

    //Item Master
    Route::resource('/purchase-challan', 'PurchaseChallanController');

    //Item Master
    Route::resource('/issue-request', 'IssueRequestController');

    //Item Master
    Route::resource('/dispatch-challan', 'DispatchChallanController');
    Route::post('/dispatch-challan/dispatch', 'DispatchChallanController@create')->name('dispatch-newcreate');

    //Item Master
    Route::resource('/payment-receipt', 'PaymentReceiptController');
});
