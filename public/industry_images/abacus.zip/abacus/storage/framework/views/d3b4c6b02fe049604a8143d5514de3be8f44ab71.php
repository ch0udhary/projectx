<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="Unify Admin Panel" />
    <meta name="keywords" content="Login, Unify Login, Admin, Dashboard, Bootstrap4, Sass, CSS3, HTML5, Responsive Dashboard, Responsive Admin Template, Admin Template, Best Admin Template, Bootstrap Template, Themeforest" />
    <meta name="author" content="Bootstrap Gallery" />
    <link rel="shortcut icon" href="img/favicon.ico" />
    <title>Amma India Admin Dashboard - Login</title>

    <!-- Common CSS -->
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/bootstrap.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(URL::asset('fonts/icomoon/icomoon.css')); ?>" />

    <!-- Mian and Login css -->
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/main.css')); ?>" />
    <link href="<?php echo e(URL::asset('css/toastr.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(URL::asset('css/jquery.toast.css')); ?>" rel="stylesheet">
</head>

<body class="login-bg">

<div class="container">
    <div class="login-screen row align-items-center">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
            <?php echo $__env->yieldContent('before-content'); ?>



         
            <?php echo $__env->yieldContent('content'); ?>
            <form method="POST" action="<?php echo e(route('login')); ?>">
                <?php echo csrf_field(); ?>
                <div class="login-container">
                    <div class="row no-gutters">
                        <div class="col-xl-4 col-lg-5 col-md-6 col-sm-12">
                            <div class="login-box">
                                <a href="#" class="login-logo">
                                    <img src="img/logo.png" alt="Amma India Admin Dashboard" />
                                </a>
                                <div class="input-group">
                                    <span class="input-group-addon" id="username"><i class="icon-account_circle"></i></span>
                                   <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>"  placeholder="Username" aria-label="username" aria-describedby="username" name="email" value="<?php echo e(old('email')); ?>" required autofocus>
                                    <?php if($errors->has('email')): ?>
                                        <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                                <br>
                                <div class="input-group">
                                    <span class="input-group-addon" id="password"><i class="icon-verified_user"></i></span>

                                    <input id="password" type="password" placeholder="Password" aria-label="Password" aria-describedby="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required>

                                    <?php if($errors->has('password')): ?>
                                        <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                    <?php endif; ?>

                                </div>
                                <div class="actions clearfix">
                                    <a href="forgot-pwd.html">Lost password?</a>
                                    <input type="submit" class="btn btn-primary" value="Login">
                                </div>
                                <div class="or"></div>
                                <div class="mt-4">
                                    <a href="<?php echo e(route('register')); ?>" class="additional-link">Don't have an Account? <span>Create Now</span></a>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-8 col-lg-7 col-md-6 col-sm-12">
                            <div class="login-slider"></div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<footer class="main-footer no-bdr fixed-btm">
    <div class="container">
        Copyright Amma India Admin 2018.
    </div>
</footer>

<script src="<?php echo e(URL::asset('js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('js/toastr.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(URL::asset('js/ui-toastr.min.js')); ?>" type="text/javascript"></script>
<!-- If using flash()->important() or flash()->overlay(), you'll need to pull in the JS for Twitter Bootstrap. -->

<?php if(session()->has('flash_notification')): ?>
    <script>
        jQuery( document ).ready(function() {
    <?php $__currentLoopData = session('flash_notification', collect())->toArray(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                toastr.<?php echo ($message['level'] == 'danger')?'error':$message['level']; ?>('<?php echo $message['message'];?>');
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        });


    </script>

<?php endif; ?>
</body>
</html>

