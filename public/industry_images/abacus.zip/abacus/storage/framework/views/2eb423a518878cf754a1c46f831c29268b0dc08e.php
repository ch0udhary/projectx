<?php $__env->startSection('content'); ?>
<div class="app-main">
    <!-- BEGIN .main-heading -->
    <header class="main-heading">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xl-8 col-lg-8 col-md-8 col-sm-8">
                    <div class="page-icon">
                        <i class="icon-layers"></i>
                    </div>
                    <div class="page-title">
                        <h5>Generate Receipt</h5>
                        <h6 class="sub-heading">Welcome to Amma</h6>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4">
                    <div class="right-actions">
                        <!-- <a href="#" class="btn btn-primary float-right" data-toggle="tooltip" data-placement="left" title="Download Reports">
                            <i class="icon-download4"></i>
                        </a> -->
                    </div>
                </div>
            </div>
        </div>
    </header>
<div class="main-content">
	
	<!-- Row start -->
	<div class="row gutters">
		<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
			<div class="card">
				<div class="card-header">Issue Certificate</div>
				<div class="card-body">
               	  <div class="row gutters">
                        <div class="col-sm-6 form-group">
                            <label for="">Master Franchisee</label>
                            <select class="form-control">
                                <option selected>Select</option>
                                <option>0001</option>
                                <option>0002</option>
                                <option>0003</option>
                                <option>0004</option>
                                <option>0005</option>
                            </select>
                        </div>
                        <div class="col-sm-6 form-group">
                            <label for="">Centre</label>
                            <select class="form-control">
                                <option selected>Select Centre</option>
                                <option>Rajauri Garden</option>
                                <option>Tilak Nagar</option>
                                <option>Malviya Nagar</option>
                                <option>Lajpat Nagar</option>
                                <option>Munirka</option>
                            </select>
                        </div>
                        <div class="col-sm-6 form-group">
                            <label for="">From Date</label>
                            <input class="form-control" type="date" placeholder="">
                        </div>
                        <div class="col-sm-6 form-group">
                            <label for="">To Date</label>
                            <input class="form-control" type="date" placeholder="">                                                
                        </div>
                        
                    </div>
					<table id="basicExample" class="table table-list table-striped table-bordered">
						<thead>
							<tr>
								<th width="15%">Student Name</th>
								<th width="15%">Student Reg. No.</th>
                                <th width="20%">Program</th>
                                <th width="10%">Level</th>
								<th width="10%">Date of Completion</th>
								<th width="12%">Certificate Date</th>
								<th width="12%">Certificate No</th>
								<th width="18%">Issue Certifcate</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td>Tiger Nixon</td>
								<td>6945</td>
								<td>ELMAS Abacus Program</td>
								<td>Level-III</td>
								<td>10/03/2018</td>
								<td><input style="width:auto;" class="form-control" type="date"></td>
								<td><input class="form-control" type="text" style="width:auto;" placeholder="Certificate No."></td>
								<td><button type="submit" class="delete btn btn-primary btn-sm">Issue Certifcate</button><span class="controls"><a href="#"><i class="fa fa-pencil" aria-hidden="true"></i></a><a href="#"><i class="fa fa-trash-o" aria-hidden="true"></i></a></span></td>
							</tr>
							<tr>
								<td>Zorita Serrano</td>
								<td>7797</td>
								<td>ELMAS Abacus Program</td>
								<td>Level-III</td>
								<td>10/03/2018</td>
								<td><input style="width:auto;" class="form-control" type="date"></td>
								<td><input class="form-control" type="text" style="width:auto;" placeholder="Certificate No."></td>
								<td><button type="submit" class="delete btn btn-primary btn-sm">Issue Certifcate</button><span class="controls"><a href="#"><i class="fa fa-pencil" aria-hidden="true"></i></a><a href="#"><i class="fa fa-trash-o" aria-hidden="true"></i></a></span></td>
							</tr>
							<tr>
								<td>Jennifer Acosta</td>
								<td>6866</td>
								<td>ELMAS Abacus Program</td>
								<td>Level-III</td>
								<td>10/03/2018</td>
								<td><input style="width:auto;" class="form-control" type="date"></td>
								<td><input class="form-control" type="text"  style="width:auto;" placeholder="Certificate No."></td>
								<td><button type="submit" class="delete btn btn-primary btn-sm">Issue Certifcate</button><span class="controls"><a href="#"><i class="fa fa-pencil" aria-hidden="true"></i></a><a href="#"><i class="fa fa-trash-o" aria-hidden="true"></i></a></span></td>
							</tr>
							<tr>
								<td>Cara Stevens</td>
								<td>9897</td>
								<td>ELMAS Abacus Program</td>
								<td>Level-III</td>
								<td>10/03/2018</td>
								<td><input style="width:auto;" class="form-control" type="date"></td>
								<td><input class="form-control" type="text" style="width:auto;" placeholder="Certificate No."></td>
								<td><button type="submit" class="delete btn btn-primary btn-sm">Issue Certifcate</button><span class="controls"><a href="#"><i class="fa fa-pencil" aria-hidden="true"></i></a><a href="#"><i class="fa fa-trash-o" aria-hidden="true"></i></a></span></td>
							</tr>
							<tr>
								<td>Hermione Butler</td>
								<td>3598</td>
								<td>ELMAS Abacus Program</td>
								<td>Level-III</td>
								<td>10/03/2018</td>
								<td><input style="width:auto;" class="form-control" type="date"></td>
								<td><input class="form-control" type="text" style="width:auto;" placeholder="Certificate No."></td>
								<td><button type="submit" class="delete btn btn-primary btn-sm">Issue Certifcate</button><span class="controls"><a href="#"><i class="fa fa-pencil" aria-hidden="true"></i></a><a href="#"><i class="fa fa-trash-o" aria-hidden="true"></i></a></span></td>
							</tr>
							<tr>
								<td>Lael Greer</td>
								<td>4225</td>
								<td>ELMAS Abacus Program</td>
								<td>Level-III</td>
								<td>10/03/2018</td>
								<td><input style="width:auto;" class="form-control" type="date"></td>
								<td><input class="form-control" type="text"  style="width:auto;" placeholder="Certificate No."></td>
								<td><button type="submit" class="delete btn btn-primary btn-sm">Issue Certifcate</button><span class="controls"><a href="#"><i class="fa fa-pencil" aria-hidden="true"></i></a><a href="#"><i class="fa fa-trash-o" aria-hidden="true"></i></a></span></td>
							</tr>
							<tr>
								<td>Jonas Alexander</td>
								<td>8075</td>
								<td>ELMAS Abacus Program</td>
								<td>Level-III</td>
								<td>10/03/2018</td>
								<td><input style="width:auto;" class="form-control" type="date"></td>
								<td><input class="form-control" style="width:auto;" type="text" placeholder="Certificate No."></td>
								<td><button type="submit" class="delete btn btn-primary btn-sm">Issue Certifcate</button><span class="controls"><a href="#"><i class="fa fa-pencil" aria-hidden="true"></i></a><a href="#"><i class="fa fa-trash-o" aria-hidden="true"></i></a></span></td>
							</tr>
							<tr>
								<td>Shad Decker</td>
								<td>7364</td>
								<td>ELMAS Abacus Program</td>
								<td>Level-III</td>
								<td>10/03/2018</td>
								<td><input style="width:auto;" class="form-control" type="date"></td>
								<td><input class="form-control" type="text" style="width:auto;" placeholder="Certificate No."></td>
								<td><button type="submit" class="delete btn btn-primary btn-sm">Issue Certifcate</button><span class="controls"><a href="#"><i class="fa fa-pencil" aria-hidden="true"></i></a><a href="#"><i class="fa fa-trash-o" aria-hidden="true"></i></a></span></td>
							</tr>
							<tr>
								<td>Michael Bruce</td>
								<td>8852</td>
								<td>ELMAS Abacus Program</td>
								<td>Level-III</td>
								<td>10/03/2018</td>
								<td><input style="width:auto;" class="form-control" type="date"></td>
								<td><input class="form-control"  style="width:auto;"type="text" placeholder="Certificate No."></td>
								<td><button type="submit" class="delete btn btn-primary btn-sm">Issue Certifcate</button><span class="controls"><a href="#"><i class="fa fa-pencil" aria-hidden="true"></i></a><a href="#"><i class="fa fa-trash-o" aria-hidden="true"></i></a></span></td>
							</tr>
							<tr>
								<td>Donna Snider</td>
								<td>3466</td>
								<td>ELMAS Abacus Program</td>
								<td>Level-III</td>
								<td>10/03/2018</td>
								<td><input style="width:auto;" class="form-control" type="date"></td>
								<td><input style="width:auto;" class="form-control" type="text" placeholder="Certificate No."></td>
								<td><button type="submit" class="delete btn btn-primary btn-sm">Issue Certifcate</button><span class="controls"><a href="#"><i class="fa fa-pencil" aria-hidden="true"></i></a><a href="#"><i class="fa fa-trash-o" aria-hidden="true"></i></a></span></td>
							</tr>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
	<!-- Row ends -->
	
</div>
<!-- END: .main-content -->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>