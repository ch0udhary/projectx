<?php $__env->startSection('content'); ?>
<div class="app-main">
    <!-- BEGIN .main-heading -->
    <header class="main-heading">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xl-8 col-lg-8 col-md-8 col-sm-8">
                    <div class="page-icon">
                        <i class="icon-layers"></i>
                    </div>
                    <div class="page-title">
                        <h5>Generate Receipt</h5>
                        <h6 class="sub-heading">Welcome to Amma</h6>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4">
                    <div class="right-actions">
                        <!-- <a href="#" class="btn btn-primary float-right" data-toggle="tooltip" data-placement="left" title="Download Reports">
                            <i class="icon-download4"></i>
                        </a> -->
                    </div>
                </div>
            </div>
        </div>
    </header>
<!-- BEGIN .main-content -->
<div class="main-content">
<?php if(\Session::has('success')): ?>
    <div class="alert alert-success">
        <ul>
            <li><?php echo \Session::get('success'); ?></li>
        </ul>
    </div>
<?php endif; ?>
<?php if(\Session::has('error')): ?>
    <div class="alert alert-danger">
        <ul>
            <li><?php echo \Session::get('error'); ?></li>
        </ul>
    </div>
<?php endif; ?>
 <!-- Row start -->
<div class="row gutters">
    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
        <!-- Row start -->
        <div class="row gutters">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                <div class="card">
                    <div class="card-body">
                        <form method="post" action="<?php echo e(route('savefees')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="row gutters">
                            <div class="col-md-8 mx-auto col-sm-12">
                                <div class="row">
                                    <div class="form-group col-sm-4">
                                        <label for="">Master Franchisee</label>
                                        <select class="form-control    <?php echo e($errors->has('masterFranchisesId') ? ' is-invalid' : ''); ?>" name="masterFranchisesId" id="franchisee_code">
                                        <option selected value="">Select</option>
                                        <?php if(!empty($masterfranchisess)): ?>
                                        <?php $__currentLoopData = $masterfranchisess; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($mf->id); ?>"><?php echo e($mf->master_franchisee_code); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                                        <?php endif; ?>
                                        </select>
                                        <?php if($errors->has('masterFranchisesId')): ?>
                                        <span class="invalid-feedback">
                                            <strong><?php echo e($errors->first('masterFranchisesId')); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group col-sm-4 ">
                                        <label for="">Franchisee Code</label>
                                        <select class="form-control <?php echo e($errors->has('franchisesId') ? ' is-invalid' : ''); ?>" id="franchise" name="franchisesId">
                                            <option selected value="">Select</option>
                                            
                                        </select>
                                        <?php if($errors->has('franchisesId')): ?>
                                        <span class="invalid-feedback">
                                            <strong><?php echo e($errors->first('franchisesId')); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group col-sm-4 <?php echo e($errors->has('centreCode') ? ' is-invalid' : ''); ?>">
                                        <label for="">Centre</label>
                                        <select class="form-control " id="centreCode" name="centreCode">
                                            <option selected>Select Centre</option>
                                            
                                        </select>
                                        <?php if($errors->has('centreCode')): ?>
                                        <span class="invalid-feedback">
                                            <strong><?php echo e($errors->first('centreCode')); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="row gutters">
                                        <div class="col">
                                            <input class="form-control" placeholder="Student registration number" type="text" id="regnumber">
                                        </div>
                                        <div class="col">
                                            <button type="button" class="btn btn-primary" id="getDetails">Get Details</button>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group studentDeatils">
                                 
                                </div> 
                                <div class="row">
                                    <div class="form-group col-sm-4 ">
                                        <label for="">System Receipt No.</label>
                                        <input class="form-control <?php echo e($errors->has('receiptNo') ? ' is-invalid' : ''); ?>" placeholder="11200017325 (Franchisee code, running number)" type="text" name="receiptNo">
                                        <?php if($errors->has('receiptNo')): ?>
                                        <span class="invalid-feedback">
                                            <strong><?php echo e($errors->first('receiptNo')); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group col-sm-4 ">
                                        <label for="">Printed Manual Receipt No.</label>
                                        <input name="manualReceiptNo" class="form-control <?php echo e($errors->has('manualReceiptNo') ? ' is-invalid' : ''); ?>" placeholder="15225" type="text">
                                        <?php if($errors->has('manualReceiptNo')): ?>
                                        <span class="invalid-feedback">
                                            <strong><?php echo e($errors->first('manualReceiptNo')); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group col-sm-4">
                                        <label for="">Receipt Date</label>
                                        <input name="receiptDate" class="form-control <?php echo e($errors->has('receiptDate') ? ' is-invalid' : ''); ?>" placeholder="" type="date">
                                        <?php if($errors->has('receiptDate')): ?>
                                        <span class="invalid-feedback">
                                            <strong><?php echo e($errors->first('receiptDate')); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="form-group col-sm-4">
                                        <label for="">Fee</label>
                                        <input name="fees" class="form-control <?php echo e($errors->has('fees') ? ' is-invalid' : ''); ?>" placeholder="Rs.2500.00" type="text">
                                        <?php if($errors->has('fees')): ?>
                                        <span class="invalid-feedback">
                                            <strong><?php echo e($errors->first('fees')); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group col-sm-4">
                                        <label for="">Student Kit Cost</label>
                                        <input name="kitCost" class="form-control <?php echo e($errors->has('kitCost') ? ' is-invalid' : ''); ?>" placeholder="Rs.800.00" type="text">
                                        <?php if($errors->has('kitCost')): ?>
                                        <span class="invalid-feedback">
                                            <strong><?php echo e($errors->first('kitCost')); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group col-sm-4">
                                        <label for="">Books Cost</label>
                                        <input name="bookCost" class="form-control <?php echo e($errors->has('bookCost') ? ' is-invalid' : ''); ?>" placeholder="Rs.200.00" type="text">
                                        <?php if($errors->has('bookCost')): ?>
                                        <span class="invalid-feedback">
                                            <strong><?php echo e($errors->first('bookCost')); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="form-group col-sm-4">
                                        <label for="">Abacus Cost</label>
                                        <input  name="abacusCost" class="form-control <?php echo e($errors->has('abacusCost') ? ' is-invalid' : ''); ?>" placeholder="Rs.200.00" type="text">
                                        <?php if($errors->has('abacusCost')): ?>
                                        <span class="invalid-feedback">
                                            <strong><?php echo e($errors->first('abacusCost')); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group col-sm-4">
                                        <label for="">Bag Cost</label>
                                        <input name="bagCost" class="form-control <?php echo e($errors->has('bagCost') ? ' is-invalid' : ''); ?>" placeholder="Rs.200.00" type="text">
                                        <?php if($errors->has('bagCost')): ?>
                                        <span class="invalid-feedback">
                                            <strong><?php echo e($errors->first('bagCost')); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group col-sm-4">
                                        <label for="">Miscellaneous </label>
                                        <input name="miscellaneous" class="form-control <?php echo e($errors->has('miscellaneous') ? ' is-invalid' : ''); ?>" placeholder="Rs.200.00" type="text">
                                        <?php if($errors->has('miscellaneous')): ?>
                                        <span class="invalid-feedback">
                                            <strong><?php echo e($errors->first('miscellaneous')); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="form-group col-sm-6">
                                        <label for="">Fee Concession, if any</label>
                                        <input  name="concession" class="form-control <?php echo e($errors->has('concession') ? ' is-invalid' : ''); ?>" placeholder="Rs.-500.00" type="text">
                                        <?php if($errors->has('concession')): ?>
                                        <span class="invalid-feedback">
                                            <strong><?php echo e($errors->first('concession')); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group col-sm-6">
                                        <label for="">Reason for Concession</label>
                                        <input name="reasonConcession" class="form-control <?php echo e($errors->has('reasonConcession') ? ' is-invalid' : ''); ?>" placeholder="Defense Personnel" type="text">
                                        <?php if($errors->has('reasonConcession')): ?>
                                        <span class="invalid-feedback">
                                            <strong><?php echo e($errors->first('reasonConcession')); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="">Total</label>
                                    <input name="total" class="form-control <?php echo e($errors->has('total') ? ' is-invalid' : ''); ?>" placeholder="Rs.3400.00" type="text">
                                    <?php if($errors->has('total')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('total')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class="form-group row gutters">
                            <div class="col-sm-3 mx-auto">
                                <button type="submit" class="btn btn-primary btn-lg btn-block">Submit</button>
                            </div>
                        </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!-- Row end -->
    </div>
</div>
<!-- Row ends -->   
    
    
</div>
<!-- END: .main-content -->
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>

<script>
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    $('#franchisee_code').change(function(e) {
        e.preventDefault(); // does not go through with the link.
        var tt = $(this,'option:selected').val();
        $.post({
            type:'POST',
            data: {'masterId':$(this).val()},
            url: "<?php echo e(route('getFranchisee')); ?>"
        }).done(function (data) {
            $('#franchise').html(data);            
           
        });
    });
    $('#franchise').change(function(e) {
        e.preventDefault(); // does not go through with the link.
        var tt = $(this,'option:selected').val();
        $.post({
            type:'POST',
            data: {'id':$(this).val(),'masterId' :  $('#franchisee_code ,option:selected').val()},
            url: "<?php echo e(route('getcenter')); ?>"
        }).done(function (data) {
            $('#centreCode').html(data);            
           
        });
    });
    $('#getDetails').on('click',function(e) {
        e.preventDefault(); // does not go through with the link.
        if($.trim($('#regnumber').val()) == ''){
            alert("Please Enter Registration Number.")
        }
        var tt = $('#regnumber').val();
        $.post({
            type:'POST',
            data: {'regNo':$('#regnumber').val()},
            url: "<?php echo e(route('getstudent')); ?>"
        }).done(function (data) {
            $('.studentDeatils').html(data);            
           
        });
    });
</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>