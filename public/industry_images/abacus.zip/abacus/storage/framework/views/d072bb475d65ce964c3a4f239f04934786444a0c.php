<?php $__env->startSection('stylesheet'); ?>
    <link href="<?php echo e(URL::asset('css/toastr.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(URL::asset('css/jquery.toast.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php if(Session::has('message')): ?>
    <p class="success <?php echo e(Session::get('alert-class', 'alert-info')); ?>"><?php echo e(Session::get('message')); ?></p>
<?php endif; ?>
<div class="app-main">
    <!-- BEGIN .main-heading -->
    <header class="main-heading">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xl-8 col-lg-8 col-md-8 col-sm-8">
                    <div class="page-icon">
                        <i class="icon-layers"></i>
                    </div>
                    <div class="page-title">
                        <h5>Grade Master</h5>
                        <h6 class="sub-heading">Welcome to Amma</h6>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4">
                    <div class="right-actions">
                        <!-- <a href="#" class="btn btn-primary float-right" data-toggle="tooltip" data-placement="left" title="Download Reports">
                            <i class="icon-download4"></i>
                        </a> -->
                    </div>
                </div>
            </div>
        </div>
    </header>
<!-- BEGIN .main-content -->
<div class="main-content">


 <!-- Row start -->
<div class="row gutters">
    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
        <!-- Row start -->
        <div class="row gutters">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                <div class="card">
                    <div class="card-body">
                       <form method="post" action="<?php echo e(route('gradeMastersubmit')); ?>">
                        <?php echo csrf_field(); ?>
                         <div class="row gutters">
                            <div class="col-md-6 mx-auto col-sm-12">
                                <div class="row">
                                    <div class="form-group col-sm-6">
                                        <label for="">Percentage from</label>
                                        <select class="form-control  <?php echo e($errors->has('percentage_from') ? ' is-invalid' : ''); ?>" name="percentage_from">
                                            <option value="">Select from</option>
                                            <?php if(!empty($percentage)): ?>
                                            <?php $__currentLoopData = $percentage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($mf); ?>"><?php echo e($mf); ?>%</option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                                            <?php endif; ?>
                                        </select>
                                        <?php if($errors->has('percentage_from')): ?>
                                        <span class="invalid-feedback">
                                            <strong><?php echo e($errors->first('percentage_from')); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group col-sm-6">
                                        <label for="">Percentage to</label>
                                        <select class="form-control  <?php echo e($errors->has('percentage_to') ? ' is-invalid' : ''); ?>" name="percentage_to">
                                            <option value="">Select to</option>
                                            <?php if(!empty($percentage)): ?>
                                            <?php $__currentLoopData = $percentage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($mf); ?>"><?php echo e($mf); ?>%</option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                                            <?php endif; ?>
                                        </select>
                                        <?php if($errors->has('percentage_to')): ?>
                                        <span class="invalid-feedback">
                                            <strong><?php echo e($errors->first('percentage_to')); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group col-sm-12">
                                        <label for="">Grade</label>
                                        <select class="form-control  <?php echo e($errors->has('level') ? ' is-invalid' : ''); ?>" name="grade">
                                            <option value="">Select grade</option>
                                            <option value="A+">A+</option>
                                            <option value="A">A</option>
                                            <option value="B">B</option>
                                            <option value="C">C</option>
                                            <option value="D">D</option>
                                            <option value="F">F</option>
                                        </select>
                                        <?php if($errors->has('grade')): ?>
                                        <span class="invalid-feedback">
                                            <strong><?php echo e($errors->first('grade')); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group row gutters">
                            <div class="col-sm-3 mx-auto">
                                <button type="submit" class="btn btn-primary btn-lg btn-block">Submit</button>
                            </div>
                        </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!-- Row end -->
        <!-- Row end -->
                                   
        <div class="row">
            <div class="col-md-8 mx-auto col-sm-12 listofprogram">

            <table id="" class="table table-striped table-bordered" width="100%" cellspacing="0" cellpadding="0" border="0">
                <tbody><tr>
                    <th width="30%">Percentage From</th>
                    <th width="30%">Percentage To</th>
                    <th width="30%">Grade</th>
                </tr>
                <?php if(!empty($grade_master_details)): ?>
                <?php $__currentLoopData = $grade_master_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($value['percentage_from']); ?>%</td>
                    <td><?php echo e($value['percentage_to']); ?>%</td>
                    <td><?php echo e($value['grade']); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>  
              </tbody></table>

            </div>
        </div>
    </div>
</div>
<!-- Row ends -->   
    
    
</div>
<!-- END: .main-content -->
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>
<script src="<?php echo e(URL::asset('js/toastr.min.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(URL::asset('js/ui-toastr.min.js')); ?>" type="text/javascript"></script>
    <!-- If using flash()->important() or flash()->overlay(), you'll need to pull in the JS for Twitter Bootstrap. -->

    <?php if(session()->has('flash_notification')): ?>
        <script>
            jQuery( document ).ready(function() {
                <?php $__currentLoopData = session('flash_notification', collect())->toArray(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                toastr.<?php echo ($message['level'] == 'danger')?'error':$message['level']; ?>('<?php echo $message['message'];?>');
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            });


        </script>

    <?php endif; ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>