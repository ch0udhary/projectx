<?php $__env->startSection('stylesheet'); ?>
    <link href="<?php echo e(URL::asset('css/toastr.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(URL::asset('css/jquery.toast.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <!-- BEGIN .app-main -->
    <div class="app-main">
        <!-- BEGIN .main-heading -->
        <header class="main-heading">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-xl-8 col-lg-8 col-md-8 col-sm-8">
                        <div class="page-icon">
                            <i class="icon-layers"></i>
                        </div>
                        <div class="page-title">
                            <h5>Lead</h5>
                            <h6 class="sub-heading">Welcome to Amma</h6>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4">
                        <div class="right-actions">
                            <a href="#" class="btn btn-primary float-right" data-toggle="tooltip" data-placement="left" title="Download Reports">
                                <i class="icon-download4"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <!-- END: .main-heading -->
        <!-- BEGIN .main-content -->
        <div class="main-content">

            <!-- Row start -->
            <div class="row gutters">
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                    <div class="card">
                        <div class="card-header">Lead List</div>
                        <div class="card-body">
                            <div class="row gutters">
                                <div class="col form-group">
                                    <label for="">Master Franchisee</label>
                                    <select class="form-control">
                                        <option selected>Select</option>
                                        <option>0001</option>
                                        <option>0002</option>
                                        <option>0003</option>
                                        <option>0004</option>
                                        <option>0005</option>
                                    </select>
                                </div>
                                <div class="col form-group">
                                    <label for="">Centre</label>
                                    <select class="form-control">
                                        <option selected>Select Centre</option>
                                        <option>Rajauri Garden</option>
                                        <option>Tilak Nagar</option>
                                        <option>Malviya Nagar</option>
                                        <option>Lajpat Nagar</option>
                                        <option>Munirka</option>
                                    </select>
                                </div>
                                <div class="col form-group">
                                    <label for="">Program Interested</label>
                                    <select class="form-control">
                                        <option selected="">Select Program</option>
                                        <option>Mental Arithmetic &amp; Abacus</option>
                                        <option>Vedic Maths Program</option>
                                        <option>Art &amp; Craft</option>
                                        <option>Course Instructor Program</option>
                                    </select>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-6 form-group">
                                    <label for="">From Date</label>
                                    <input class="form-control" type="date" placeholder="">
                                </div>
                                <div class="col-sm-6 form-group">
                                    <label for="">To Date</label>
                                    <input class="form-control" type="date" placeholder="">
                                </div>
                            </div>
                            <table id="basicExample" class="table table-list table-striped table-bordered">
                                <thead>
                                <tr>
                                    <th width="18%">Name</th>
                                    <th width="18%">Program Interested</th>
                                    <th width="20%">Address</th>
                                    <th width="14%">Lead Status</th>
                                    <th width="15%">Enquiry Date</th>
                                    <th width="15%">Mobile</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php if($leads): ?>
                                    <?php $program_array = array('1'=>'Mental Arithmetic &amp; Abacus','2'=>'Vedic Maths Program','3'=>'Art &amp; Craft','4'=>'Course Instructor Program');

                                    // echo '<pre>'; print_r($program_array); echo '</pre>';

                                    ?>

                                    <?php $__currentLoopData = $leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($value['name']); ?></td>

                                    <td>
                                        <?php $__currentLoopData = $program_array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$parray): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($key ==$value['program_interested']): ?>
                                                 <?php echo $parray; ?>

                                            <?php endif; ?>
                                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </td>
                                    <td><?php echo e($value['address']); ?>, <?php echo e($value['city']); ?>,<?php echo e($value['state']); ?>,<?php echo e($value['pin']); ?></td>
                                    <td><?php echo e($value['lead_status']); ?></td>
                                    <td><?php echo e($value['enquiry_date']); ?></td>
                                    <td><?php echo e($value['mobile']); ?><span class="controls"><a href="<?php echo e(url('/admin/leads')); ?>/<?php echo e($value['id']); ?>/edit"><i class="fa fa-pencil" aria-hidden="true"></i></a>

                                            <a onclick="return delete_leads('<?php echo 'delete_leads_'.$value['id'] ; ?>')" class="btn  btn-sm mt-ladda-btn ladda-button"><span><i class="fa fa-trash-o" aria-hidden="true"></i></span></a></span>
                                        <form method="POST" action="<?php echo e(url('/admin/leads')); ?>/<?php echo e($value['id']); ?>" accept-charset="UTF-8" class="form-horizontal" style="display: inline-block; display:none;" id="delete_leads_<?php echo e($value['id']); ?>"> <?php echo method_field('DELETE'); ?> <?php echo csrf_field(); ?>
                                            <span><button type="submit" class="label label-danger" style="border:none !important;padding:8px; ">Delete</button></span>
                                        </form>






                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>


                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Row ends -->

        </div>
        <!-- END: .main-content -->
        <div class="modal fade" id="basic" tabindex="-1" role="basic" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">

                    <div class="modal-body">Are You Sure? </div>
                    <div class="modal-footer">
                        <input type="hidden" id="deleting_leads_id_value" value=""/>
                        <button type="button" class="btn dark btn-outline"  onclick="return hiding_box();">No</button>
                        <button type="button" class="btn green" onclick="return submiting_user();">Yes</button>
                    </div>
                </div>
                <!-- /.modal-content -->
            </div>
            <!-- /.modal-dialog -->
        </div>

        <div class="clearfix"></div>
    </div>
    <!-- END: .app-main -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>

    <script>
        function delete_leads(id)
        {
            $('#deleting_leads_id_value').val(id);
            $('#basic').modal('toggle');
        }

        function hiding_box()
        {
            $('#deleting_leads_id_value').val('');
            $('#basic').modal('hide');
        }

        function submiting_user()
        {
            var get_form_id = $('#deleting_leads_id_value').val();
            if(get_form_id != '')
            {
                $( "#"+get_form_id ).submit();
            }
        }
    </script>
    <script src="<?php echo e(URL::asset('js/toastr.min.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(URL::asset('js/ui-toastr.min.js')); ?>" type="text/javascript"></script>
    <!-- If using flash()->important() or flash()->overlay(), you'll need to pull in the JS for Twitter Bootstrap. -->

    <?php if(session()->has('flash_notification')): ?>
        <script>
            jQuery( document ).ready(function() {
                <?php $__currentLoopData = session('flash_notification', collect())->toArray(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                toastr.<?php echo ($message['level'] == 'danger')?'error':$message['level']; ?>('<?php echo $message['message'];?>');
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            });


        </script>

    <?php endif; ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>