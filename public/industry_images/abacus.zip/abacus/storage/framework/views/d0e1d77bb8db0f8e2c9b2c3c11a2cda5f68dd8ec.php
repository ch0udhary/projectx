<?php $__env->startSection('stylesheet'); ?>
    <link href="<?php echo e(URL::asset('vendor/datatables/dataTables.bs4.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(URL::asset('vendor/datatables/dataTables.bs4-custom.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="app-main">
    <!-- BEGIN .main-heading -->
    <header class="main-heading">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xl-8 col-lg-8 col-md-8 col-sm-8">
                    <div class="page-icon">
                        <i class="icon-layers"></i>
                    </div>
                    <div class="page-title">
                        <h5>Fees Master</h5>
                        <h6 class="sub-heading">Welcome to Amma</h6>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4">
                    <div class="right-actions">
                        <!-- <a href="#" class="btn btn-primary float-right" data-toggle="tooltip" data-placement="left" title="Download Reports">
                            <i class="icon-download4"></i>
                        </a> -->
                    </div>
                </div>
            </div>
        </div>
    </header>
<!-- BEGIN .main-content -->
<div class="main-content">
<?php if(\Session::has('success')): ?>
    <div class="alert alert-success">
        <ul>
            <li><?php echo \Session::get('success'); ?></li>
        </ul>
    </div>
<?php endif; ?>
<?php if(\Session::has('error')): ?>
    <div class="alert alert-danger">
        <ul>
            <li><?php echo \Session::get('error'); ?></li>
        </ul>
    </div>
<?php endif; ?>
<!-- Row start -->
    <div class="row gutters">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
            <div class="card">
                <div class="card-header">Students Fee List</div>
                <div class="card-body">
                    <form method="post" action="<?php echo e(route('payment-receipt.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="row gutters">
                        <div class="col-md-6 mx-auto col-sm-12">
                            <div class="form-group">
                                <label for="">Master Franchisee Code</label>
                                <select class="form-control    <?php echo e($errors->has('master_franchisee_code') ? ' is-invalid' : ''); ?>" name="master_franchisee_code" id="franchisee_code">
                                <option selected value="">Select</option>
                                <?php if(!empty($masterfranchisess)): ?>
                                <?php $__currentLoopData = $masterfranchisess; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($mf->id); ?>"><?php echo e($mf->master_franchisee_code); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                                <?php endif; ?>
                                </select>
                                <?php if($errors->has('masterFranchisesId')): ?>
                                <span class="invalid-feedback">
                                    <strong><?php echo e($errors->first('master_franchisee_code')); ?></strong>
                                </span>
                                <?php endif; ?>

                            </div>
                            <div class="form-group">
                                <label for="">Franchisee Code</label>
                                <select class="form-control <?php echo e($errors->has('franchisee_code') ? ' is-invalid' : ''); ?>" id="franchise" name="franchisee_code">
                                    <option selected value="">Select</option>
                                    
                                </select>
                                <?php if($errors->has('franchisee_code')): ?>
                                <span class="invalid-feedback">
                                    <strong><?php echo e($errors->first('franchisee_code')); ?></strong>
                                </span>
                                <?php endif; ?>
                               
                            </div>
                            <div class="form-group">
                                <label for="">Amount</label>
                                <input type="text" class="form-control <?php echo e($errors->has('amount') ? ' is-invalid' : ''); ?>" placeholder="Amount" name="amount">
                                <?php if($errors->has('amount')): ?>
                                <span class="invalid-feedback">
                                    <strong><?php echo e($errors->first('amount')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label for="">Payment Mode</label>
                                <select class="form-control" name="payment_mode">
                                    <option>Select Payment type</option>
                                    <option>Cash</option>
                                    <option>Bank Transfer</option>
                                    <option>Cheque/Demand Draft</option>
                                    <option>Credit Card/Debit Card</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="">Payment Date</label>
                                <input type="date" class="form-control" placeholder="" name="payment_date">
                            </div>
                            
                            <div class="form-group">
                                <label for="">Cheque/DD/NEFT No.</label>
                                <input type="text" class="form-control" placeholder="" name="payment_mode_no">
                            </div>
                            <div class="form-group">
                                <label for="">Bank</label>
                                <input type="text" class="form-control" placeholder="" name="bank">
                            </div>
                        </div>
                    </div>
                    <div class="form-group row gutters">
                        <div class="col-sm-3 mx-auto">
                            <button type="submit" class="btn btn-primary btn-lg btn-block">Submit</button>
                        </div>
                    </div>

                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- Row ends -->    
    
</div>
<!-- END: .main-content -->
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>

<script>
 $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    $('#franchisee_code').change(function(e) {
        e.preventDefault(); // does not go through with the link.
        var tt = $(this,'option:selected').val();
        $.post({
            type:'POST',
            data: {'masterId':$(this).val()},
            url: "<?php echo e(route('getFranchisee')); ?>"
        }).done(function (data) {
            $('#franchise').html(data);            
           
        });
    });  
    
</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>