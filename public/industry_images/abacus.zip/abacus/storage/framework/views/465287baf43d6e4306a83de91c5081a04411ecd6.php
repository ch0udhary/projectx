<?php $__env->startSection('stylesheet'); ?>
    <link href="<?php echo e(URL::asset('vendor/datatables/dataTables.bs4.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(URL::asset('vendor/datatables/dataTables.bs4-custom.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="app-main">
    <!-- BEGIN .main-heading -->
    <header class="main-heading">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xl-8 col-lg-8 col-md-8 col-sm-8">
                    <div class="page-icon">
                        <i class="icon-layers"></i>
                    </div>
                    <div class="page-title">
                        <h5>Training Fee</h5>
                        <h6 class="sub-heading">Welcome to Amma</h6>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4">
                    <div class="right-actions">
                        <!-- <a href="#" class="btn btn-primary float-right" data-toggle="tooltip" data-placement="left" title="Download Reports">
                            <i class="icon-download4"></i>
                        </a> -->
                    </div>
                </div>
            </div>
        </div>
    </header>
<!-- BEGIN .main-content -->
<div class="main-content">
<?php if(\Session::has('success')): ?>
    <div class="alert alert-success">
        <ul>
            <li><?php echo \Session::get('success'); ?></li>
        </ul>
    </div>
<?php endif; ?>
<?php if(\Session::has('error')): ?>
    <div class="alert alert-danger">
        <ul>
            <li><?php echo \Session::get('error'); ?></li>
        </ul>
    </div>
<?php endif; ?>
    <div class="row gutters">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
            <!-- Row start -->
            <div class="row gutters">
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                    <div class="card">
                        <div class="card-body">  
                            <div class="row gutters">
                              
                                    <div class="form-group col-sm-6">
                                        <label for="">Master Franchisee</label>
                                        <select class="form-control    <?php echo e($errors->has('level') ? ' is-invalid' : ''); ?>" name="masterFranchisesId" id="franchisee_code">
                                        <option selected value="">Select</option>
                                        <?php if(!empty($masterfranchisess)): ?>
                                        <?php $__currentLoopData = $masterfranchisess; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($mf->id); ?>"><?php echo e($mf->master_franchisee_code); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                                        <?php endif; ?>
                                        </select>
                                        <?php if($errors->has('masterFranchisesId')): ?>
                                        <span class="invalid-feedback">
                                            <strong><?php echo e($errors->first('masterFranchisesId')); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group col-sm-6 <?php echo e($errors->has('centreCode') ? ' is-invalid' : ''); ?>">
                                        <label for="">Centre</label>
                                        <select class="form-control " id="centreCode" name="centreCode">
                                            <option selected>Select Centre</option>
                                            
                                        </select>
                                        <?php if($errors->has('centreCode')): ?>
                                        <span class="invalid-feedback">
                                            <strong><?php echo e($errors->first('centreCode')); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="col-sm-6 form-group">
                                        <label for="">From Date</label>
                                        <input class="form-control" type="date" placeholder="" name="startDate">
                                    </div>
                                    <div class="col-sm-6 form-group">
                                        <label for="">To Date</label>
                                        <input class="form-control" type="date" placeholder="" name="endDate">                                                
                                    </div>
                                   
                                </div>
                            <table id="basicExample" class="table table-list table-striped table-bordered">
                                <thead>
                                    <tr>
                                        <th width="20%">Faculty Name</th>
                                        <th width="15%">Faculty Code</th>
                                        <th width="20%">System Receipt No.</th>
                                        <th width="15%">Receipt Date</th>
                                        <th width="15%">Centre Code</th>
                                        <th width="15%">Fee Amount</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php if(!empty($listing)): ?>
                                    <?php $__currentLoopData = $listing; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($list->faculty_detail->facultyName); ?></td>
                                        <td><?php echo e($list->faculty_detail->facultyCode); ?></td>
                                        <td><?php echo e($list->receiptNo); ?></td>
                                        <td><?php echo e($list->receiptDate); ?></td>
                                        <td><?php echo e($list->center_detail->centre_name); ?></td>
                                        <td><?php echo e($list->total); ?>

                                        <!-- <span class="controls"><a href="#"><i class="fa fa-pencil" aria-hidden="true"></i></a><a href="#"><i class="fa fa-trash-o" aria-hidden="true"></i></a></span> -->
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                                    
                                </tbody>
                            </table>

                        </div>
                    </div>
                         
                </div>
            </div>
            <!-- Row end -->
        </div>
    </div>
    
    
</div>
<!-- END: .main-content -->
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
<script src="<?php echo e(URL::asset('vendor/datatables/dataTables.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(URL::asset('vendor/datatables/dataTables.bootstrap.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(URL::asset('vendor/datatables/custom/custom-datatables.js')); ?>" type="text/javascript"></script>
<script>
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    $('#franchisee_code').change(function(e) {
        e.preventDefault(); // does not go through with the link.
        var tt = $(this,'option:selected').val();
        $.post({
            type:'POST',
            data: {'masterId':$(this).val()},
            url: "<?php echo e(route('getcenter')); ?>"
        }).done(function (data) {
            $('#centreCode').html(data);            
           
        });
    });
    $('#centreCode').change(function(e) {
        e.preventDefault(); // does not go through with the link.
        var tt = $(this,'option:selected').val();
        $.post({
            type:'POST',
            data: {'centreCode':$(this).val()},
            url: "<?php echo e(route('facultylist')); ?>"
        }).done(function (data) {
            $('#facultyId').html(data);            
           
        });
    });
    $('#programId').change(function(e) {
        e.preventDefault(); // does not go through with the link.
        var tt = $(this,'option:selected').val();
        $.post({
            type:'POST',
            data: {'programId':$(this).val()},
            url: "<?php echo e(route('getlevel')); ?>"
        }).done(function (data) {
            $('#levellist').html(data);            
           
        });
    });
    $('.beforedelete').on('click',function(e){
       
        if(confirm("Are you sure, you want to delete this item ?")){
            $('#deletecalender').submit();
        }else{
             e.preventDefault();
        }
    })
</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>