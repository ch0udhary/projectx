<?php $__env->startSection('content'); ?>

    

    <!-- BEGIN .app-main -->
    <div class="app-main">
        <!-- BEGIN .main-heading -->
        <header class="main-heading">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-xl-8 col-lg-8 col-md-8 col-sm-8">
                        <div class="page-icon">
                            <i class="icon-layers"></i>
                        </div>
                        <div class="page-title">
                            <h5>Add Master Franchisee</h5>
                            <h6 class="sub-heading">Welcome to Amma</h6>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4">
                        <div class="right-actions">
                            <a href="#" class="btn btn-primary float-right" data-toggle="tooltip" data-placement="left" title="Download Reports">
                                <i class="icon-download4"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <!-- END: .main-heading -->
        <!-- BEGIN .main-content -->
        <div class="main-content">
            <div class="row gutters">
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                    <!-- Row start -->
                    <div class="row gutters">
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                            <?php if(isset($MasterFranchises_info)): ?>
                                <form method="POST" action='<?php echo e(url("/admin/master-franchises/".$MasterFranchises_info['id'])); ?>'>
                                    <?php echo method_field('PUT'); ?>
                            <?php else: ?>
                                <form method="POST" action="<?php echo e(url('/admin/master-franchises/')); ?>">
                            <?php endif; ?>
                                 <?php echo csrf_field(); ?>
                            <div class="card">
                                <div class="card-body">
                                    <div class="row gutters">
                                        <div class="col-md-8 mx-auto col-sm-12">
                                            <div class="row">
                                                <div class="form-group col-sm-6">
                                                    <label for="">Master Franchisee Code</label>
                                                    <input name="master_franchisee_code" value="<?php if(isset($MasterFranchises_info['master_franchisee_code'])): ?><?php echo e($MasterFranchises_info['master_franchisee_code']); ?><?php else: ?><?php echo e(old('master_franchisee_code')); ?><?php endif; ?>" type="text" class="form-control <?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" id="master_franchisee_code" placeholder="DL/0058 (state short code, running number)">
                                                    <?php if($errors->has('master_franchisee_code')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('master_franchisee_code')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="form-group col-sm-6">
                                                    <label for="">Date of Agreement</label>
                                                    <input  value="<?php if(isset($MasterFranchises_info['date_of_agreement'])): ?><?php echo e($MasterFranchises_info['date_of_agreement']); ?><?php else: ?><?php echo e(old('date_of_agreement')); ?><?php endif; ?>" name="date_of_agreement" type="date" class="form-control <?php echo e($errors->has('date_of_agreement') ? ' is-invalid' : ''); ?>" id="date_of_agreement" >
                                                    <?php if($errors->has('date_of_agreement')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('date_of_agreement')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="form-group col-sm-6">
                                                    <label for="">Name of Organisation/Name</label>
                                                    <input type="text" value="<?php if(isset($MasterFranchises_info['name'])): ?><?php echo e($MasterFranchises_info['name']); ?><?php else: ?><?php echo e(old('name')); ?><?php endif; ?>" name="name" class="form-control <?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" id="name" placeholder="Krishna Coaching Centre" >
                                                    <?php if($errors->has('name')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('name')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="form-group col-sm-6">
                                                    <label for="">Date of Establishment/Date of Birth</label>
                                                    <input value="<?php if(isset($MasterFranchises_info['date_of_establishment'])): ?><?php echo e($MasterFranchises_info['date_of_establishment']); ?><?php else: ?><?php echo e(old('date_of_establishment')); ?><?php endif; ?>" name="date_of_establishment" type="date" class="form-control <?php echo e($errors->has('date_of_establishment') ? ' is-invalid' : ''); ?>" id="date_of_establishment" >
                                                    <?php if($errors->has('date_of_establishment')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('date_of_establishment')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label for="">Address</label>
                                                <input value="<?php if(isset($MasterFranchises_info['address'])): ?><?php echo e($MasterFranchises_info['address']); ?><?php else: ?><?php echo e(old('address')); ?><?php endif; ?>" name="address" class="form-control <?php echo e($errors->has('address') ? ' is-invalid' : ''); ?>" type="text"placeholder="101, Janak puri West">
                                                <?php if($errors->has('address')): ?>
                                                    <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('address')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                            <div class="row">
                                                <div class="form-group col-sm-4">
                                                    <label for="">City</label>
                                                    <input value="<?php if(isset($MasterFranchises_info['city'])): ?><?php echo e($MasterFranchises_info['city']); ?><?php else: ?><?php echo e(old('city')); ?><?php endif; ?>" name="city" class="form-control <?php echo e($errors->has('city') ? ' is-invalid' : ''); ?>" type="text"placeholder="New Delhi">
                                                    <?php if($errors->has('city')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('city')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="form-group col-sm-4">
                                                    <label for="">State</label>
                                                    <input value="<?php if(isset($MasterFranchises_info['state'])): ?><?php echo e($MasterFranchises_info['state']); ?><?php else: ?><?php echo e(old('state')); ?><?php endif; ?>" name="state" class="form-control <?php echo e($errors->has('state') ? ' is-invalid' : ''); ?>" placeholder="Delhi" type="text">
                                                    <?php if($errors->has('state')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('state')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="form-group col-sm-4">
                                                    <label for="">PIN</label>
                                                    <input value="<?php if(isset($MasterFranchises_info['pin'])): ?><?php echo e($MasterFranchises_info['pin']); ?><?php else: ?><?php echo e(old('pin')); ?><?php endif; ?>" name="pin" class="form-control <?php echo e($errors->has('pin') ? ' is-invalid' : ''); ?>" placeholder="110014" type="text">
                                                    <?php if($errors->has('pin')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('pin')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="form-group col-sm-4">
                                                    <label for="">Office/Home Phone No.</label>
                                                    <input value="<?php if(isset($MasterFranchises_info['phone_no'])): ?><?php echo e($MasterFranchises_info['phone_no']); ?><?php else: ?><?php echo e(old('phone_no')); ?><?php endif; ?>" name="phone_no" type="text" class="form-control <?php echo e($errors->has('phone_no') ? ' is-invalid' : ''); ?>" id="phone_no" placeholder="011 25752763" >
                                                    <?php if($errors->has('phone_no')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('phone_no')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="form-group col-sm-4">
                                                    <label for="">Mobile No.</label>
                                                    <input value="<?php if(isset($MasterFranchises_info['mobile_no'])): ?><?php echo e($MasterFranchises_info['mobile_no']); ?><?php else: ?><?php echo e(old('mobile_no')); ?><?php endif; ?>" name="mobile_no" type="text" class="form-control <?php echo e($errors->has('mobile_no') ? ' is-invalid' : ''); ?>" id="mobile_no" placeholder="9212252763" >
                                                    <?php if($errors->has('mobile_no')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('mobile_no')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="form-group col-sm-4">
                                                    <label for="">Email ID</label>
                                                    <input value="<?php if(isset($MasterFranchises_info['email'])): ?><?php echo e($MasterFranchises_info['email']); ?><?php else: ?><?php echo e(old('email')); ?><?php endif; ?>" name="email" type="email" class="form-control <?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" id="email" placeholder="info@ammaindia.com">
                                                    <?php if($errors->has('email')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('email')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label for="">Education, if individual</label>
                                                <input name="education"  value="<?php if(isset($MasterFranchises_info['education'])): ?><?php echo e($MasterFranchises_info['education']); ?><?php else: ?><?php echo e(old('education')); ?><?php endif; ?>" type="text" class="form-control <?php echo e($errors->has('education') ? ' is-invalid' : ''); ?>" id="education" placeholder="B.A., B.Ed." >
                                                <?php if($errors->has('education')): ?>
                                                    <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('education')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                            <div class="row">
                                                <div class="form-group col-sm-6">
                                                    <label for="">Years Experience in Teaching</label>
                                                    <input value="<?php if(isset($MasterFranchises_info['years_experience_in_teaching'])): ?><?php echo e($MasterFranchises_info['years_experience_in_teaching']); ?><?php else: ?><?php echo e(old('years_experience_in_teaching')); ?><?php endif; ?>" name="years_experience_in_teaching" type="text" class="form-control <?php echo e($errors->has('years_experience_in_teaching') ? ' is-invalid' : ''); ?>" id="years_experience_in_teaching" placeholder="5 years" >
                                                    <?php if($errors->has('years_experience_in_teaching')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('years_experience_in_teaching')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="form-group col-sm-6">
                                                    <label for="">Years Experience in Business</label>
                                                    <input  value="<?php if(isset($MasterFranchises_info['years_experience_in_business'])): ?><?php echo e($MasterFranchises_info['years_experience_in_business']); ?><?php else: ?><?php echo e(old('years_experience_in_business')); ?><?php endif; ?>" name="years_experience_in_business" type="text" class="form-control <?php echo e($errors->has('years_experience_in_business') ? ' is-invalid' : ''); ?>" id="years_experience_in_business" placeholder="15 years (n/a for individual)" >
                                                    <?php if($errors->has('years_experience_in_business')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('years_experience_in_business')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="form-group col-sm-4">
                                                    <label for="">Centre Code</label>
                                                    <input  value="<?php if(isset($MasterFranchises_info['centre_code'])): ?><?php echo e($MasterFranchises_info['centre_code']); ?><?php else: ?><?php echo e(old('centre_code')); ?><?php endif; ?>" name="centre_code" type="text" class="form-control  <?php echo e($errors->has('centre_code') ? ' is-invalid' : ''); ?>" id="centre_code" placeholder="DL/EPN/EPN/001" >
                                                    <?php if($errors->has('centre_code')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('centre_code')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="form-group col-sm-4">
                                                    <label for="">Licensed Territory</label>
                                                    <input  value="<?php if(isset($MasterFranchises_info['licensed_territory'])): ?><?php echo e($MasterFranchises_info['licensed_territory']); ?><?php else: ?><?php echo e(old('licensed_territory')); ?><?php endif; ?>" type="text" name="licensed_territory" class="form-control  <?php echo e($errors->has('licensed_territory') ? ' is-invalid' : ''); ?>" id="" placeholder="Patel Nagar" >
                                                    <?php if($errors->has('licensed_territory')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('licensed_territory')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="form-group col-sm-4">
                                                    <label for="">PIN Code</label>
                                                    <input  value="<?php if(isset($MasterFranchises_info['pin_code'])): ?><?php echo e($MasterFranchises_info['pin_code']); ?><?php else: ?><?php echo e(old('pin_code')); ?><?php endif; ?>" type="text" name="pin_code" class="form-control  <?php echo e($errors->has('pin_code') ? ' is-invalid' : ''); ?>" id="" placeholder="110008" >
                                                    <?php if($errors->has('pin_code')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('pin_code')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="form-group col-sm-4">
                                                    <label for="">License Certificate No.</label>
                                                    <input value="<?php if(isset($MasterFranchises_info['license_certificate_no'])): ?><?php echo e($MasterFranchises_info['license_certificate_no']); ?><?php else: ?><?php echo e(old('license_certificate_no')); ?><?php endif; ?>" name="license_certificate_no" type="text" class="form-control  <?php echo e($errors->has('license_certificate_no') ? ' is-invalid' : ''); ?>" id="license_certificate_no" placeholder="115" >
                                                    <?php if($errors->has('license_certificate_no')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('license_certificate_no')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="form-group col-sm-4">
                                                    <label for="">License Period from</label>
                                                    <input  value="<?php if(isset($MasterFranchises_info['license_period_from'])): ?><?php echo e($MasterFranchises_info['license_period_from']); ?><?php else: ?><?php echo e(old('license_period_from')); ?><?php endif; ?>" name="license_period_from" type="date" class="form-control  <?php echo e($errors->has('license_period_from') ? ' is-invalid' : ''); ?>" id="	license_period_from" placeholder="" >
                                                    <?php if($errors->has('license_period_from')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('license_period_from')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="form-group col-sm-4">
                                                    <label for="">License Period to</label>
                                                    <input  value="<?php if(isset($MasterFranchises_info['license_period_to'])): ?><?php echo e($MasterFranchises_info['license_period_to']); ?><?php else: ?><?php echo e(old('license_period_to')); ?><?php endif; ?>" name="license_period_to" type="date" class="form-control  <?php echo e($errors->has('license_period_to') ? ' is-invalid' : ''); ?>" id="license_period_to" placeholder="" >
                                                    <?php if($errors->has('license_period_to')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('license_period_to')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="form-group col-sm-4">
                                                    <label for="">Franchisee License Fee</label>
                                                    <input  value="<?php if(isset($MasterFranchises_info['franchisee_license_fee'])): ?><?php echo e($MasterFranchises_info['franchisee_license_fee']); ?><?php else: ?><?php echo e(old('franchisee_license_fee')); ?><?php endif; ?>" name="franchisee_license_fee" type="text" class="form-control  <?php echo e($errors->has('franchisee_license_fee') ? ' is-invalid' : ''); ?>" id="franchisee_license_fee" placeholder="Rs.30,000/-" >
                                                    <?php if($errors->has('franchisee_license_fee')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('franchisee_license_fee')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="form-group col-sm-4">
                                                    <label for="">License Fee Receipt No</label>
                                                    <input  value="<?php if(isset($MasterFranchises_info['license_fee_receipt_no'])): ?><?php echo e($MasterFranchises_info['license_fee_receipt_no']); ?><?php else: ?><?php echo e(old('license_fee_receipt_no')); ?><?php endif; ?>" name="license_fee_receipt_no" type="text" class="form-control  <?php echo e($errors->has('license_fee_receipt_no') ? ' is-invalid' : ''); ?>" id="license_fee_receipt_no" placeholder="0533" >
                                                    <?php if($errors->has('license_fee_receipt_no')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('license_fee_receipt_no')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="form-group col-sm-4">
                                                    <label for="">Receipt Date</label>
                                                    <input  value="<?php if(isset($MasterFranchises_info['receipt_date'])): ?><?php echo e($MasterFranchises_info['receipt_date']); ?><?php else: ?><?php echo e(old('receipt_date')); ?><?php endif; ?>" name="receipt_date" type="date" class="form-control  <?php echo e($errors->has('receipt_date') ? ' is-invalid' : ''); ?>" id="receipt_date" placeholder="" >
                                                    <?php if($errors->has('receipt_date')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('receipt_date')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="form-group col-sm-4">
                                                    <label for="">Renewal Fee</label>
                                                    <input  value="<?php if(isset($MasterFranchises_info['renewal_fee'])): ?><?php echo e($MasterFranchises_info['renewal_fee']); ?><?php else: ?><?php echo e(old('renewal_fee')); ?><?php endif; ?>" name="renewal_fee" type="text" class="form-control  <?php echo e($errors->has('renewal_fee') ? ' is-invalid' : ''); ?>" id="renewal_fee" placeholder="Rs.10,000/-">
                                                    <?php if($errors->has('renewal_fee')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('renewal_fee')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="form-group col-sm-4">
                                                    <label for="">Renewed Period from</label>
                                                    <input  value="<?php if(isset($MasterFranchises_info['renewed_period_from'])): ?><?php echo e($MasterFranchises_info['renewed_period_from']); ?><?php else: ?><?php echo e(old('renewed_period_from')); ?><?php endif; ?>" name="renewed_period_from" type="date" class="form-control  <?php echo e($errors->has('renewed_period_from') ? ' is-invalid' : ''); ?>" id="renewed_period_from" placeholder="">
                                                    <?php if($errors->has('renewed_period_from')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('renewed_period_from')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="form-group col-sm-4">
                                                    <label for="">Renewed Period to</label>
                                                    <input  value="<?php if(isset($MasterFranchises_info['renewed_period_to'])): ?><?php echo e($MasterFranchises_info['renewed_period_to']); ?><?php else: ?><?php echo e(old('renewed_period_to')); ?><?php endif; ?>" name="renewed_period_to" type="date" class="form-control  <?php echo e($errors->has('renewed_period_to') ? ' is-invalid' : ''); ?>" id="renewed_period_to" placeholder="">
                                                    <?php if($errors->has('renewed_period_to')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('renewed_period_to')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="form-group col-sm-6">
                                                    <label for="">Royalty</label>
                                                    <input  value="<?php if(isset($MasterFranchises_info['royalty'])): ?><?php echo e($MasterFranchises_info['royalty']); ?><?php else: ?><?php echo e(old('royalty')); ?><?php endif; ?>" name="royalty" type="text" class="form-control  <?php echo e($errors->has('royalty') ? ' is-invalid' : ''); ?>" id="royalty" placeholder="25% of course fees" >
                                                    <?php if($errors->has('royalty')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('royalty')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="form-group col-sm-6">
                                                    <label for="">Material Discount</label>
                                                    <input  value="<?php if(isset($MasterFranchises_info['material_discount'])): ?><?php echo e($MasterFranchises_info['material_discount']); ?><?php else: ?><?php echo e(old('material_discount')); ?><?php endif; ?>" name="material_discount" type="text" class="form-control  <?php echo e($errors->has('material_discount') ? ' is-invalid' : ''); ?>" id="material_discount" placeholder="" >
                                                    <?php if($errors->has('material_discount')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('material_discount')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group row gutters">
                                        <div class="col-sm-3 mx-auto">
                                            <button type="submit" class="btn btn-primary btn-lg btn-block">Submit</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            </form>
                        </div>
                    </div>
                    <!-- Row end -->
                </div>

            </div>


        </div>
        <!-- END: .main-content -->
    </div>
    <!-- END: .app-main -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>