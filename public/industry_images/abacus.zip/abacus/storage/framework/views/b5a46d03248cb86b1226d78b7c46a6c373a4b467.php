<?php $__env->startSection('stylesheet'); ?>
    <link href="<?php echo e(URL::asset('css/toastr.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(URL::asset('css/jquery.toast.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>



    

    <!-- BEGIN .app-main -->

    <div class="app-main">
        <!-- BEGIN .main-heading -->
        <header class="main-heading">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-xl-8 col-lg-8 col-md-8 col-sm-8">
                        <div class="page-icon">
                            <i class="icon-layers"></i>
                        </div>
                        <div class="page-title">
                            <h5>Add Master Franchisee</h5>
                            <h6 class="sub-heading">Welcome to Amma</h6>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4">
                        <div class="right-actions">
                            <a href="#" class="btn btn-primary float-right" data-toggle="tooltip" data-placement="left" title="Download Reports">
                                <i class="icon-download4"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <!-- END: .main-heading -->
        <!-- BEGIN .main-content -->
        <div class="main-content">
            <div class="row gutters">
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                    <!-- Row start -->
                    <div class="row gutters">
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                             <form method="POST" action="<?php echo e(url('/admin/franchisee-mapping/')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="card">
                                    <div class="card-body">
                                        <div class="row gutters">
                                            <div class="col-md-6 mx-auto col-sm-12">
                                                <div class="form-group">
                                                    <label for="">Franchisee Code</label>
                                                    <select name="franchisee_code" id="franchisee_code" class="form-control <?php echo e($errors->has('franchisee_code') ? ' is-invalid' : ''); ?>">
                                                        <option value="">Select Franchise Code</option>
                                                        <?php if($franchises_info): ?>
                                                            <?php $__currentLoopData = $franchises_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mvalue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($mvalue['id']); ?>" <?php echo e((old('franchisee_code')==$mvalue['id'])? 'selected':''); ?>><?php echo e($mvalue['franchisee_code']); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php endif; ?>
                                                    </select>
                                                    <?php if($errors->has('franchisee_code')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('franchisee_code')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="row form-group">
                                                    <div class="col">
                                                        <label for="">Existing Master Franchisee :</label>
                                                    </div>
                                                    <div class="col">
                                                        <span id="master-franchise"></span>
                                                    </div>
                                                </div>
                                                <div class="row form-group">
                                                    <div class="col">
                                                        <label for="">Licensed Territory :</label>
                                                    </div>
                                                    <div class="col">
                                                        <span id="master-licensed"></span>
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label for="">Change Master Franchise Code</label>
                                                    <select name="master_franchisee_code" class="form-control <?php echo e($errors->has('master_franchisee_code') ? ' is-invalid' : ''); ?>">
                                                        <option value="" >Select Master Franchisee</option>
                                                        <?php if($masterfranchisess): ?>
                                                            <?php $__currentLoopData = $masterfranchisess; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mvalue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($mvalue['id']); ?>" <?php echo e((old('master_franchisee_code')==$mvalue['id'])? 'selected':''); ?>><?php echo e($mvalue['master_franchisee_code']); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php endif; ?>
                                                    </select>
                                                    <?php if($errors->has('master_franchisee_code')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('master_franchisee_code')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                         </div>
                                        <div class="form-group row gutters">
                                            <div class="col-sm-3 mx-auto">
                                                <button type="submit" class="btn btn-primary btn-lg btn-block">Submit</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <!-- Row end -->
                </div>

            </div>


        </div>
        <!-- END: .main-content -->
    </div>
    <!-- END: .app-main -->
<?php $__env->stopSection(); ?>



<?php $__env->startSection('javascript'); ?>

<script>
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    $('#franchisee_code').change(function(e) {
        e.preventDefault(); // does not go through with the link.
        var tt = $(this).val();
        $.post({
            type:'POST',
            data:$(this).val(),
            url: '/admin/franchisee-mapping/ajaxRequest'
        }).done(function (data) {
            $('#master-franchise').text(data['1']);
            $('#master-licensed').text(data['0']);
            // console.log(data);
            //location.reload();
        });
    });
</script>

<script src="<?php echo e(URL::asset('js/toastr.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(URL::asset('js/ui-toastr.min.js')); ?>" type="text/javascript"></script>
<!-- If using flash()->important() or flash()->overlay(), you'll need to pull in the JS for Twitter Bootstrap. -->

<?php if(session()->has('flash_notification')): ?>
    <script>
        jQuery( document ).ready(function() {
            <?php $__currentLoopData = session('flash_notification', collect())->toArray(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            toastr.<?php echo ($message['level'] == 'danger')?'error':$message['level']; ?>('<?php echo $message['message'];?>');
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        });


    </script>

<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>