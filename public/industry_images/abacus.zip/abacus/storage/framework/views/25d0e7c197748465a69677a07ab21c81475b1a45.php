<?php $__env->startSection('content'); ?>
<div class="app-main">
    <!-- BEGIN .main-heading -->
    <header class="main-heading">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xl-8 col-lg-8 col-md-8 col-sm-8">
                    <div class="page-icon">
                        <i class="icon-layers"></i>
                    </div>
                    <div class="page-title">
                        <h5>Training Calender</h5>
                        <h6 class="sub-heading">Welcome to Amma</h6>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4">
                    <div class="right-actions">
                        <!-- <a href="#" class="btn btn-primary float-right" data-toggle="tooltip" data-placement="left" title="Download Reports">
                            <i class="icon-download4"></i>
                        </a> -->
                    </div>
                </div>
            </div>
        </div>
    </header>
<!-- BEGIN .main-content -->
<div class="main-content">
<?php if(\Session::has('success')): ?>
    <div class="alert alert-success">
        <ul>
            <li><?php echo \Session::get('success'); ?></li>
        </ul>
    </div>
<?php endif; ?>
<?php if(\Session::has('error')): ?>
    <div class="alert alert-danger">
        <ul>
            <li><?php echo \Session::get('error'); ?></li>
        </ul>
    </div>
<?php endif; ?>
    <div class="row gutters">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
            <!-- Row start -->
            <div class="row gutters">
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                    <div class="card">
                        <div class="card-body">
                            

                            <div class="row gutters">
                                <div class="col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label for="">Master Franchisee</label>
                                        <select class="form-control <?php echo e($errors->has('masterFranchisesId') ? ' is-invalid' : ''); ?>" name="masterFranchisesId" id="franchisee_code">
                                        <option selected value="">Select</option>
                                        <?php if(!empty($masterfranchisess)): ?>
                                        <?php $__currentLoopData = $masterfranchisess; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($mf->id); ?>"><?php echo e($mf->master_franchisee_code); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                                        <?php endif; ?>
                                        </select>
                                        <?php if($errors->has('masterFranchisesId')): ?>
                                        <span class="invalid-feedback">
                                            <strong><?php echo e($errors->first('masterFranchisesId')); ?></strong>
                                        </span> 
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label for="">Centre</label>
                                        <select class="form-control <?php echo e($errors->has('centreCode') ? ' is-invalid' : ''); ?>" id="centreCode" name="centreCode">
                                            <option selected>Select Centre</option>
                                            
                                        </select>
                                        <?php if($errors->has('centreCode')): ?>
                                        <span class="invalid-feedback">
                                            <strong><?php echo e($errors->first('centreCode')); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label for="">Faculty</label>
                                        <select class="form-control <?php echo e($errors->has('masterFranchisesId') ? ' is-invalid' : ''); ?>" id="facultyId" name="facultyId">
                                            <option selected>Select Faculty</option>                 
                                        </select>
                                        <?php if($errors->has('facultyId')): ?>
                                        <span class="invalid-feedback">
                                            <strong><?php echo e($errors->first('facultyId')); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-md-12 col-sm-12">
                                    <table id="" width="100%" border="0" cellspacing="0" cellpadding="0" class="table table-striped table-bordered">
                                        <tr>
                                          <th width="25%">Date</th>
                                          <th width="25%">Program</th>
                                          <th width="25%">Level</th>
                                          <th width="25%">Completion Date</th>
                                        </tr>
                                        <?php if(!empty($listing)): ?>
                                        <?php $__currentLoopData = $listing; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                          <td><?php echo e($list->trainingDate); ?></td>
                                          <td><?php echo e($list->program->name); ?></td>
                                          <td><?php echo e($list->level_rel->name); ?></td>
                                          
                                          <td>
                                              <a href="<?php echo e(route('training-completion.create')); ?>" class="delete btn btn-primary btn-sm">Training Complete</a>
                                          </td>
                                          </form>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </table>
                                </div>
                            </div>
                            </form>
                        </div>
                    </div>
                         
                </div>
            </div>
            <!-- Row end -->
        </div>
    </div>
    
    
</div>
<!-- END: .main-content -->
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>

<script>
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    $('#franchisee_code').change(function(e) {
        e.preventDefault(); // does not go through with the link.
        var tt = $(this,'option:selected').val();
        $.post({
            type:'POST',
            data: {'masterId':$(this).val()},
            url: "<?php echo e(route('getcenter')); ?>"
        }).done(function (data) {
            $('#centreCode').html(data);            
           
        });
    });
    $('#centreCode').change(function(e) {
        e.preventDefault(); // does not go through with the link.
        var tt = $(this,'option:selected').val();
        $.post({
            type:'POST',
            data: {'centreCode':$(this).val()},
            url: "<?php echo e(route('facultylist')); ?>"
        }).done(function (data) {
            $('#facultyId').html(data);            
           
        });
    });
    $('#programId').change(function(e) {
        e.preventDefault(); // does not go through with the link.
        var tt = $(this,'option:selected').val();
        $.post({
            type:'POST',
            data: {'programId':$(this).val()},
            url: "<?php echo e(route('getlevel')); ?>"
        }).done(function (data) {
            $('#levellist').html(data);            
           
        });
    });
    $('.beforedelete').on('click',function(e){
       
        if(confirm("Are you sure, you want to delete this item ?")){
            $('#deletecalender').submit();
        }else{
             e.preventDefault();
        }
    })
</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>