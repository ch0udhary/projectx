<?php $__env->startSection('stylesheet'); ?>
    <link href="<?php echo e(URL::asset('css/toastr.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(URL::asset('css/jquery.toast.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <!-- BEGIN .app-main -->
    <div class="app-main">
        <!-- BEGIN .main-heading -->
        <header class="main-heading">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-xl-8 col-lg-8 col-md-8 col-sm-8">
                        <div class="page-icon">
                            <i class="icon-layers"></i>
                        </div>
                        <div class="page-title">
                            <h5>Master Program</h5>
                            <h6 class="sub-heading">Welcome to Amma</h6>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4">
                        <div class="right-actions">
                            <a href="#" class="btn btn-primary float-right" data-toggle="tooltip" data-placement="left" title="Download Reports">
                                <i class="icon-download4"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <!-- END: .main-heading -->
        <!-- BEGIN .main-content -->
        <div class="main-content">

            <div class="row gutters">
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                    <!-- Row start -->
                    <div class="card">
                        

                        <?php //echo '<pre>'; print_r($errors->all()); echo '</pre>'; ?>

                        
                        <div class="card-body">
                            <form method="post" action="<?php echo e(route('program-level.store')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="row gutters">
                                    <div class="col-md-8 mx-auto col-sm-12">

                                        <div class="form-group">
                                            <div class="row gutters">
                                                <div class="col-sm-12">
                                                    <div class="row">
                                                        <div class="form-group col-sm-12">
                                                <select name="master_program" id="master_program" class="form-control <?php echo e($errors->has('master_program') ? ' is-invalid' : ''); ?>">
                                                    <option value="" >Select Master Program</option>
                                                    <?php if(isset($programmasters)): ?>
                                                        <?php $__currentLoopData = $programmasters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mvalue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($mvalue['id']); ?>" <?php if(old('master_program')==$mvalue['id'] || isset($franchises_info['name']) && $franchises_info['id'] == $mvalue['id']): ?>selected="selected" <?php endif; ?> ><?php echo e($mvalue['name']); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>
                                                </select>
                                                <?php if($errors->has('master_program')): ?>
                                                    <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('master_program')); ?></strong>
                                                        </span>
                                                <?php endif; ?>
                                            </div>
                                                    </div></div>

                                                <div class="col-sm-12">
                                                    <div class="row">
                                                        <div class="form-group col-sm-12">
                                                    <input name="program_level" value="<?php if(isset($lead['program_level'])): ?><?php echo e($lead['program_level']); ?><?php else: ?><?php echo e(old('program_level')); ?><?php endif; ?>" class="form-control <?php echo e($errors->has('program_level') ? ' is-invalid' : ''); ?>" placeholder="Enter Program Level" type="text" id="">
                                                    <?php if($errors->has('program_level')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('program_level')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                                    </div></div>


                                            </div>
                                        </div>
                                    </div>

                                </div>
                                <div class="form-group row gutters">
                                    <div class="col-sm-3 mx-auto">
                                        <button type="submit" class="btn btn-primary btn-lg btn-block">Add Master Program Level</button>
                                    </div>
                                </div>

                            </form>
                            <!-- Row end -->
                            <div class="row">
                                <div class="col-md-8 mx-auto col-sm-12 listofprogramlevel" id="listofprogramlevel">



                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


        </div>
        <!-- END: .main-content -->
    </div>
    <!-- END: .app-main -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>
    <script>

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $('#master_program').change(function(e) {
        e.preventDefault(); // does not go through with the link.
        var tt = $(this,'option:selected').val();
        $.post({
        type:'POST',
        data: {'id':$(this).val(),'masterId' :  $('#master_program ,option:selected').val()},
        url: "<?php echo e(route('getlevellist')); ?>"
        }).done(function (data) {
        $('#listofprogramlevel').html(data.program_list);

        });
    });
    </script>


    <script src="<?php echo e(URL::asset('js/toastr.min.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(URL::asset('js/ui-toastr.min.js')); ?>" type="text/javascript"></script>
    <!-- If using flash()->important() or flash()->overlay(), you'll need to pull in the JS for Twitter Bootstrap. -->

    <?php if(session()->has('flash_notification')): ?>
        <script>
            jQuery( document ).ready(function() {
                <?php $__currentLoopData = session('flash_notification', collect())->toArray(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                toastr.<?php echo ($message['level'] == 'danger')?'error':$message['level']; ?>('<?php echo $message['message'];?>');
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            });


        </script>

    <?php endif; ?>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>