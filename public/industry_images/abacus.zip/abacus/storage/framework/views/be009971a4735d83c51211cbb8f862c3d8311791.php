<?php $__env->startSection('content'); ?>

    <!-- BEGIN .app-main -->
    <div class="app-main">
        <!-- BEGIN .main-heading -->
        <header class="main-heading">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-xl-8 col-lg-8 col-md-8 col-sm-8">
                        <div class="page-icon">
                            <i class="icon-layers"></i>
                        </div>
                        <div class="page-title">
                            <h5>Student Registration</h5>
                            <h6 class="sub-heading">Welcome to Amma</h6>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4">
                        <div class="right-actions">
                            <a href="#" class="btn btn-primary float-right" data-toggle="tooltip" data-placement="left" title="Download Reports">
                                <i class="icon-download4"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <!-- END: .main-heading -->
        <!-- BEGIN .main-content -->
        <div class="main-content">
            <?php //echo '<pre>'; print_r($franchises_info); echo '</pre>'; ?>
            <?php if(isset($student_info)): ?>
                <form method="POST" action="<?php echo e(url('/admin/students/'.$student_info['id'])); ?>" enctype="multipart/form-data">
                    <?php echo method_field('PUT'); ?>
                    <?php else: ?>
                        <form method="POST" action="<?php echo e(url('/admin/students/')); ?>" enctype="multipart/form-data">
                            <?php endif; ?>
                            <?php echo csrf_field(); ?>
            <div class="row gutters">

                <div class="col-md-12 col-sm-12">
                    <!-- Row start -->
                    <div class="row gutters">
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                            <div class="card">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="form-group col-sm-4">
                                        <label for="">Master Franchisee</label>
                                        <select class="form-control <?php echo e($errors->has('level') ? ' is-invalid' : ''); ?>" name="masterFranchisesId" id="franchisee_code">
                                        <option value="">Select</option>
                                        <?php if(!empty($masterfranchisess)): ?>
                                        <?php $__currentLoopData = $masterfranchisess; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($mf->id); ?>" <?php if(isset($student_info['master_franchisee_id']) && $student_info['master_franchisee_id'] == $mf->id ): ?>selected="selected" <?php endif; ?>><?php echo e($mf->master_franchisee_code); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                                        <?php endif; ?>
                                        </select>
                                        <?php if($errors->has('masterFranchisesId')): ?>
                                        <span class="invalid-feedback">
                                            <strong><?php echo e($errors->first('masterFranchisesId')); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group col-sm-4 ">
                                        <label for="">Franchisee Code</label>
                                        <select class="form-control <?php echo e($errors->has('franchisesId') ? ' is-invalid' : ''); ?>" id="franchise" name="franchisesId">
                                            <option value="<?php if(isset($student_info['franchisee_id'])): ?><?php echo e($student_info['franchisee_id']); ?><?php else: ?><?php echo e(''); ?><?php endif; ?>"><?php if(isset($franchises_info['name'])): ?><?php echo e($franchises_info['name']); ?><?php else: ?><?php echo e('select'); ?><?php endif; ?></option>
                                        </select>
                                        <?php if($errors->has('franchisesId')): ?>
                                        <span class="invalid-feedback">
                                            <strong><?php echo e($errors->first('franchisesId')); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group col-sm-4 <?php echo e($errors->has('centreCode') ? ' is-invalid' : ''); ?>">
                                        <label for="">Centre</label>
                                        <select class="form-control " id="centreCode" name="centreCode">
                                            <option value="<?php if(isset($student_info['centre_id'])): ?><?php echo e($student_info['centre_id']); ?><?php else: ?><?php echo e(''); ?><?php endif; ?>"><?php if(isset($Centres_name['centre_name'])): ?><?php echo e($Centres_name['centre_name']); ?><?php else: ?><?php echo e('select'); ?><?php endif; ?></option>
                                        </select>
                                         <?php if($errors->has('centreCode')): ?>
                                        <span class="invalid-feedback">
                                            <strong><?php echo e($errors->first('centreCode')); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Row end -->
                </div>
                <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                    <!-- Row start -->
                    <div class="row gutters">
                        <?php
                           // echo "<pre>";
                           // print_r($student_info);
                        ?>
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                            <div class="card">
                                <div class="card-header">Student Registration</div>
                                <div class="card-body">
                                    <div class="form-group">
                                        <label for="">Registration No.</label>
                                        <input name="registration_no" type="text" value="<?php if(isset($student_info['registration_no'])): ?><?php echo e($student_info['registration_no']); ?><?php else: ?><?php echo e(old('registration_no')); ?><?php endif; ?>" class="form-control <?php echo e($errors->has('registration_no') ? ' is-invalid' : ''); ?>" id="" placeholder="6945">
                                        <?php if($errors->has('registration_no')): ?>
                                            <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('registration_no')); ?></strong>
                                                        </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="">Registration Date</label>
                                        <input type="date" name="registration_date"  value="<?php if(isset($student_info['registration_date'])): ?><?php echo e($student_info['registration_date']); ?><?php else: ?><?php echo e(old('registration_date')); ?><?php endif; ?>" class="form-control <?php echo e($errors->has('registration_date') ? ' is-invalid' : ''); ?>" id="" >
                                        <?php if($errors->has('registration_date')): ?>
                                            <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('registration_date')); ?></strong>
                                                        </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group">
                                        <label class="custom-file">Student Photo</label>
                                        <input id="file2" name="student_photo" class="form-control <?php echo e($errors->has('student_photo') ? ' is-invalid' : ''); ?>" type="file">
                                        <?php if($errors->has('student_photo')): ?>
                                            <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('student_photo')); ?></strong>
                                                        </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="">Name</label>
                                        <input type="text" name="name"  value="<?php if(isset($student_info['name'])): ?><?php echo e($student_info['name']); ?><?php else: ?><?php echo e(old('name')); ?><?php endif; ?>" class="form-control <?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" id="" placeholder="Anand Kumar Joshi">
                                        <?php if($errors->has('name')): ?>
                                            <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('name')); ?></strong>
                                                        </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="">Date of Birth, Age</label>
                                        <input type="date" name="dob"  value="<?php if(isset($student_info['dob'])): ?><?php echo e($student_info['dob']); ?><?php else: ?><?php echo e(old('dob')); ?><?php endif; ?>" class="form-control <?php echo e($errors->has('dob') ? ' is-invalid' : ''); ?>" id="">
                                        <?php if($errors->has('dob')): ?>
                                            <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('dob')); ?></strong>
                                                        </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="">Address</label>
                                        <textarea name="address"  class="form-control <?php echo e($errors->has('address') ? ' is-invalid' : ''); ?>" id="" rows="2" placeholder="2563, WEA, Karol Bagh"> <?php if(isset($student_info['address'])): ?><?php echo e($student_info['address']); ?><?php else: ?><?php echo e(old('address')); ?><?php endif; ?></textarea>
                                        <?php if($errors->has('address')): ?>
                                            <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('address')); ?></strong>
                                                        </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="">City</label>
                                        <input name="city" type="text"  value="<?php if(isset($student_info['city'])): ?><?php echo e($student_info['city']); ?><?php else: ?><?php echo e(old('city')); ?><?php endif; ?>" class="form-control <?php echo e($errors->has('city') ? ' is-invalid' : ''); ?>" id="" placeholder="New Delhi" >
                                        <?php if($errors->has('city')): ?>
                                            <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('city')); ?></strong>
                                                        </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group row">
                                        <div class="col">
                                            <label for="">State</label>
                                            <input name="state" type="text"  value="<?php if(isset($student_info['state'])): ?><?php echo e($student_info['state']); ?><?php else: ?><?php echo e(old('state')); ?><?php endif; ?>" class="form-control <?php echo e($errors->has('state') ? ' is-invalid' : ''); ?>" id="" placeholder="Delhi" >
                                            <?php if($errors->has('state')): ?>
                                                <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('state')); ?></strong>
                                                        </span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="col">
                                            <label for="">PIN</label>
                                            <input name="pin" type="text"  value="<?php if(isset($student_info['pin'])): ?><?php echo e($student_info['pin']); ?><?php else: ?><?php echo e(old('pin')); ?><?php endif; ?>" class="form-control <?php echo e($errors->has('pin') ? ' is-invalid' : ''); ?>" id="" placeholder="110055" >
                                            <?php if($errors->has('pin')): ?>
                                                <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('pin')); ?></strong>
                                                        </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="">Contact Tel No.</label>
                                        <input type="text" name="contact_tel_no"  value="<?php if(isset($student_info['contact_tel_no'])): ?><?php echo e($student_info['contact_tel_no']); ?><?php else: ?><?php echo e(old('contact_tel_no')); ?><?php endif; ?>" class="form-control <?php echo e($errors->has('contact_tel_no') ? ' is-invalid' : ''); ?>" id="" placeholder="011 65905983" >
                                        <?php if($errors->has('contact_tel_no')): ?>
                                            <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('contact_tel_no')); ?></strong>
                                                        </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="">Male / Female</label>
                                        <select name="gender" class="form-control <?php echo e($errors->has('gender') ? ' is-invalid' : ''); ?>">
                                            <option  value="">Select Gender</option>
                                            <option value="male" <?php if(isset($student_info['gender']) && $student_info['gender'] =='male'): ?><?php echo e('selected'); ?><?php endif; ?>>Male</option>
                                            <option value="female" <?php if(isset($student_info['gender']) && $student_info['gender'] =='female'): ?><?php echo e('selected'); ?><?php endif; ?>>Female</option>
                                        </select>
                                        <?php if($errors->has('gender')): ?>
                                            <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('gender')); ?></strong>
                                                        </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="">School Name</label>
                                        <input name="school_name" type="text"  value="<?php if(isset($student_info['school_name'])): ?><?php echo e($student_info['school_name']); ?><?php else: ?><?php echo e(old('school_name')); ?><?php endif; ?>" class="form-control <?php echo e($errors->has('school_name') ? ' is-invalid' : ''); ?>" id="" placeholder="Salwan Public School">
                                        <?php if($errors->has('school_name')): ?>
                                            <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('school_name')); ?></strong>
                                                        </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="">School Address</label>
                                        <input name="school_address" type="text"  value="<?php if(isset($student_info['school_address'])): ?><?php echo e($student_info['school_address']); ?><?php else: ?><?php echo e(old('school_address')); ?><?php endif; ?>" class="form-control <?php echo e($errors->has('school_address') ? ' is-invalid' : ''); ?>" id="" placeholder="101, Old Rajinder" >
                                        <?php if($errors->has('school_address')): ?>
                                            <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('school_address')); ?></strong>
                                                        </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="">City</label>
                                        <input type="text" name="school_city" value="<?php if(isset($student_info['school_city'])): ?><?php echo e($student_info['school_city']); ?><?php else: ?><?php echo e(old('school_city')); ?><?php endif; ?>" class="form-control <?php echo e($errors->has('school_city') ? ' is-invalid' : ''); ?>" id="" placeholder="New Delhi" >
                                        <?php if($errors->has('school_city')): ?>
                                            <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('school_city')); ?></strong>
                                                        </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group row">
                                        <div class="col">
                                            <label for="">State</label>
                                            <input name="school_state" type="text"  value="<?php if(isset($student_info['school_state'])): ?><?php echo e($student_info['school_state']); ?><?php else: ?><?php echo e(old('school_state')); ?><?php endif; ?>" class="form-control <?php echo e($errors->has('school_state') ? ' is-invalid' : ''); ?>" id="" placeholder="Delhi" >
                                            <?php if($errors->has('school_state')): ?>
                                                <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('school_state')); ?></strong>
                                                        </span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="col">
                                            <label for="">PIN</label>
                                            <input type="text" name="school_pin"  value="<?php if(isset($student_info['school_pin'])): ?><?php echo e($student_info['school_pin']); ?><?php else: ?><?php echo e(old('school_pin')); ?><?php endif; ?>" class="form-control <?php echo e($errors->has('school_pin') ? ' is-invalid' : ''); ?>" id="" placeholder="110055" >
                                            <?php if($errors->has('school_pin')): ?>
                                                <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('school_pin')); ?></strong>
                                                        </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="">Standard/Class</label>
                                        <input type="text" name="class"  value="<?php if(isset($student_info['class'])): ?><?php echo e($student_info['class']); ?><?php else: ?><?php echo e(old('class')); ?><?php endif; ?>" class="form-control <?php echo e($errors->has('class') ? ' is-invalid' : ''); ?>" id="" placeholder="2nd" >
                                        <?php if($errors->has('class')): ?>
                                            <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('class')); ?></strong>
                                                        </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="">Hobby1</label>
                                        <input name="hobby_1" type="text"  value="<?php if(isset($student_info['hobby_1'])): ?><?php echo e($student_info['hobby_1']); ?><?php else: ?><?php echo e(old('hobby_1')); ?><?php endif; ?>" class="form-control <?php echo e($errors->has('hobby_1') ? ' is-invalid' : ''); ?>" id="" placeholder="Keyboard" >
                                        <?php if($errors->has('hobby_1')): ?>
                                            <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('hobby_1')); ?></strong>
                                                        </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="">Hobby2</label>
                                        <input name="hobby_2" type="text"  value="<?php if(isset($student_info['hobby_2'])): ?><?php echo e($student_info['hobby_2']); ?><?php else: ?><?php echo e(old('hobby_2')); ?><?php endif; ?>" class="form-control <?php echo e($errors->has('hobby_2') ? ' is-invalid' : ''); ?>" id="" placeholder="Karate" >
                                        <?php if($errors->has('hobby_2')): ?>
                                            <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('hobby_2')); ?></strong>
                                                        </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="">Hobby3</label>
                                        <input name="hobby_3" type="text"  value="<?php if(isset($student_info['hobby_3'])): ?><?php echo e($student_info['hobby_3']); ?><?php else: ?><?php echo e(old('hobby_3')); ?><?php endif; ?>" class="form-control <?php echo e($errors->has('hobby_3') ? ' is-invalid' : ''); ?>" id="" placeholder="" >
                                        <?php if($errors->has('hobby_3')): ?>
                                            <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('hobby_3')); ?></strong>
                                                        </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Row end -->
                </div>
                <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                    <!-- Row start -->
                    <div class="row gutters">
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                            <div class="card">
                                <div class="card-header">Parent Detail</div>
                                <div class="card-body">
                                    <div class="form-group">
                                        <label for="">Father's Name Title</label>
                                        <select name="ftitle" class="form-control <?php echo e($errors->has('ftitle') ? ' is-invalid' : ''); ?>">
                                            <option  value="">Select</option>
                                            <option value="Dr" <?php if(isset($parentDetails['ftitle']) && $parentDetails['ftitle'] =='Dr'): ?><?php echo e('selected'); ?><?php endif; ?>>Dr.</option>
                                            <option value="Mr" <?php if(isset($parentDetails['ftitle']) && $parentDetails['ftitle'] =='Mr'): ?><?php echo e('selected'); ?><?php endif; ?>>Mr.</option>
                                        </select>
                                        <?php if($errors->has('ftitle')): ?>
                                            <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('ftitle')); ?></strong>
                                                        </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="">Father's Name</label>
                                        <input type="text" name="fathers_name"  value="<?php if(isset($parentDetails['fathers_name'])): ?><?php echo e($parentDetails['fathers_name']); ?><?php else: ?><?php echo e(old('fathers_name')); ?><?php endif; ?>" class="form-control <?php echo e($errors->has('fathers_name') ? ' is-invalid' : ''); ?>" id="" placeholder="Sushil Kumar Joshi">
                                        <?php if($errors->has('fathers_name')): ?>
                                            <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('fathers_name')); ?></strong>
                                                        </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="">Occupation </label>
                                        <input type="text" name="fathers_occupation"   value="<?php if(isset($parentDetails['fathers_occupation'])): ?><?php echo e($parentDetails['fathers_occupation']); ?><?php else: ?><?php echo e(old('fathers_occupation')); ?><?php endif; ?>" class="form-control <?php echo e($errors->has('fathers_occupation') ? ' is-invalid' : ''); ?>" id="" placeholder="Service (service, self-employed, business, housewife)">
                                        <?php if($errors->has('fathers_occupation')): ?>
                                            <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('fathers_occupation')); ?></strong>
                                                        </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="">Office Address</label>
                                        <textarea name="fathers_office_address" class="form-control <?php echo e($errors->has('fathers_office_address') ? ' is-invalid' : ''); ?>" id="" rows="2"  placeholder="Shastri Bhawan, Dr.Rajendra Prasad Road"> <?php if(isset($parentDetails['fathers_office_address'])): ?><?php echo e($parentDetails['fathers_office_address']); ?><?php else: ?><?php echo e(old('fathers_office_address')); ?><?php endif; ?></textarea>
                                        <?php if($errors->has('fathers_office_address')): ?>
                                            <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('fathers_office_address')); ?></strong>
                                                        </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="">City</label>
                                        <input name="fathers_city" type="text"  value="<?php if(isset($parentDetails['fathers_city'])): ?><?php echo e($parentDetails['fathers_city']); ?><?php else: ?><?php echo e(old('fathers_city')); ?><?php endif; ?>" class="form-control <?php echo e($errors->has('fathers_city') ? ' is-invalid' : ''); ?>" id="" placeholder="New Delhi" >
                                        <?php if($errors->has('fathers_city')): ?>
                                            <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('fathers_city')); ?></strong>
                                                        </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group row">
                                        <div class="col">
                                            <label for="">State</label>
                                            <input name="fathers_state"  value="<?php if(isset($parentDetails['fathers_state'])): ?><?php echo e($parentDetails['fathers_state']); ?><?php else: ?><?php echo e(old('fathers_state')); ?><?php endif; ?>"class="form-control <?php echo e($errors->has('fathers_state') ? ' is-invalid' : ''); ?>" placeholder="Delhi" type="text">
                                            <?php if($errors->has('fathers_state')): ?>
                                                <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('fathers_state')); ?></strong>
                                                        </span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="col">
                                            <label for="">PIN</label>
                                            <input name="fathers_pin"  value="<?php if(isset($parentDetails['fathers_pin'])): ?><?php echo e($parentDetails['fathers_pin']); ?><?php else: ?><?php echo e(old('fathers_pin')); ?><?php endif; ?>" class="form-control <?php echo e($errors->has('fathers_pin') ? ' is-invalid' : ''); ?>" placeholder="110014" type="text">
                                            <?php if($errors->has('fathers_pin')): ?>
                                                <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('fathers_pin')); ?></strong>
                                                        </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="">Office Tel.No.</label>
                                        <input name="fathers_office_tel_no"  value="<?php if(isset($parentDetails['fathers_office_tel_no'])): ?><?php echo e($parentDetails['fathers_office_tel_no']); ?><?php else: ?><?php echo e(old('fathers_office_tel_no')); ?><?php endif; ?>" type="text" class="form-control <?php echo e($errors->has('fathers_office_tel_no') ? ' is-invalid' : ''); ?>" id="" placeholder="011 25752763">
                                        <?php if($errors->has('fathers_office_tel_no')): ?>
                                            <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('fathers_office_tel_no')); ?></strong>
                                                        </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="">Mobile No.</label>
                                        <input name="fathers_mobile_no"  value="<?php if(isset($parentDetails['fathers_mobile_no'])): ?><?php echo e($parentDetails['fathers_mobile_no']); ?><?php else: ?><?php echo e(old('fathers_mobile_no')); ?><?php endif; ?>" type="text" class="form-control <?php echo e($errors->has('fathers_mobile_no') ? ' is-invalid' : ''); ?>" id="" placeholder="9310394263">
                                        <?php if($errors->has('fathers_mobile_no')): ?>
                                            <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('fathers_mobile_no')); ?></strong>
                                                        </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="">Email ID</label>
                                        <input name="fathers_email"  value="<?php if(isset($parentDetails['fathers_email'])): ?><?php echo e($parentDetails['fathers_email']); ?><?php else: ?><?php echo e(old('fathers_email')); ?><?php endif; ?>" type="email" class="form-control <?php echo e($errors->has('fathers_email') ? ' is-invalid' : ''); ?>" id="" placeholder="skj@gmail.com">
                                        <?php if($errors->has('fathers_email')): ?>
                                            <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('fathers_email')); ?></strong>
                                                        </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="">Mother's Name Title</label>
                                        <select name="mtitle" class="form-control <?php echo e($errors->has('mtitle') ? ' is-invalid' : ''); ?>">
                                            <option  value="">Select</option>
                                            <option value="Dr" <?php if(isset($parentDetails['mtitle']) && $parentDetails['mtitle'] =='Dr'): ?><?php echo e('selected'); ?><?php endif; ?>>Dr.</option>
                                            <option value="Miss" <?php if(isset($parentDetails['mtitle']) && $parentDetails['mtitle'] =='Miss'): ?><?php echo e('selected'); ?><?php endif; ?>>Miss.</option>
                                        </select>
                                        <?php if($errors->has('mtitle')): ?>
                                            <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('mtitle')); ?></strong>
                                                        </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="">Mother's Name</label>
                                        <input name="mothers_name" value="<?php if(isset($parentDetails['mothers_name'])): ?><?php echo e($parentDetails['mothers_name']); ?><?php else: ?><?php echo e(old('mothers_name')); ?><?php endif; ?>" type="text" class="form-control <?php echo e($errors->has('mothers_name') ? ' is-invalid' : ''); ?>" id="" placeholder=" Rekha Joshi">
                                        <?php if($errors->has('mothers_name')): ?>
                                            <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('mothers_name')); ?></strong>
                                                        </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="">Occupation</label>
                                        <input name="mothers_occupation"  value="<?php if(isset($parentDetails['mothers_occupation'])): ?><?php echo e($parentDetails['mothers_occupation']); ?><?php else: ?><?php echo e(old('mothers_occupation')); ?><?php endif; ?>" type="text" class="form-control <?php echo e($errors->has('mothers_occupation') ? ' is-invalid' : ''); ?>" id="" placeholder="Self-employed">
                                        <?php if($errors->has('mothers_occupation')): ?>
                                            <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('mothers_occupation')); ?></strong>
                                                        </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="">Office Address</label>
                                        <input name="mothers_office_address"  value="<?php if(isset($parentDetails['mothers_office_address'])): ?><?php echo e($parentDetails['mothers_office_address']); ?><?php else: ?><?php echo e(old('mothers_office_address')); ?><?php endif; ?>" type="text" class="form-control <?php echo e($errors->has('mothers_office_address') ? ' is-invalid' : ''); ?>" id="" placeholder="2563, WEA Karol Bagh">
                                        <?php if($errors->has('mothers_office_address')): ?>
                                            <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('mothers_office_address')); ?></strong>
                                                        </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="">City</label>
                                        <input  name="mothers_city" value="<?php if(isset($parentDetails['mothers_city'])): ?><?php echo e($parentDetails['mothers_city']); ?><?php else: ?><?php echo e(old('mothers_city')); ?><?php endif; ?>" type="text" class="form-control <?php echo e($errors->has('mothers_city') ? ' is-invalid' : ''); ?>" id="" placeholder="New Delhi" >
                                        <?php if($errors->has('mothers_city')): ?>
                                            <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('mothers_city')); ?></strong>
                                                        </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group row">
                                        <div class="col">
                                            <label for="">State</label>
                                            <input name="mothers_state"  value="<?php if(isset($parentDetails['mothers_state'])): ?><?php echo e($parentDetails['mothers_state']); ?><?php else: ?><?php echo e(old('mothers_state')); ?><?php endif; ?>" class="form-control <?php echo e($errors->has('mothers_state') ? ' is-invalid' : ''); ?>" placeholder="Delhi" type="text">
                                            <?php if($errors->has('mothers_state')): ?>
                                                <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('mothers_state')); ?></strong>
                                                        </span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="col">
                                            <label for="">PIN</label>
                                            <input name="mothers_pin"  value="<?php if(isset($parentDetails['mothers_pin'])): ?><?php echo e($parentDetails['mothers_pin']); ?><?php else: ?><?php echo e(old('mothers_pin')); ?><?php endif; ?>" class="form-control <?php echo e($errors->has('mothers_pin') ? ' is-invalid' : ''); ?>" placeholder="110014" type="text">
                                            <?php if($errors->has('mothers_pin')): ?>
                                                <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('mothers_pin')); ?></strong>
                                                        </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="">Office Tel.No.</label>
                                        <input name="mothers_office_tel_no"  value="<?php if(isset($parentDetails['mothers_office_tel_no'])): ?><?php echo e($parentDetails['mothers_office_tel_no']); ?><?php else: ?><?php echo e(old('mothers_office_tel_no')); ?><?php endif; ?>" type="text" class="form-control <?php echo e($errors->has('mothers_office_tel_no') ? ' is-invalid' : ''); ?>" id="" placeholder="011 25752763">
                                        <?php if($errors->has('mothers_office_tel_no')): ?>
                                            <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('mothers_office_tel_no')); ?></strong>
                                                        </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="">Mobile No.</label>
                                        <input name="mothers_mobile_no"  value="<?php if(isset($parentDetails['mothers_mobile_no'])): ?><?php echo e($parentDetails['mothers_mobile_no']); ?><?php else: ?><?php echo e(old('mothers_mobile_no')); ?><?php endif; ?>" type="text" class="form-control <?php echo e($errors->has('mothers_mobile_no') ? ' is-invalid' : ''); ?>" id="" placeholder="9313318230">
                                        <?php if($errors->has('mothers_mobile_no')): ?>
                                            <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('mothers_mobile_no')); ?></strong>
                                                        </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="">Email ID</label>
                                        <input name="mothers_email" value="<?php if(isset($parentDetails['mothers_email'])): ?><?php echo e($parentDetails['mothers_email']); ?><?php else: ?><?php echo e(old('mothers_email')); ?><?php endif; ?>" type="email" class="form-control <?php echo e($errors->has('mothers_email') ? ' is-invalid' : ''); ?>" id="" placeholder="rekhajoshi@gmail.com">
                                        <?php if($errors->has('mothers_email')): ?>
                                            <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('mothers_email')); ?></strong>
                                                        </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="">Referred by (Friends, Advertisement, Internet, etc.)</label>
                                        <input name="referred_by"  value="<?php if(isset($parentDetails['referred_by'])): ?><?php echo e($parentDetails['referred_by']); ?><?php else: ?><?php echo e(old('referred_by')); ?><?php endif; ?>" type="text" class="form-control <?php echo e($errors->has('referred_by') ? ' is-invalid' : ''); ?>" id="" placeholder="Internet">
                                        <?php if($errors->has('referred_by')): ?>
                                            <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('referred_by')); ?></strong>
                                                        </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="">Purpose of enrollment</label>
                                        <input name="purpose_of_enrollment"  value="<?php if(isset($parentDetails['purpose_of_enrollment'])): ?><?php echo e($parentDetails['purpose_of_enrollment']); ?><?php else: ?><?php echo e(old('purpose_of_enrollment')); ?><?php endif; ?>" type="text" class="form-control <?php echo e($errors->has('purpose_of_enrollment') ? ' is-invalid' : ''); ?>" id="" placeholder="Improvement in mathematics, confidence">
                                        <?php if($errors->has('purpose_of_enrollment')): ?>
                                            <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('purpose_of_enrollment')); ?></strong>
                                                        </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Row end -->
                </div>
            </div>
            <div class="form-group row gutters">
                <div class="col-sm-3 mx-auto">
                    <button type="submit" class="btn btn-primary btn-lg btn-block">Submit</button>
                </div>
            </div>
                        </form>

        </div>
        <!-- END: .main-content -->
    </div>
    <!-- END: .app-main -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>

    <script>
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
       $('#franchisee_code').change(function(e) {
        e.preventDefault(); // does not go through with the link.
        var tt = $(this,'option:selected').val();
        $.post({
            type:'POST',
            data: {'masterId':$(this).val()},
            url: "<?php echo e(route('getFranchisee')); ?>"
        }).done(function (data) {
            $('#franchise').html(data);            
           
        });
    });
    $('#franchise').change(function(e) {
        e.preventDefault(); // does not go through with the link.
        var tt = $(this,'option:selected').val();
        $.post({
            type:'POST',
            data: {'id':$(this).val(),'masterId' :  $('#franchisee_code ,option:selected').val()},
            url: "<?php echo e(route('getcenter')); ?>"
        }).done(function (data) {
            $('#centreCode').html(data);            
           
        });
    });
      
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>