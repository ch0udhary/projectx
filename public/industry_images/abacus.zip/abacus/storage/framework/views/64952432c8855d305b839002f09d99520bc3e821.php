<?php $__env->startSection('content'); ?>
<div class="app-main">
    <!-- BEGIN .main-heading -->
    <header class="main-heading">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xl-8 col-lg-8 col-md-8 col-sm-8">
                    <div class="page-icon">
                        <i class="icon-layers"></i>
                    </div>
                    <div class="page-title">
                        <h5>Fees Master</h5>
                        <h6 class="sub-heading">Welcome to Amma</h6>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4">
                    <div class="right-actions">
                        <!-- <a href="#" class="btn btn-primary float-right" data-toggle="tooltip" data-placement="left" title="Download Reports">
                            <i class="icon-download4"></i>
                        </a> -->
                    </div>
                </div>
            </div>
        </div>
    </header>
<!-- BEGIN .main-content -->
<div class="main-content">
<?php if(\Session::has('success')): ?>
    <div class="alert alert-success">
        <ul>
            <li><?php echo \Session::get('success'); ?></li>
        </ul>
    </div>
<?php endif; ?>
<?php if(\Session::has('error')): ?>
    <div class="alert alert-danger">
        <ul>
            <li><?php echo \Session::get('error'); ?></li>
        </ul>
    </div>
<?php endif; ?>
    <div class="row gutters">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
            <!-- Row start -->
            <div class="row gutters">
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                    <div class="card">
                        <div class="card-body">
                            <form method="post" action="<?php echo e(route('faculty.store')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="row gutters">
                                <div class="col-md-8 mx-auto col-sm-12">
                                    <div class="row">
                                        <div class="form-group col-sm-4">
                                            <label for="">Franchisee Master</label>
                                           <select class="form-control    <?php echo e($errors->has('level') ? ' is-invalid' : ''); ?>" name="masterFranchisesId" id="franchisee_code">
                                            <option selected value="">Select</option>
                                            <?php if(!empty($masterfranchisess)): ?>
                                            <?php $__currentLoopData = $masterfranchisess; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($mf->id); ?>"><?php echo e($mf->master_franchisee_code); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                                            <?php endif; ?>
                                            </select>
                                            <?php if($errors->has('masterFranchisesId')): ?>
                                            <span class="invalid-feedback">
                                                <strong><?php echo e($errors->first('masterFranchisesId')); ?></strong>
                                            </span> 
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group col-sm-4">
                                            <label for="">Franchisee Code</label>
                                            <select class="form-control <?php echo e($errors->has('franchisesId') ? ' is-invalid' : ''); ?>" id="franchise" name="franchisesId">
                                                <option selected value="">Select</option>
                                                
                                            </select>
                                            <?php if($errors->has('franchisesId')): ?>
                                            <span class="invalid-feedback">
                                                <strong><?php echo e($errors->first('franchisesId')); ?></strong>
                                            </span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group col-sm-4">
                                            <label for="">Centre</label>
                                            <select class="form-control " id="centreCode" name="centreCode">
                                                <option selected>Select Centre</option>
                                                
                                            </select>
                                            <?php if($errors->has('centreCode')): ?>
                                            <span class="invalid-feedback">
                                                <strong><?php echo e($errors->first('centreCode')); ?></strong>
                                            </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <!-- <div class="form-group row">
                                        <div class="col">
                                            <label for="">Center Name</label>
                                        </div>
                                        <div class="col">
                                            <label>Asha Coaching Center</label>
                                        </div>
                                    </div> -->
                                    <div class="row">
                                        <div class="form-group col-sm-6">
                                            <label for="" >Faculty Type</label>
                                            <select class="form-control" name="facultyType">            
                                                <option value="owner">Owner</option>
                                                <option value="faculty">Faculty</option>
                                            </select>
                                            <?php if($errors->has('facultyType')): ?>
                                            <span class="invalid-feedback">
                                                <strong><?php echo e($errors->first('facultyType')); ?></strong>
                                            </span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group col-sm-6">
                                            <label for="">Faculty/Teacher Code</label>
                                            <input class="form-control" placeholder="323" type="text" name="facultyCode">
                                            <?php if($errors->has('facultyCode')): ?>
                                            <span class="invalid-feedback">
                                                <strong><?php echo e($errors->first('facultyCode')); ?></strong>
                                            </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="form-group col-sm-6">
                                            <label for="">Name</label>
                                            <input class="form-control" placeholder="Mrs. Kalpana Chawla" type="text" name="facultyName">
                                            <?php if($errors->has('facultyName')): ?>
                                            <span class="invalid-feedback">
                                                <strong><?php echo e($errors->first('facultyName')); ?></strong>
                                            </span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group col-sm-6">
                                            <label for="">Date of Birth</label>
                                            <input class="form-control" placeholder="" type="date" name="dob">
                                            <?php if($errors->has('dob')): ?>
                                            <span class="invalid-feedback">
                                                <strong><?php echo e($errors->first('dob')); ?></strong>
                                            </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="">Address</label>
                                        <input class="form-control" placeholder="25/34 East Patel Nagar" name="address">
                                        <?php if($errors->has('address')): ?>
                                        <span class="invalid-feedback">
                                            <strong><?php echo e($errors->first('address')); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="row">
                                        <div class="form-group col-sm-4">
                                            <label for="">City</label>
                                            <input class="form-control" placeholder="New Delhi" name="city">
                                            <?php if($errors->has('city')): ?>
                                            <span class="invalid-feedback">
                                                <strong><?php echo e($errors->first('city')); ?></strong>
                                            </span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group col-sm-4">
                                            <label for="">State</label>
                                            <input class="form-control" placeholder="Delhi" type="text" name="state">
                                            <?php if($errors->has('state')): ?>
                                            <span class="invalid-feedback">
                                                <strong><?php echo e($errors->first('state')); ?></strong>
                                            </span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group col-sm-4">
                                            <label for="">PIN</label>
                                            <input class="form-control" placeholder="110014" type="text" name="pincode">
                                            <?php if($errors->has('pincode')): ?>
                                            <span class="invalid-feedback">
                                                <strong><?php echo e($errors->first('pincode')); ?></strong>
                                            </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="form-group col-sm-6">
                                            <label for="">Education</label>
                                            <input class="form-control" placeholder="B.A., B.Ed." type="text" name="education">
                                            <?php if($errors->has('education')): ?>
                                            <span class="invalid-feedback">
                                                <strong><?php echo e($errors->first('education')); ?></strong>
                                            </span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group col-sm-6">
                                            <label for="">Skills, if any.</label>
                                            <input class="form-control" placeholder="Singer" type="text" name="skills">
                                            <?php if($errors->has('skills')): ?>
                                            <span class="invalid-feedback">
                                                <strong><?php echo e($errors->first('skills')); ?></strong>
                                            </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="form-group col-sm-4">
                                            <label for="">Residence Phone No.</label>
                                            <input class="form-control" placeholder="011 25752763" type="text" name="residenceNo">
                                            <?php if($errors->has('residenceNo')): ?>
                                            <span class="invalid-feedback">
                                                <strong><?php echo e($errors->first('residenceNo')); ?></strong>
                                            </span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group col-sm-4">
                                            <label for="">Mobile No.</label>
                                            <input class="form-control" placeholder="9310394264" type="text" name="mobileNo">
                                            <?php if($errors->has('mobileNo')): ?>
                                            <span class="invalid-feedback">
                                                <strong><?php echo e($errors->first('mobileNo')); ?></strong>
                                            </span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group col-sm-4">
                                            <label for="">Email ID</label>
                                            <input class="form-control" placeholder="kc@gmail.com" type="email" name="email">
                                            <?php if($errors->has('email')): ?>
                                            <span class="invalid-feedback">
                                                <strong><?php echo e($errors->first('email')); ?></strong>
                                            </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="form-group col-sm-4">
                                            <label for="">Years Experience in Teaching</label>
                                            <Select class="form-control" name="experienceTotal">
                                                <option >Select Years</option>
                                                <?php for($i=1;$i<=5;$i++): ?>         <option value="<?php echo e($i); ?>"><?php echo e($i); ?> years</option>
                                                <?php endfor; ?>                
                                            </Select>
                                            <?php if($errors->has('experienceTotal')): ?>
                                            <span class="invalid-feedback">
                                                <strong><?php echo e($errors->first('experienceTotal')); ?></strong>
                                            </span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group col-sm-4">
                                            <label for="">Years Experience in Abacus</label>
                                            <Select class="form-control" name="experienceAbcus">
                                                <option >Select Years</option>
                                                <?php for($i=1;$i<=5;$i++): ?>         <option value="<?php echo e($i); ?>"><?php echo e($i); ?> years</option>
                                                <?php endfor; ?>  
                                            </Select>
                                            <?php if($errors->has('experienceAbcus')): ?>
                                            <span class="invalid-feedback">
                                                <strong><?php echo e($errors->first('experienceAbcus')); ?></strong>
                                            </span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="form-group col-sm-4">
                                            <label for="">Years Exp. in Vedic Maths</label>
                                            <Select class="form-control" name="experienceVMath">
                                                <option >Select Years</option>
                                                <?php for($i=1;$i<=5;$i++): ?>         <option value="<?php echo e($i); ?>"><?php echo e($i); ?> years</option>
                                                <?php endfor; ?>   
                                            </Select>
                                            <?php if($errors->has('experienceVMath')): ?>
                                            <span class="invalid-feedback">
                                                <strong><?php echo e($errors->first('experienceVMath')); ?></strong>
                                            </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="">Whether training required</label>
                                        <Select name="trainingRequire" class="form-control">     
                                            <option value="yes">Yes</option>
                                            <option value="no">No</option>
                                        </Select>
                                        <?php if($errors->has('trainingRequire')): ?>
                                        <span class="invalid-feedback">
                                            <strong><?php echo e($errors->first('trainingRequire')); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group row gutters">
                                <div class="col-sm-3 mx-auto">
                                    <button type="submit" class="btn btn-primary btn-lg btn-block">Submit</button>
                                </div>
                            </div>
                            </form>
                        </div>
                    </div>
                         
                </div>
            </div>
            <!-- Row end -->
        </div>
    </div>
    
    
</div>
<!-- END: .main-content -->
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>

<script>
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    $('#franchisee_code').change(function(e) {
        e.preventDefault(); // does not go through with the link.
        var tt = $(this,'option:selected').val();
        $.post({
            type:'POST',
            data: {'masterId':$(this).val()},
            url: "<?php echo e(route('getFranchisee')); ?>"
        }).done(function (data) {
            $('#franchise').html(data);            
           
        });
    });
    $('#franchise').change(function(e) {
        e.preventDefault(); // does not go through with the link.
        var tt = $(this,'option:selected').val();
        $.post({
            type:'POST',
            data: {'id':$(this).val(),'masterId' :  $('#franchisee_code ,option:selected').val()},
            url: "<?php echo e(route('getcenter')); ?>"
        }).done(function (data) {
            $('#centreCode').html(data);            
           
        });
    });
    $('#getDetails').on('click',function(e) {
        e.preventDefault(); // does not go through with the link.
        if($.trim($('#regnumber').val()) == ''){
            alert("Please Enter Registration Number.")
        }
        var tt = $('#regnumber').val();
        $.post({
            type:'POST',
            data: {'regNo':$('#regnumber').val()},
            url: "<?php echo e(route('getstudent')); ?>"
        }).done(function (data) {
            $('.studentDeatils').html(data);            
           
        });
    });
</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>