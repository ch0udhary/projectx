<?php $__env->startSection('stylesheet'); ?>
    <link href="<?php echo e(URL::asset('css/toastr.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(URL::asset('css/jquery.toast.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>



    

    <!-- BEGIN .app-main -->

    <div class="app-main">
        <!-- BEGIN .main-heading -->
        <header class="main-heading">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-xl-8 col-lg-8 col-md-8 col-sm-8">
                        <div class="page-icon">
                            <i class="icon-layers"></i>
                        </div>
                        <div class="page-title">
                            <h5>Add Master Franchisee</h5>
                            <h6 class="sub-heading">Welcome to Amma</h6>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4">
                        <div class="right-actions">
                            <a href="#" class="btn btn-primary float-right" data-toggle="tooltip" data-placement="left" title="Download Reports">
                                <i class="icon-download4"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <!-- END: .main-heading -->
        <!-- BEGIN .main-content -->
        <div class="main-content">
            <?php //echo '<pre>'; print_r($franchises_info); echo '</pre>'; ?>


                        
                            <div class="row gutters">

                                <div class="col-md-12 col-sm-12">
                                    <!-- Row start -->
                                    <div class="row gutters">
                                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                                            <div class="card">
                                                <div class="card-body">
												<form method="POST" action="<?php echo e(url('/admin/center-faculty/')); ?>" enctype="multipart/form-data">

														<?php echo csrf_field(); ?>
                                                    <div class="row">
													
                                                        <div class="form-group col-sm-4">
                                                            <label for="">Master Franchisee</label>
                                                            <select class="form-control <?php echo e($errors->has('masterFranchisesId') ? ' is-invalid' : ''); ?>" name="masterFranchisesId" id="franchisee_code">
                                                                <option value="">Select</option>
                                                                <?php if(!empty($masterfranchisess)): ?>
                                                                    <?php $__currentLoopData = $masterfranchisess; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <option value="<?php echo e($mf->id); ?>" <?php if(isset($student_info['master_franchisee_id']) && $student_info['master_franchisee_id'] == $mf->id ): ?>selected="selected" <?php endif; ?>><?php echo e($mf->master_franchisee_code); ?></option>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                <?php endif; ?>
                                                            </select>
                                                            <?php if($errors->has('masterFranchisesId')): ?>
                                                                <span class="invalid-feedback">
                                            <strong><?php echo e($errors->first('masterFranchisesId')); ?></strong>
                                        </span>
                                                            <?php endif; ?>
                                                        </div>
                                                        <div class="form-group col-sm-4 ">
                                                            <label for="">Franchisee Code</label>
                                                            <select class="form-control <?php echo e($errors->has('franchisesId') ? ' is-invalid' : ''); ?>" id="franchise" name="franchisesId">
                                                                <option value="<?php if(isset($student_info['franchisee_id'])): ?><?php echo e($student_info['franchisee_id']); ?><?php else: ?><?php echo e(''); ?><?php endif; ?>"><?php if(isset($franchises_info['name'])): ?><?php echo e($franchises_info['name']); ?><?php else: ?><?php echo e('select'); ?><?php endif; ?></option>
                                                            </select>
                                                            <?php if($errors->has('franchisesId')): ?>
                                                                <span class="invalid-feedback">
                                            <strong><?php echo e($errors->first('franchisesId')); ?></strong>
                                        </span>
                                                            <?php endif; ?>
                                                        </div>
                                                        <div class="form-group col-sm-4 ">
                                                            <label for="">Centre</label>
                                                            <select class="form-control <?php echo e($errors->has('centreCode') ? ' is-invalid' : ''); ?>" id="centreCode" name="centreCode">
                                                                <option value="<?php if(isset($Centres_name['centre_name'])): ?><?php echo e($Centres_name['centre_name']); ?><?php else: ?><?php echo e(''); ?><?php endif; ?>"><?php if(isset($Centres_name['centre_name'])): ?><?php echo e($Centres_name['centre_name']); ?><?php else: ?><?php echo e('select'); ?><?php endif; ?></option>
                                                            </select>
                                                            <?php if($errors->has('centreCode')): ?>
                                                                <span class="invalid-feedback">
                                            <strong><?php echo e($errors->first('centreCode')); ?></strong>
                                        </span>
                                                            <?php endif; ?>
                                                        </div>


                                                    <div class="form-group col-sm-4">
                                                        <label for="">First Name</label>
                                                        <input type="text" name="fname"  value="<?php if(isset($student_info['Fname'])): ?><?php echo e($student_info['name']); ?><?php else: ?><?php echo e(old('name')); ?><?php endif; ?>" class="form-control <?php echo e($errors->has('fname') ? ' is-invalid' : ''); ?>" id="" placeholder="Anand">
                                                        <?php if($errors->has('fname')): ?>
                                                            <span class="invalid-feedback">
                                                        <strong><?php echo e($errors->first('fname')); ?></strong>
                                                    </span>
                                                        <?php endif; ?>
                                                    </div>
                                                    <div class="form-group col-sm-4">
                                                        <label for="">Last Name</label>
                                                        <input type="text" name="lname"  value="<?php if(isset($student_info['name'])): ?><?php echo e($student_info['name']); ?><?php else: ?><?php echo e(old('lname')); ?><?php endif; ?>" class="form-control <?php echo e($errors->has('lname') ? ' is-invalid' : ''); ?>" id="" placeholder="Joshi">
                                                        <?php if($errors->has('lname')): ?>
                                                            <span class="invalid-feedback">
                                                        <strong><?php echo e($errors->first('lname')); ?></strong>
                                                    </span>
                                                        <?php endif; ?>
                                                    </div>
                                                    <div class="form-group col-sm-4">
                                                        <label for="">Gender</label>
                                                        <select name="gender" class="form-control <?php echo e($errors->has('gender') ? ' is-invalid' : ''); ?>">
                                                            <option  value="">Select Gender</option>
                                                            <option value="male" <?php if(isset($student_info['gender']) && $student_info['gender'] =='male'): ?><?php echo e('selected'); ?><?php endif; ?>>Male</option>
                                                            <option value="female" <?php if(isset($student_info['gender']) && $student_info['gender'] =='female'): ?><?php echo e('selected'); ?><?php endif; ?>>Female</option>
                                                        </select>
                                                        <?php if($errors->has('gender')): ?>
                                                            <span class="invalid-feedback">
                                                        <strong><?php echo e($errors->first('gender')); ?></strong>
                                                    </span>
                                                        <?php endif; ?>
                                                    </div>
                                                    </div>
                                               
											   <div class="form-group row gutters">
                                <div class="col-sm-3 mx-auto">
                                    <button type="submit" class="btn btn-primary btn-lg btn-block">Submit</button>
                                </div>
                            </div>
							   </form>
							<div class="row">
                                <div class="col-md-8 mx-auto col-sm-12" id="facultyattendance">  </div>
                            </div>
											   </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Row end -->
                                

                            
                            
                     
						
						
							</div></div>

        </div>
        <!-- END: .main-content -->
    </div>
    <!-- END: .app-main -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>

    <script>
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $('#franchisee_code').change(function(e) {
            e.preventDefault(); // does not go through with the link.
            var tt = $(this,'option:selected').val();
            $.post({
                type:'POST',
                data: {'masterId':$(this).val()},
                url: "<?php echo e(route('getFranchisee')); ?>"
            }).done(function (data) {
                $('#franchise').html(data);

            });
        });
        $('#franchise').change(function(e) {
            e.preventDefault(); // does not go through with the link.
            var tt = $(this,'option:selected').val();
            $.post({
                type:'POST',
                data: {'id':$(this).val(),'masterId' :  $('#franchisee_code ,option:selected').val()},
                url: "<?php echo e(route('getcenter')); ?>"
            }).done(function (data) {
                $('#centreCode').html(data);

            });
        }); 

		$('#centreCode').change(function(e) {
            e.preventDefault(); // does not go through with the link.
            var tt = $(this,'option:selected').val();
            $.post({
                type:'POST',
                data: {'id':$(this).val(),'centreid' :  $('#centreCode ,option:selected').val()},
                url: "<?php echo e(route('getfaculty_list')); ?>"
            }).done(function (data) {
                $('#facultyattendance').html(data);

            });
        });


        </script>


    <script src="<?php echo e(URL::asset('js/toastr.min.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(URL::asset('js/ui-toastr.min.js')); ?>" type="text/javascript"></script>
    <!-- If using flash()->important() or flash()->overlay(), you'll need to pull in the JS for Twitter Bootstrap. -->

    <?php if(session()->has('flash_notification')): ?>
        <script>
            jQuery( document ).ready(function() {
                <?php $__currentLoopData = session('flash_notification', collect())->toArray(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                toastr.<?php echo ($message['level'] == 'danger')?'error':$message['level']; ?>('<?php echo $message['message'];?>');
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            });


        </script>

    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>